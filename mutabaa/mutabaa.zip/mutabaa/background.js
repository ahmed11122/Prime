// ══════════════════════════════════════════════════════════════════
// متابعة — background.js (Manifest V3 service worker)
// ══════════════════════════════════════════════════════════════════
// Single source of truth for the employee's activity/session state,
// ACROSS all prime-iq.com tabs and iframes.
//
// Two independent axes, on purpose (see Prompt.txt):
//
//   SESSION  — "logged_in" | "logged_out"
//              Changed ONLY by explicit evidence from the company
//              system (landing on its login screen). Never inferred
//              from tab closing, tab hidden, window blur, or idle.
//
//   ACTIVITY — "عمل" | "استراحة"
//              Driven ONLY by chrome.idle, which reports SYSTEM-WIDE
//              mouse/keyboard input — not "is prime-iq.com focused".
//              Switching to WhatsApp, another tab, another app, or
//              helping a coworker all still count as "عمل" as long as
//              the person is touching the keyboard/mouse at all.
//
// "استراحة" therefore means, precisely:
//   "استراحة محتسبة بسبب عدم وجود نشاط بالنظام لمدة 7 دقائق"
// — NOT "confirmed on an official break". Content scripts only ever
// display the short label; this file (and the dashboard) are where
// that distinction has to be respected.
// ══════════════════════════════════════════════════════════════════

const PB_BASE_URL = "https://api.mutabaa.online";
const PB_API_KEY = "cf98ce3b65462aba390b6de5d4922f7219c46b344e6ba1cc";

const BREAK_THRESHOLD_SEC = 7 * 60; // chrome.idle's minimum granularity is 15s; 7 min is well above that.
const BREAK_THRESHOLD_MS = BREAK_THRESHOLD_SEC * 1000;

const COMPANY_URL_PATTERNS = [
  "*://*.prime-iq.com/*",
  "*://prime-iq.com/*"
];

const STORAGE_KEY = "mutabaaBgState";

chrome.idle.setDetectionInterval(BREAK_THRESHOLD_SEC);

// ── STATE ────────────────────────────────────────────────────────
// MV3 service workers get evicted after ~30s of inactivity and are
// recreated on the next event. A plain `let` variable would silently
// reset to its defaults on every eviction, which previously caused
// stuck/incorrect state. chrome.storage.session persists for the
// entire browser session (cleared on browser restart, which is the
// correct boundary — a fresh browser session shouldn't resume
// yesterday's stale "on break" state) but survives worker eviction.
let state = {
  session: "logged_out",  // "logged_in" | "logged_out"
  activity: "عمل",         // "عمل" | "استراحة" — only meaningful while session === "logged_in"
  breakStartedAt: null,    // ms epoch — the CALCULATED idle-start moment, not the report time
  rawName: null,
  lastActivityAt: 0
};

let stateLoadPromise = null;

function loadState() {
  if (stateLoadPromise) return stateLoadPromise;
  stateLoadPromise = new Promise((resolve) => {
    chrome.storage.session.get([STORAGE_KEY], (data) => {
      if (data && data[STORAGE_KEY]) {
        state = Object.assign(state, data[STORAGE_KEY]);
      }
      resolve(state);
    });
  });
  return stateLoadPromise;
}

function saveState() {
  chrome.storage.session.set({ [STORAGE_KEY]: state });
}

async function pbCreate(collection, payload) {
  try {
    const res = await fetch(
      `${PB_BASE_URL}/api/collections/${collection}/records`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Api-Key": PB_API_KEY
        },
        body: JSON.stringify(payload)
      }
    );
    if (!res.ok) {
      console.error("[متابعة] bg pbCreate failed", collection, res.status);
    }
    return res.ok;
  } catch (e) {
    console.error("[متابعة] bg pbCreate error", collection, e);
    return false;
  }
}

function currentBadgeStatus() {
  return state.session === "logged_out" ? "مفصولة" : state.activity;
}

async function notifyContentTabs() {
  const status = currentBadgeStatus();
  const tabs = await chrome.tabs.query({ url: COMPANY_URL_PATTERNS });
  for (const tab of tabs) {
    chrome.tabs.sendMessage(
      tab.id,
      { type: "mutabaaStatus", status },
      () => {
        // No receiver yet (script still loading) — fine, ignore.
        void chrome.runtime.lastError;
      }
    );
  }
}

// ── SESSION (logged_in / logged_out) ────────────────────────────

async function startSession(rawName) {
  if (!rawName) return;
  await loadState();

  if (state.session === "logged_in" && state.rawName === rawName) {
    // Already tracking this same employee — nothing changed.
    return;
  }

  if (state.session === "logged_in" && state.rawName && state.rawName !== rawName) {
    // Shared PC: a different employee is now identified without an
    // explicit logout ever being seen for the previous one (e.g. the
    // login screen heuristic missed it). Close the old session out
    // rather than silently overwriting it.
    await endSession(state.rawName);
  }

  state.session = "logged_in";
  state.rawName = rawName;
  state.activity = "عمل";
  state.breakStartedAt = null;
  state.lastActivityAt = Date.now();
  saveState();

  await pbCreate("break_events", {
    rawName,
    type: "session_start",
    timestamp: Date.now()
  });

  notifyContentTabs();
}

async function endSession(rawNameOverride) {
  await loadState();
  const rawName = rawNameOverride || state.rawName;

  if (state.session === "logged_out" || !rawName) return;

  // Close out a dangling break rather than leaving a break_start with
  // no matching break_end.
  if (state.activity === "استراحة" && state.breakStartedAt) {
    await pbCreate("break_events", {
      rawName,
      type: "break_end",
      timestamp: Date.now(),
      breakStart: state.breakStartedAt,
      durationMs: Date.now() - state.breakStartedAt,
      reason: "session_end"
    });
  }

  state.session = "logged_out";
  state.activity = "عمل";
  state.breakStartedAt = null;
  saveState();

  await pbCreate("break_events", {
    rawName,
    type: "session_end",
    timestamp: Date.now()
  });

  notifyContentTabs();
}

// ── ACTIVITY (عمل / استراحة) ─────────────────────────────────────

async function onSystemIdle() {
  await loadState();
  if (state.session !== "logged_in") return; // nothing to track without a session
  if (state.activity === "استراحة") return;   // already on break

  // The event fires right as chrome.idle crosses BREAK_THRESHOLD_SEC
  // of no input, so the real idle start is ~threshold ago, not "now".
  const breakStart = Date.now() - BREAK_THRESHOLD_MS;

  state.activity = "استراحة";
  state.breakStartedAt = breakStart;
  saveState();

  await pbCreate("break_events", {
    rawName: state.rawName,
    type: "break_start",
    timestamp: Date.now(),
    breakStart,
    reason: "system_idle",
    thresholdMs: BREAK_THRESHOLD_MS
  });

  notifyContentTabs();
}

async function onSystemActive() {
  await loadState();
  state.lastActivityAt = Date.now();

  if (state.session !== "logged_in" || state.activity !== "استراحة") {
    saveState();
    return;
  }

  const breakStart = state.breakStartedAt;
  const now = Date.now();

  state.activity = "عمل";
  state.breakStartedAt = null;
  saveState();

  await pbCreate("break_events", {
    rawName: state.rawName,
    type: "break_end",
    timestamp: now,
    breakStart,
    durationMs: breakStart ? now - breakStart : 0,
    reason: "user_input"
  });

  notifyContentTabs();
}

// chrome.idle only ever reports "active", "idle", or "locked". A
// locked screen / sleeping PC has no input either, so it's treated
// exactly like "idle" — per the prompt, this must never be read as a
// logout, just as an activity gap.
chrome.idle.onStateChanged.addListener((newState) => {
  if (newState === "active") onSystemActive();
  else onSystemIdle(); // "idle" or "locked"
});

// ── MESSAGES FROM CONTENT SCRIPTS ───────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || !msg.type) return;

  if (msg.type === "mutabaaRawName" && msg.rawName) {
    startSession(msg.rawName);
  }

  if (msg.type === "mutabaaLoggedOut") {
    // Explicit evidence from the company system's own login screen —
    // the only thing allowed to end a session.
    endSession(msg.rawName || null);
  }

  if (msg.type === "mutabaaActivityPing") {
    // A real interaction was also seen directly inside a company tab.
    // Redundant with chrome.idle most of the time, but harmless and
    // catches the brief window right after an idle->active transition
    // before chrome.idle itself has re-queried.
    onSystemActive();
  }

  if (msg.type === "mutabaaRequestStatus" && sender.tab) {
    loadState().then(() => {
      chrome.tabs.sendMessage(
        sender.tab.id,
        { type: "mutabaaStatus", status: currentBadgeStatus() },
        () => { void chrome.runtime.lastError; }
      );
    });
  }
});

// ══════════════════════════════════════════════════════════════════
// بدالة (Yeastar PBX) AUTO-LOGIN RELAY
// ══════════════════════════════════════════════════════════════════
// Bridges content-badala.js (on the badala.html grid) and
// content-yeastar.js (on the PBX login page). Neither can talk to
// the other directly since they're different origins/tabs, so
// background.js holds the pending creds and remembers which tab (and
// window) is running the badala grid so a logout can be relayed back.
// Entirely independent of the activity/session engine above — it
// only shares this file as a message-routing hub.

const YEASTAR_URL = "https://192.168.9.30:8088/login";

const YEASTAR_STORAGE_KEY = "mutabaaYeastarRelayState";

let pendingYeastarCreds = null;   // { username, password } awaiting a login-page tab
let activeYeastarUsername = null; // username currently logged in on the Yeastar tab, if known

// Same MV3-eviction concern as the session/activity engine above: a plain
// `let` here would silently forget which line is actually logged in on
// the Yeastar tab the moment the service worker gets evicted, which is
// exactly what let the "already logged in — don't force logout" check
// below get skipped in practice. Persist it the same way.
let yeastarStateLoadPromise = null;
function loadYeastarRelayState() {
  if (yeastarStateLoadPromise) return yeastarStateLoadPromise;
  yeastarStateLoadPromise = new Promise((resolve) => {
    chrome.storage.session.get([YEASTAR_STORAGE_KEY], (data) => {
      const saved = data && data[YEASTAR_STORAGE_KEY];
      if (saved) {
        pendingYeastarCreds = saved.pendingYeastarCreds || null;
        activeYeastarUsername = saved.activeYeastarUsername || null;
      }
      resolve();
    });
  });
  return yeastarStateLoadPromise;
}

function saveYeastarRelayState() {
  chrome.storage.session.set({
    [YEASTAR_STORAGE_KEY]: { pendingYeastarCreds, activeYeastarUsername }
  });
}

loadYeastarRelayState();

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // 1. badala.html found "our" claimed line and its creds.
  if (msg && msg.type === "badalaClaimed") {
    loadYeastarRelayState().then(() => {
      console.log("[متابعة] bg received badalaClaimed", msg.lineNum, "from tab", sender.tab && sender.tab.id);

      chrome.tabs.query({ url: "https://192.168.9.30:8088/*" }, (tabs) => {
        // If this exact line is already the one logged in on the Yeastar
        // tab, there's nothing to do. This matters because
        // content-badala.js re-sends badalaClaimed every time its page
        // (re)loads and still sees ".line-card.mine" — e.g. the employee
        // just closed and reopened the mutabaa.online tab and logged back
        // in — even though the PBX session was never actually touched.
        // Force-logging-out here would kill a perfectly good session, and
        // since nothing re-fills+resubmits creds for an already-logged-in
        // tab, that would just strand the PBX on its login screen and
        // auto-release the line (needing "فتح البدالة" again).
        if (tabs.length > 0 && activeYeastarUsername && activeYeastarUsername === msg.username) {
          console.log("[متابعة] bg: line", msg.lineNum, "already active on Yeastar tab", tabs[0].id, "— skipping forceLogout");
          chrome.tabs.update(tabs[0].id, { active: true });
          if (tabs[0].windowId != null) chrome.windows.update(tabs[0].windowId, { focused: true });
          sendResponse({ ok: true, path: "already-active" });
          return;
        }

        pendingYeastarCreds = { username: msg.username, password: msg.password };
        saveYeastarRelayState();

        // Reuse an existing Yeastar tab if one's already open, else open
        // one. IMPORTANT: if that tab is still authenticated as a
        // DIFFERENT line, just navigating it to /login silently redirects
        // back to the dashboard (session cookie still valid) — the login
        // form never appears, so the new creds never get typed in, and
        // the extension looks "stuck" on the previous line. So force a
        // real logout first and let content-yeastar.js's forceLogout
        // handler pick up these freshly-set pendingYeastarCreds once the
        // login form actually shows.
        if (tabs.length > 0) {
          console.log("[متابعة] bg reusing existing Yeastar tab", tabs[0].id);
          chrome.tabs.update(tabs[0].id, { active: true });
          chrome.tabs.sendMessage(
            tabs[0].id,
            { type: "forceLogout" },
            () => { void chrome.runtime.lastError; }
          );
        } else {
          console.log("[متابعة] bg opening new Yeastar tab");
          chrome.tabs.create({ url: YEASTAR_URL });
        }
        sendResponse({ ok: true, path: "relogging-in" });
      });
    });
    return true;
  }

  // 2. content-yeastar.js, on load, asks if there are creds waiting for it.
  if (msg && msg.type === "yeastarRequestPendingCreds") {
    sendResponse({ pending: pendingYeastarCreds });
    return true;
  }

  // 3. Login succeeded — stop offering these creds to future loads
  //    (e.g. a manual refresh of an already-logged-in tab).
  if (msg && msg.type === "yeastarLoginSucceeded") {
    // Whichever creds we were trying to land are now the active session.
    // If pendingYeastarCreds is null, this is a tab that was simply
    // already logged in on its own (no relay-driven login happened) —
    // we don't know its username in that case, so leave whatever we had.
    if (pendingYeastarCreds) {
      activeYeastarUsername = pendingYeastarCreds.username;
    }
    pendingYeastarCreds = null;
    saveYeastarRelayState();
    return;
  }

  // 4. The PBX session ended (back on the login page after being
  //    logged in) — tell every open badala tab to release the line.
  // Broadcasting to all *://*.mutabaa.online/* tabs rather than a
  // single remembered tab id: that id was only ever an in-memory
  // variable, and background.js's service worker can be evicted and
  // restarted by MV3 at any point between a line being claimed and
  // the PBX session eventually ending, which would silently reset it
  // to null and drop this notification entirely.
  if (msg && msg.type === "yeastarLoggedOut") {
    pendingYeastarCreds = null;
    activeYeastarUsername = null;
    saveYeastarRelayState();
    chrome.tabs.query({ url: "*://*.mutabaa.online/*" }, (tabs) => {
      for (const tab of tabs) {
        chrome.tabs.sendMessage(
          tab.id,
          { type: "yeastarLoggedOut" },
          () => { void chrome.runtime.lastError; }
        );
      }
    });
    return;
  }

  // 5. The employee manually clicked "إغلاق البدالة" on the badala
  //    grid — tell every open Yeastar tab to actually log out of the
  //    PBX too (this is the reverse direction of #4 above).
  if (msg && msg.type === "badalaReleased") {
    console.log("[متابعة] bg received badalaReleased from tab", sender.tab && sender.tab.id);
    pendingYeastarCreds = null;
    activeYeastarUsername = null;
    saveYeastarRelayState();
    chrome.tabs.query({ url: "https://192.168.9.30:8088/*" }, (tabs) => {
      console.log("[متابعة] bg found", tabs.length, "yeastar tab(s) for forceLogout");
      for (const tab of tabs) {
        chrome.tabs.sendMessage(
          tab.id,
          { type: "forceLogout" },
          () => {
            if (chrome.runtime.lastError) {
              console.warn("[متابعة] forceLogout sendMessage error:", chrome.runtime.lastError.message);
            } else {
              console.log("[متابعة] forceLogout delivered to tab", tab.id);
            }
          }
        );
      }
    });
    return;
  }
});

loadState().then(() => {
  console.log("[متابعة] background service worker active", state);
});

// ══════════════════════════════════════════════════════════════════
// QUICK TICKET REOPEN — context menu
// ══════════════════════════════════════════════════════════════════
// Confirmed via DevTools Network tab (2026-09-14) that reopening a
// closed ticket is a single POST, so we skip تحليل التذاكر entirely:
//   POST https://prime-iq.com/myp/TicketsStaffReopenSRVL
//   Body: ticketIds=<رقم التذكرة>
// The actual fetch happens in process-content.js (it needs the page's
// own cookies/context); this just relays the click + selected text.
// ══════════════════════════════════════════════════════════════════

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "mutabaaQuickReopen",
    title: "إعادة فتح التذكرة (%s)",
    contexts: ["selection"]
  });

  chrome.contextMenus.create({
    id: "mutabaaQuickReopenPrompt",
    title: "إعادة فتح التذكرة...",
    contexts: ["page"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || !tab.id) return;

  if (info.menuItemId === "mutabaaQuickReopen") {
    chrome.tabs.sendMessage(tab.id, {
      type: "mutabaaReopenTicket",
      ticketId: (info.selectionText || "").trim()
    });
  } else if (info.menuItemId === "mutabaaQuickReopenPrompt") {
    chrome.tabs.sendMessage(tab.id, {
      type: "mutabaaReopenTicket",
      ticketId: null
    });
  }
});

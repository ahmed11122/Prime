// ══════════════════════════════════════════════════════════════════
// BACKUP / RESTORE of important local data
// ══════════════════════════════════════════════════════════════════
// Backs up only data that can't be recreated:
//   • procstate_*            per-order history records
//   • mutabaa_note_phrases   saved note phrases
//   • mutabaaRawName         employee name
// Skips caches, reload guards and session credentials.
// Saved as Downloads\mutabaa-backup\mutabaa-backup.json (overwritten).
// Optional: set BACKUP_URL to also POST the same JSON to a server.
// Loaded by both background.js (importScripts) and popup.html.
// ══════════════════════════════════════════════════════════════════
const MB_PREFIXES = ["procstate_"];
const MB_EXACT = ["mutabaa_note_phrases", "mutabaaRawName"];
const MB_BACKUP_ALARM = "mutabaaBackup";
const MB_BACKUP_HOURS = 6;
const MB_LAST_HASH_KEY = "mutabaaBackupLastHash";
const BACKUP_URL = ""; // e.g. "https://mutabaa.online/api/backup" (leave empty to disable)

function mbWanted(key) {
  return MB_EXACT.includes(key) || MB_PREFIXES.some((p) => key.startsWith(p));
}

async function mbCollect() {
  const all = await chrome.storage.local.get(null);
  const data = {};
  for (const k in all) if (mbWanted(k)) data[k] = all[k];
  return data;
}

function mbHash(str) {
  let h = 5381;
  for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
  return String(h);
}

function mbToDataUrl(str) {
  const bytes = new TextEncoder().encode(str);
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  }
  return "data:application/json;base64," + btoa(bin);
}

async function mbRunBackup(force) {
  const data = await mbCollect();
  if (!Object.keys(data).length) return { status: "empty" };
  const json = JSON.stringify({ app: "mutabaa", at: Date.now(), data });
  const hash = mbHash(JSON.stringify(data));
  const last = (await chrome.storage.local.get(MB_LAST_HASH_KEY))[MB_LAST_HASH_KEY];
  if (!force && last === hash) return { status: "unchanged" };

  try {
    await chrome.downloads.download({
      url: mbToDataUrl(json),
      filename: "mutabaa-backup/mutabaa-backup.json",
      conflictAction: "overwrite",
      saveAs: false
    });
  } catch (e) {
    return { status: "error", error: String(e) };
  }
  if (BACKUP_URL) {
    try {
      await fetch(BACKUP_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: json });
    } catch (e) { /* file backup already succeeded */ }
  }
  await chrome.storage.local.set({ [MB_LAST_HASH_KEY]: hash });
  return { status: "ok", count: Object.keys(data).length };
}

// Merge: never overwrite a newer local record with an older backup one.
async function mbRestore(parsed) {
  const data = parsed && parsed.app === "mutabaa" ? parsed.data : null;
  if (!data) return { status: "invalid" };
  const current = await chrome.storage.local.get(null);
  const toSet = {};
  for (const k in data) {
    if (!mbWanted(k)) continue;
    const cur = current[k];
    if (cur && cur.ts && data[k] && data[k].ts && cur.ts >= data[k].ts) continue;
    if (cur !== undefined && !(cur && cur.ts)) continue; // keep existing non-record values
    toSet[k] = data[k];
  }
  await chrome.storage.local.set(toSet);
  return { status: "ok", count: Object.keys(toSet).length };
}

// ══════════════════════════════════════════════════════════════════
// متابعة — مراقب الطلبات (Order Tracker Content Script)
// ══════════════════════════════════════════════════════════════════
// This extension no longer talks to Firebase at all. All order-mapping
// monitoring events (order_events / audit_events / break_events) go
// exclusively to PocketBase.
// ══════════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════════
// POCKETBASE (all monitoring telemetry)
// ══════════════════════════════════════════════════════════════════
//
// Point this at wherever PocketBase is reachable from the employee
// PCs: the machine's LAN IP (e.g. "http://192.168.1.50:8090") if
// PocketBase runs on one PC and is reached over the local network, or
// a domain/reverse-proxy URL if exposed over the internet (Phase 9).
// "http://127.0.0.1:8090" only works if the extension runs on the
// SAME PC as PocketBase.
const PB_BASE_URL = "https://api.mutabaa.online";

// Simple shared-secret header so random traffic can't write events.
// Set the same value in PocketBase's API rules (see pb_migrations/
// 1735300000_order_mapping_collections.js) — this is NOT strong
// security by itself, pair it with Phase 9 (no public admin UI, etc).
const PB_API_KEY = "cf98ce3b65462aba390b6de5d4922f7219c46b344e6ba1cc";

async function pbCreate(collection, payload) {
  try {
    const res = await fetch(
      `${PB_BASE_URL}/api/collections/${collection}/records`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Api-Key": PB_API_KEY
        },
        body: JSON.stringify(payload)
      }
    );

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      console.error(
        "[متابعة] PocketBase write failed",
        collection,
        res.status,
        text
      );
      return false;
    }

    return true;
  } catch (e) {
    console.error(
      "[متابعة] PocketBase write error",
      collection,
      e
    );
    return false;
  }
}

// Fire-and-forget variant for unload-time events, where we can't
// await a fetch. sendBeacon can't set custom headers, so the API key
// travels in the body instead; the PocketBase rule checks either.
function pbBeacon(collection, payload) {
  try {
    const body = new Blob(
      [JSON.stringify(Object.assign({ apiKey: PB_API_KEY }, payload))],
      { type: "application/json" }
    );
    navigator.sendBeacon(
      `${PB_BASE_URL}/api/collections/${collection}/records`,
      body
    );
  } catch (e) {
    console.error("[متابعة] PocketBase beacon error", collection, e);
  }
}

// ══════════════════════════════════════════════════════════════════
// EXTENSION-CONTEXT SAFETY
// ══════════════════════════════════════════════════════════════════
// After the extension is reloaded/updated (a new version pushed, or a
// manual reload in chrome://extensions), any tab that was already open
// keeps running its OLD copy of this content script. chrome.runtime
// still exists as an object on that stale script, but the connection
// behind it is dead — so chrome.runtime.sendMessage()/chrome.storage.*
// throw synchronously ("Extension context invalidated") the moment
// they're called. There's nothing to do about it besides not letting it
// surface as an uncaught error; it resolves itself once the tab reloads.
// All chrome.runtime/chrome.storage calls in this file should go
// through these wrappers instead of calling the API directly.
function safeSendMessage(message, callback) {
  if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.sendMessage) {
    return;
  }
  try {
    if (callback) {
      chrome.runtime.sendMessage(message, callback);
    } else {
      chrome.runtime.sendMessage(message);
    }
  } catch (e) {
    // stale/invalidated context — ignore
  }
}

function safeStorageGet(keys, callback) {
  if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) {
    callback({});
    return;
  }
  try {
    chrome.storage.local.get(keys, callback);
  } catch (e) {
    callback({});
  }
}

function safeStorageSet(items) {
  if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) {
    return;
  }
  try {
    chrome.storage.local.set(items);
  } catch (e) {
    // stale/invalidated context — ignore
  }
}

function safeStorageRemove(keys) {
  if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) {
    return;
  }
  try {
    chrome.storage.local.remove(keys);
  } catch (e) {
    // stale/invalidated context — ignore
  }
}

let lastOrderEndReportTs = 0;

// ══════════════════════════════════════════════════════════════════
// CROSS-FRAME RELAY
// ══════════════════════════════════════════════════════════════════
// The company system renders the actual work UI (bookmark tables,
// save forms, audit counters) inside same-origin iframes on some
// pages, not the top document. With "all_frames": true in the
// manifest, this script now runs inside those iframes too.
//
// Only ONE frame may own the idle timer / session / badge — the top
// frame, since the employee-name element (".user-box .user-name")
// only reliably lives there. If every frame ran its own independent
// idle timer, a frame with no activity in it (because the employee
// is working inside a *different* sibling iframe) would falsely
// report a break under the same name. So non-top frames still detect
// activity, order clicks, saved modals, and audit counts locally
// (that's where the real DOM is), but relay what they find up to the
// top frame instead of tracking their own state. These are
// same-origin iframes, so a direct function call on window.top works
// synchronously — no postMessage plumbing needed.
// ══════════════════════════════════════════════════════════════════

const IS_TOP_FRAME =
  window.top === window.self;

function getTopWindowSafe() {
  try {
    // Throws for a cross-origin top frame.
    void window.top.document;
    return window.top;
  } catch (e) {
    return null;
  }
}

function relayMarkActivity() {
  const top = getTopWindowSafe();
  if (top && typeof top.__mutabaaMarkActivity === "function") {
    top.__mutabaaMarkActivity();
  }
}

function dispatchOrderEvent(type, caseId) {
  if (IS_TOP_FRAME) {
    reportEvent(type, caseId);
    return;
  }
  const top = getTopWindowSafe();
  if (top && typeof top.__mutabaaReportEvent === "function") {
    top.__mutabaaReportEvent(type, caseId);
  }
}

function dispatchAuditSnapshot(count) {
  if (IS_TOP_FRAME) {
    reportAuditSnapshot(count);
    return;
  }
  const top = getTopWindowSafe();
  if (top && typeof top.__mutabaaReportAuditSnapshot === "function") {
    top.__mutabaaReportAuditSnapshot(count);
  }
}

if (IS_TOP_FRAME) {
  window.__mutabaaMarkActivity = () => markActivity();
  window.__mutabaaReportEvent = (type, caseId) => reportEvent(type, caseId);
  window.__mutabaaReportAuditSnapshot = (count) => reportAuditSnapshot(count);
}

// ══════════════════════════════════════════════════════════════════
// PRESENCE / BREAK TELEMETRY (break_events)
// ══════════════════════════════════════════════════════════════════
// Independent of order/audit activity — this is the only source of a
// real "آخر ظهور" on the dashboard that isn't just borrowed from an
// order save. Written from: a periodic heartbeat while the tab is
// visible and status is "عمل", the "عمل"/"استراحة" transitions relayed
// from background.js's idle timer, tab visibility changes, and the
// two genuinely reliable session edges (page load, explicit logout).

async function reportBreakEvent(type, extra, rawNameOverride) {
  const rawName = rawNameOverride || getRawEmployeeName();
  if (!rawName) return;

  const payload = Object.assign({
    rawName,
    type,
    timestamp: Date.now(),
    url: location.href
  }, extra || {});

  await pbCreate("break_events", payload);
}

// Fire-and-forget variant for the logout edge, where the tab is about
// to navigate to the login page — same reasoning as pbBeacon above.
function beaconBreakEvent(type, extra, rawNameOverride) {
  const rawName = rawNameOverride || getRawEmployeeName();
  if (!rawName) return;

  const payload = Object.assign({
    rawName,
    type,
    timestamp: Date.now(),
    url: location.href
  }, extra || {});

  pbBeacon("break_events", payload);
}

function dispatchBreakEvent(type, extra) {
  if (IS_TOP_FRAME) {
    reportBreakEvent(type, extra);
    return;
  }
  const top = getTopWindowSafe();
  if (top && typeof top.__mutabaaReportBreakEvent === "function") {
    top.__mutabaaReportBreakEvent(type, extra);
  }
}

if (IS_TOP_FRAME) {
  window.__mutabaaReportBreakEvent = (type, extra) => reportBreakEvent(type, extra);
}

// Tab visibility — separate from the idle/break concept: leaving the
// company tab (another window, another app) isn't necessarily a break,
// it's just not provable as work either. The dashboard already knows
// how to fold a brief or "proved working" hidden stretch back into
// work time; it just needs these raw markers to do that with.
if (IS_TOP_FRAME) {
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") {
      dispatchBreakEvent("tab_hidden", { hiddenAt: Date.now() });
    } else {
      dispatchBreakEvent("tab_visible");
    }
  });
}

// ── Get employee name ─────────────────────────────────────────────
//
// Some company pages (tickets, cases, chatbox popups) use a different
// header layout and don't render ".user-box .user-name" at all. If we
// only ever looked at the live DOM, those pages would never be able to
// identify the employee and would silently send zero activity — which
// is exactly why time spent on them looked like "off pc" instead of
// work. To fix that, the name is cached the moment it's found (e.g. on
// the home page) and reused as a fallback on pages that lack the
// element, as long as it isn't stale.
// ══════════════════════════════════════════════════════════════════

let cachedRawName = null;
let cachedRawNameAt = 0;

const CACHED_NAME_MAX_AGE_MS =
  12 * 60 * 60 * 1000; // 12h — long enough to span a full shift.

safeStorageGet(["mutabaaRawName", "mutabaaRawNameAt"], (data) => {
  if (data && data.mutabaaRawName) {
    cachedRawName = data.mutabaaRawName;
    cachedRawNameAt = data.mutabaaRawNameAt || 0;
  }
});

// The login screen (e.g. .../myp/LoginRedirected, or any page showing
// a password field with no logged-in header) means nobody is actually
// signed in on this tab/PC right now. Without this check,
// getRawEmployeeName() below would fall back to the *cached* name from
// whoever was last logged in on this machine (kept "fresh" for up to
// 12h) and the tracker would keep reporting that person as actively
// working even though they logged out and nobody logged back in.
function isLoginPage() {
  const path = location.pathname.toLowerCase();
  if (path.includes("loginredirect") || path.includes("/login")) {
    return true;
  }
  // Fallback heuristic for login-style pages that don't match the URL
  // pattern above: a visible password field with no user-name element
  // is only ever the login screen on this system.
  return !!document.querySelector('input[type="password"]');
}

function getRawEmployeeName() {
  if (isLoginPage()) {
    // Actively drop the cache instead of just skipping the fallback —
    // otherwise the next page that also lacks ".user-box .user-name"
    // (a popup, an iframe) would still pick the stale name back up.
    if (cachedRawName) {
      cachedRawName = null;
      cachedRawNameAt = 0;
      safeStorageRemove(["mutabaaRawName", "mutabaaRawNameAt"]);
    }
    return null;
  }

  const el = document.querySelector(".user-box .user-name");

  if (el) {
    const name = el.textContent.trim().split("/")[0].trim();

    if (name && name !== cachedRawName) {
      cachedRawName = name;
      cachedRawNameAt = Date.now();

      safeStorageSet({
        mutabaaRawName: name,
        mutabaaRawNameAt: cachedRawNameAt
      });

      safeSendMessage({ type: "mutabaaRawName", rawName: name });
    }

    return name;
  }

  // Fall back to the cached name only if it's fresh — an old cached
  // name from a previous employee's shift shouldn't leak into today.
  if (
    cachedRawName &&
    Date.now() - cachedRawNameAt < CACHED_NAME_MAX_AGE_MS
  ) {
    return cachedRawName;
  }

  return null;
}

// ══════════════════════════════════════════════════════════════════
// ORDER EVENTS
// ══════════════════════════════════════════════════════════════════

async function reportEvent(type, caseId) {

  // Prevent duplicate order_end events
  // from the same save confirmation.
  if (type === "order_end") {

    const now = Date.now();

    if (now - lastOrderEndReportTs < 1000) {
      return;
    }

    lastOrderEndReportTs = now;
  }

  const rawName = getRawEmployeeName();

  if (!rawName) {
    console.warn(
      "[متابعة] couldn't find employee name, skipping event"
    );
    return;
  }

  const payload = {
    rawName,
    type,
    timestamp: Date.now(),
    url: location.href
  };

  if (caseId) {
    payload.caseId = caseId;
  }

  const ok = await pbCreate("order_events", payload);

  if (ok) {
    console.log(
      "[متابعة] reported",
      type,
      "for",
      rawName
    );

    if (type === "order_end") {
      flashSaveBadge();
      refreshAuditSnapshotFromServer();
    }
  }
}

// ══════════════════════════════════════════════════════════════════
// AUDIT SNAPSHOT
// ══════════════════════════════════════════════════════════════════

async function reportAuditSnapshot(count) {

  if (!Number.isInteger(count)) {
    console.warn(
      "[متابعة] skipping audit report — count is not a number:",
      count
    );
    return;
  }

  const rawName = getRawEmployeeName();

  if (!rawName) return;

  const payload = {
    rawName,
    count,
    timestamp: Date.now(),
    url: location.href
  };

  const ok = await pbCreate("audit_events", payload);

  if (ok) {
    console.log(
      "[متابعة] reported audit count",
      count,
      "for",
      rawName
    );
  }
}

// ══════════════════════════════════════════════════════════════════
// FIND "تم تدقيقها" COUNT
// ══════════════════════════════════════════════════════════════════

function findStatCount(labelText) {

  const candidates =
    document.querySelectorAll("body *");

  for (const el of candidates) {

    if (el.children.length > 0) {
      continue;
    }

    const t =
      (el.textContent || "").trim();

    if (t !== labelText) {
      continue;
    }

    let container =
      el.parentElement;

    for (
      let hop = 0;
      hop < 3 && container;
      hop++
    ) {

      const leaves =
        container.querySelectorAll("*");

      for (const c of leaves) {

        if (c.children.length > 0) {
          continue;
        }

        const ct =
          (c.textContent || "").trim();

        if (/^\d+$/.test(ct)) {

          return parseInt(ct, 10);

        }
      }

      container =
        container.parentElement;
    }
  }

  return null;
}

// ══════════════════════════════════════════════════════════════════
// AUDIT COUNTER POLLING
// ══════════════════════════════════════════════════════════════════

let lastAuditCount = null;
let lastAuditCountRawName = null;
let pendingSuspiciousCount = null;
let lastReminderMilestone = 0;
let pendingNameChange = null;

// "تم تدقيقها" only ever climbs during a single employee's session.
// A shared PC where one employee logs out and another logs in can
// briefly show a stale or blank page — e.g. the counter reads 0 or 1
// for a moment while the page is still loading, or the username
// element momentarily returns something different than usual (empty,
// truncated, a loading placeholder). Trusting that instant as-is
// would falsely stamp a wrong, too-low count as the outgoing (or
// incoming) employee's real total in PocketBase. This guard only
// accepts a drop if: (a) the same *new* name is read on two
// consecutive polls (a real handover — one flaky read can't fake
// that), or (b) the same lower value is read twice in a row for the
// same name (a real reset/logout-login on the same account).
// Otherwise a single suspicious reading is held and ignored.
function acceptAuditCount(count) {

  const currentRawName = getRawEmployeeName();

  if (!currentRawName) {
    // Name element missing/blank this poll — don't treat this as
    // a handover or touch any state, just skip until it reappears.
    pendingNameChange = null;
    return false;
  }

  if (currentRawName !== lastAuditCountRawName) {

    if (
      pendingNameChange &&
      pendingNameChange.name === currentRawName
    ) {
      // Same new name confirmed on a second poll — genuine handover.
      pendingNameChange = null;
      pendingSuspiciousCount = null;
      lastAuditCount = count;
      lastAuditCountRawName = currentRawName;
      lastReminderMilestone = Math.floor(count / SAVE_REMINDER_EVERY) * SAVE_REMINDER_EVERY;
      dispatchAuditSnapshot(count);
      return true;
    }

    // First time seeing this name — hold it, don't act on it yet.
    pendingNameChange = { name: currentRawName, count };
    return false;
  }

  pendingNameChange = null;

  if (count === lastAuditCount) {
    pendingSuspiciousCount = null;
    return false;
  }

  if (lastAuditCount !== null && count < lastAuditCount) {
    if (pendingSuspiciousCount === count) {
      pendingSuspiciousCount = null;
      lastAuditCount = count;
      dispatchAuditSnapshot(count);
      return true;
    }
    pendingSuspiciousCount = count;
    return false;
  }

  pendingSuspiciousCount = null;
  lastAuditCount = count;
  dispatchAuditSnapshot(count);
  maybeShowSaveReminder(count);
  return true;
}

// ══════════════════════════════════════════════════════════════════
// SAVE REMINDER — nudge employees to press حفظ every N processed orders
// ══════════════════════════════════════════════════════════════════

const SAVE_REMINDER_EVERY = 10;

let reminderEl = null;
let reminderHideTimer = null;

function ensureReminderEl() {

  if (reminderEl) return reminderEl;

  reminderEl = document.createElement("div");

  reminderEl.style.cssText = `
    position: fixed;
    top: 16px;
    left: 50%;
    transform: translateX(-50%) translateY(-20px);
    z-index: 2147483647;
    background: #0b1f3a;
    color: #fff;
    font-family: Tahoma, Arial, sans-serif;
    font-size: 14px;
    font-weight: bold;
    padding: 12px 20px;
    border-radius: 12px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.25);
    direction: rtl;
    text-align: center;
    opacity: 0;
    pointer-events: none;
    transition: opacity .25s ease, transform .25s ease;
    max-width: 90vw;
  `;

  document.documentElement.appendChild(reminderEl);

  return reminderEl;
}

function showSaveReminder(text) {

  const el =
    ensureReminderEl();

  el.textContent =
    text;

  clearTimeout(
    reminderHideTimer
  );

  // Force a reflow so the transition re-triggers even if a reminder
  // is already visible when the next one arrives.
  el.style.transition =
    "none";
  el.style.opacity =
    "0";
  el.style.transform =
    "translateX(-50%) translateY(-20px)";

  requestAnimationFrame(() => {
    el.style.transition =
      "opacity .25s ease, transform .25s ease";
    el.style.opacity =
      "1";
    el.style.transform =
      "translateX(-50%) translateY(0)";
  });

  reminderHideTimer =
    setTimeout(
      () => {
        el.style.opacity =
          "0";
        el.style.transform =
          "translateX(-50%) translateY(-20px)";
      },
      6000
    );
}

function maybeShowSaveReminder(count) {

  if (
    count <= 0 ||
    count % SAVE_REMINDER_EVERY !== 0 ||
    count === lastReminderMilestone
  ) {
    return;
  }

  lastReminderMilestone =
    count;

  showSaveReminder(
    `🔔 تذكير: قم بالضغط على "حفظ" دائماً بعد إكمال ${SAVE_REMINDER_EVERY} طلبات لتجنب المشاكل`
  );
}

// NOTE: this used to skip audit tracking on pages it thought were a
// separate "supervisor review queue" that reused the "تم تدقيقها"
// label for a different, per-tab count. That distinct page doesn't
// actually exist — "تم تدقيقها" shows the same real per-employee
// count on every page, for every role — and the company's URL
// restructure (both the "CasesFollowUp" path segment and the
// "superVisiorsSearch" query param now appear on the normal ticket
// page too) made the old heuristics misfire and silently disable
// counting. Removed entirely; always count.
function checkAuditCount() {

  const count =
    findStatCount("تم تدقيقها");

  if (count === null) {
    return;
  }

  acceptAuditCount(count);
}

// ══════════════════════════════════════════════════════════════════
// BADGE / EMPLOYEE-FACING TRACKER STATUS
// ══════════════════════════════════════════════════════════════════

let badgeEl = null;
let badgeReturnTimer = null;
let updateBtnEl = null;

function ensureBadge() {

  if (badgeEl) return badgeEl;

  badgeEl = document.createElement("div");

  badgeEl.textContent =
    "متابعة نشطة";

  badgeEl.style.cssText = `
    position: fixed;
    bottom: 10px;
    left: 10px;
    z-index: 999999;
    background: #1d3f8f;
    color: #fff;
    font-family: Tahoma, Arial, sans-serif;
    font-size: 11px;
    padding: 5px 10px;
    border-radius: 8px;
    opacity: 0.72;
    pointer-events: none;
    direction: rtl;
    transition: opacity .2s ease;
  `;

  document.documentElement.appendChild(badgeEl);

  updateBtnEl = document.createElement("button");
  updateBtnEl.textContent = "تحديث";
  updateBtnEl.style.cssText = `
    position: fixed;
    top: 10px;
    left: 10px;
    z-index: 999999;
    background: #2563eb;
    color: #fff;
    font-family: Tahoma, Arial, sans-serif;
    font-size: 11px;
    padding: 5px 10px;
    border: none;
    border-radius: 8px;
    opacity: 0.72;
    cursor: pointer;
    pointer-events: auto;
    direction: rtl;
    transition: opacity .2s ease, background .2s ease;
  `;
  updateBtnEl.addEventListener("mouseenter", () => { updateBtnEl.style.opacity = "0.95"; });
  updateBtnEl.addEventListener("mouseleave", () => { updateBtnEl.style.opacity = "0.72"; });
  updateBtnEl.addEventListener("click", handleManualUpdateClick);

  document.documentElement.appendChild(updateBtnEl);

  return badgeEl;
}

// Manual "تحديث" click — asks background.js whether a newer version is
// already sitting on disk (downloaded earlier by mutabaa-updater.ps1)
// and, if so, reloads the EXTENSION only. This never reloads or
// touches the page itself.
function handleManualUpdateClick() {
  if (!updateBtnEl || updateBtnEl.dataset.busy === "1") return;
  updateBtnEl.dataset.busy = "1";
  const original = updateBtnEl.textContent;
  updateBtnEl.textContent = "...جارٍ التحقق";
  updateBtnEl.style.cursor = "default";

  safeSendMessage({ type: "mutabaaManualUpdateCheck" }, (res) => {
    const reset = (text, ms) => {
      updateBtnEl.textContent = text;
      setTimeout(() => {
        if (!updateBtnEl) return;
        updateBtnEl.textContent = original;
        updateBtnEl.style.cursor = "pointer";
        updateBtnEl.dataset.busy = "0";
      }, ms);
    };

    if (chrome.runtime.lastError || !res || res.status === "error") {
      reset("تعذر التحقق", 2500);
      return;
    }
    if (res.status === "upToDate") {
      reset("محدّثة ✓", 2000);
    } else if (res.status === "cooldown") {
      reset("انتظر قليلاً", 2500);
    } else if (res.status === "updating") {
      // Extension reloads itself right now; this button (and the whole
      // page's content script) will simply go stale until the page is
      // next navigated/refreshed — that's expected, nothing to reset to.
      updateBtnEl.textContent = "...جارٍ التحديث";
    }
  });
}

function setTrackerBadge(text, strong = false) {

  const b =
    ensureBadge();

  b.textContent =
    text;

  b.style.opacity =
    strong ? "0.95" : "0.72";
}

function restoreTrackerBadge() {

  clearTimeout(
    badgeReturnTimer
  );

  if (
    activityState === "مفصولة"
  ) {

    setTrackerBadge(
      "متابعة مفصولة"
    );

  } else if (
    activityState === "استراحة"
  ) {

    setTrackerBadge(
      "متابعة استراحة"
    );

  } else {

    setTrackerBadge(
      "متابعة نشطة"
    );

  }
}

function flashSaveBadge() {

  setTrackerBadge(
    "متابعة حفظ",
    true
  );

  clearTimeout(
    badgeReturnTimer
  );

  badgeReturnTimer =
    setTimeout(
      restoreTrackerBadge,
      2000
    );
}

// ══════════════════════════════════════════════════════════════════
// ACTIVITY / BREAK TRACKING
// ══════════════════════════════════════════════════════════════════
// background.js is now the single source of truth for active/break/
// disconnected, computed across ALL prime-iq.com tabs using
// chrome.idle + chrome.tabs (not just this document's own
// visibilityState). This script's job here is just:
//   1. tell background the employee name once we find it
//   2. ping background on real interaction
//   3. render whatever status background tells us to show
// activityState still exists (read by the debug hook and
// restoreTrackerBadge after a save-flash) but is now a mirror of
// what background last reported, not something we compute locally.
// ══════════════════════════════════════════════════════════════════

let activityState = "مفصولة";

const ACTIVITY_PING_THROTTLE_MS = 5 * 1000;
let lastActivityPingAt = 0;

function pingBackgroundActivity() {

  const now = Date.now();

  if (now - lastActivityPingAt < ACTIVITY_PING_THROTTLE_MS) {
    return;
  }

  lastActivityPingAt = now;

  safeSendMessage({ type: "mutabaaActivityPing" });
}

// Track meaningful browser activity. In an iframe this also relays up
// to the top frame so order-processing clicks inside a same-origin
// iframe still count (the iframe itself has no badge/messaging of its
// own to background).
function handleLocalActivity() {

  pingBackgroundActivity();

  if (!IS_TOP_FRAME) {
    relayMarkActivity();
  }
}

[
  "mousemove",
  "mousedown",
  "keydown",
  "scroll",
  "wheel",
  "touchstart"
].forEach((evt) => {

  window.addEventListener(
    evt,
    handleLocalActivity,
    {
      passive: true,
      capture: true
    }
  );

});

// markActivity() is still exposed for the iframe relay path
// (window.__mutabaaMarkActivity), it just pings background now
// instead of running its own timer.
function markActivity() {
  pingBackgroundActivity();
}

// ══════════════════════════════════════════════════════════════════
// STATUS FROM BACKGROUND
// ══════════════════════════════════════════════════════════════════

if (
  IS_TOP_FRAME &&
  typeof chrome !== "undefined" &&
  chrome.runtime &&
  chrome.runtime.onMessage
) {

  chrome.runtime.onMessage.addListener((msg) => {

    if (!msg || msg.type !== "mutabaaStatus") {
      return;
    }

    const previousActivityState = activityState;
    activityState = msg.status;

    if (msg.status === "عمل") {

      setTrackerBadge("متابعة نشطة");
      checkAuditCount();

      // Coming back from a calculated idle gap — this is the real
      // break_end signal (background.js's idle timer is the
      // authoritative source, not a guess from order/audit gaps).
      if (previousActivityState === "استراحة") {
        dispatchBreakEvent("break_end");
      }

    } else if (msg.status === "استراحة") {

      // "استراحة" هنا تعني "استراحة محتسبة بسبب عدم وجود نشاط
      // بالنظام لمدة 7 دقائق" — a calculated idle gap, not confirmed
      // proof of an official break. The badge stays short for space,
      // but that's the real meaning behind it. Only report the start
      // once per idle stretch, not on every repeated status message.
      setTrackerBadge("متابعة استراحة", true);

      if (previousActivityState !== "استراحة") {
        dispatchBreakEvent("break_start", { breakStart: Date.now() });
      }

    } else {

      // "مفصولة" only ever reflects an explicit logout reported by
      // background.js — never a closed tab, a hidden tab, or idle time.
      setTrackerBadge("متابعة مفصولة", true);

    }

  });

}

// ══════════════════════════════════════════════════════════════════
// SESSION END
// ══════════════════════════════════════════════════════════════════
// Per the redesign: closing Chrome, a crash, tab close, tab hidden,
// or loss of Chrome focus must NEVER be treated as proof of logout.
// There is deliberately no pagehide/beforeunload handler here anymore
// — background.js is the only place session_end gets written, and it
// only does so on the explicit "mutabaaLoggedOut" signal below.

// ══════════════════════════════════════════════════════════════════
// SESSION START / LOGOUT DETECTION
// ══════════════════════════════════════════════════════════════════

if (IS_TOP_FRAME) {

  if (isLoginPage()) {

    // Landed on the login screen — this is the one reliable, explicit
    // piece of evidence that the previous employee logged out. Grab
    // the name BEFORE getRawEmployeeName() wipes the cache below, so
    // background.js knows exactly whose session to close.
    const outgoingName = cachedRawName;
    getRawEmployeeName(); // triggers the cache wipe in isLoginPage() branch above

    safeSendMessage({
      type: "mutabaaLoggedOut",
      rawName: outgoingName || null
    });

    // Explicit logout is exactly the reliable edge this needs — write
    // session_end for the outgoing name before it's gone, via beacon
    // since this tab is on its way to the login screen right now.
    if (outgoingName) {
      beaconBreakEvent("session_end", {}, outgoingName);
    }

    activityState = "مفصولة";
    setTrackerBadge("متابعة مفصولة", true);

  } else {

    // Always report the identified employee once per load — not just
    // when the name changes — so background.js can re-establish the
    // session after a service-worker restart (its in-memory/session
    // state may have been reset even though this tab's cached name is
    // unchanged from before).
    const rawName = getRawEmployeeName();

    if (rawName) {
      safeSendMessage({ type: "mutabaaRawName", rawName });
      // A fresh load/reload is a real, provable "here" moment — worth
      // its own session_start regardless of whether the name changed.
      dispatchBreakEvent("session_start");
    }

    safeSendMessage({ type: "mutabaaRequestStatus" });

    pingBackgroundActivity();

    restoreTrackerBadge();

  }

}

// ══════════════════════════════════════════════════════════════════
// BFCACHE RESTORE
// ══════════════════════════════════════════════════════════════════
//
// Some in-page "reload" buttons (e.g. the company site's own refresh
// button, as opposed to Chrome's browser reload button) navigate in a
// way Chrome serves from the back-forward cache. bfcache restores do
// NOT re-run content scripts — document_idle only ever fires once, on
// the real first load — but pagehide still fires when leaving. That
// means a matching session_end goes out when the page is left, but no
// session_start ever follows it when it comes back, which otherwise
// permanently freezes that employee's tracked work time.
//
// pageshow fires on every load, including bfcache restores, and sets
// event.persisted = true only for the restore case — so we use it to
// manually replay the session-start step the content script would
// normally do on a real load.
// ══════════════════════════════════════════════════════════════════

if (IS_TOP_FRAME) {

  window.addEventListener(
    "pageshow",
    (event) => {

      if (event.persisted) {

        safeSendMessage({ type: "mutabaaRequestStatus" });

        lastActivityPingAt = 0; // force-allow an immediate ping here
        pingBackgroundActivity();

        restoreTrackerBadge();

      }

    }
  );

}

// ══════════════════════════════════════════════════════════════════
// SAVED MODAL DETECTION
// ══════════════════════════════════════════════════════════════════

const savedModalState =
  new WeakMap();

function isElementVisible(el) {

  if (
    !(el instanceof HTMLElement)
  ) {
    return false;
  }

  if (el.hidden) {
    return false;
  }

  if (
    el.getAttribute(
      "aria-hidden"
    ) === "true"
  ) {
    return false;
  }

  const style =
    getComputedStyle(el);

  return (
    style.display !== "none" &&
    style.visibility !== "hidden" &&
    style.opacity !== "0"
  );
}

// ══════════════════════════════════════════════════════════════════
// SCAN FOR SAVED MODAL
// ══════════════════════════════════════════════════════════════════

function scanNode(node) {

  if (
    !(node instanceof HTMLElement)
  ) {
    return;
  }

  const text =
    node.textContent || "";

  const looksLikeSavedModal =
    text.includes("Saved") &&
    text.includes("تم");

  if (!looksLikeSavedModal) {
    return;
  }

  const visible =
    isElementVisible(node);

  const wasVisible =
    savedModalState.get(node) === true;

  // Hidden → visible
  if (
    visible &&
    !wasVisible
  ) {

    savedModalState.set(
      node,
      true
    );

    dispatchOrderEvent(
      "order_end"
    );

  }

  // Visible → hidden
  else if (
    !visible &&
    wasVisible
  ) {

    savedModalState.set(
      node,
      false
    );

  }

  // First time seeing the element
  else if (
    !savedModalState.has(node)
  ) {

    savedModalState.set(
      node,
      visible
    );

    if (visible) {

      dispatchOrderEvent(
        "order_end"
      );

    }
  }
}

// ══════════════════════════════════════════════════════════════════
// ORDER START DETECTION
// ══════════════════════════════════════════════════════════════════
//
// The real event for starting work on a shipment is clicking the
// bookmark button in:
// "شحنات عملاء فرعي مطلوب تدقيقها"
//
// It executes:
// dotagBookMarkCase(caseId)
//
// and moves the order to:
// "تحت التدقيق"
//
// We use click delegation instead of trying to detect a fake modal.
// ══════════════════════════════════════════════════════════════════

document.addEventListener(
  "click",
  (e) => {

    const btn =
      e.target.closest(
        '[onclick*="dotagBookMarkCase"]'
      );

    if (!btn) return;

    const iconEl =
      btn.querySelector(
        '[id^="bookmark-case-"]'
      );

    const caseId =
      iconEl
        ? (
            iconEl.id.match(
              /bookmark-case-(\d+)/
            ) || []
          )[1]
        : (
            btn
              .getAttribute("onclick")
              .match(
                /dotagBookMarkCase\((\d+)\)/
              ) || []
          )[1];

    dispatchOrderEvent(
      "order_start",
      caseId || null
    );
  },
  true
);

// ══════════════════════════════════════════════════════════════════
// MUTATION OBSERVER
// ══════════════════════════════════════════════════════════════════

const observer =
  new MutationObserver(
    (mutations) => {

      for (
        const m of mutations
      ) {

        // New elements
        m.addedNodes.forEach(
          (n) => {

            scanNode(n);

            if (
              n instanceof HTMLElement
            ) {

              n
                .querySelectorAll("*")
                .forEach(
                  scanNode
                );

            }

          }
        );

        // Existing modal changing visibility
        if (
          m.type === "attributes" &&
          m.target instanceof HTMLElement
        ) {

          scanNode(
            m.target
          );

          m.target
            .querySelectorAll("*")
            .forEach(
              scanNode
            );

        }
      }
    }
  );

observer.observe(
  document.body,
  {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: [
      "class",
      "style",
      "hidden",
      "aria-hidden"
    ]
  }
);

// ══════════════════════════════════════════════════════════════════
// INITIALIZE
// ══════════════════════════════════════════════════════════════════

const AUDIT_BACKGROUND_REFRESH_MS = 60 * 1000;

if (IS_TOP_FRAME) {

  ensureBadge();

  checkAuditCount();

  setInterval(
    () => {
      if (document.visibilityState === "visible") {
        checkAuditCount();
      }
    },
    4000
  );

  // The company page's "تم تدقيقها" counter often only refreshes in
  // the DOM on a full navigation, not after an AJAX save.
  // checkAuditCount() above only ever sees the live DOM, so it can
  // miss saves that don't reload the page.
  // refreshAuditSnapshotFromServer() (defined further down) also
  // fetches a fresh copy of the page in the background and reads the
  // counter from that response instead. Previously this only ran
  // right after a detected "Saved" confirmation modal — if that text
  // heuristic doesn't match the company system's actual modal, an
  // employee could go a long time without the count (and "آخر تحديث")
  // updating at all. Polling it periodically as a fallback means it
  // stays current even when the modal isn't detected.
  setInterval(
    () => {
      if (document.visibilityState === "visible") {
        refreshAuditSnapshotFromServer();
      }
    },
    AUDIT_BACKGROUND_REFRESH_MS
  );

  // Heartbeat: the one signal that proves "still here" independent of
  // any order/audit save. Only sent while the tab is actually visible
  // and background.js's idle timer says "عمل" — a heartbeat during a
  // calculated break would defeat the point of tracking breaks at all.
  const HEARTBEAT_INTERVAL_MS = 60 * 1000;
  setInterval(
    () => {
      if (document.visibilityState === "visible" && activityState === "عمل") {
        dispatchBreakEvent("heartbeat");
      }
    },
    HEARTBEAT_INTERVAL_MS
  );

}

// ══════════════════════════════════════════════════════════════════
// LIVE "تم تدقيقها" REFRESH AFTER SAVE
// ══════════════════════════════════════════════════════════════════
//
// Employees can process many orders and press حفظ once.
//
// Example:
//
// 30 orders processed
//       ↓
// حفظ
//
// We must NOT treat حفظ as "1 completed order".
//
// Instead, after حفظ we try to read the company's actual
// "تم تدقيقها" counter.
//
// First try the current DOM.
// If that hasn't changed, request the current company page in the
// background and inspect the returned HTML.
//
// ══════════════════════════════════════════════════════════════════

function findStatCountInRoot(
  root,
  labelText
) {

  const candidates =
    root.querySelectorAll("*");

  for (
    const el of candidates
  ) {

    if (
      el.children.length > 0
    ) {
      continue;
    }

    const t =
      (el.textContent || "")
        .trim();

    if (
      t !== labelText
    ) {
      continue;
    }

    let container =
      el.parentElement;

    for (
      let hop = 0;
      hop < 4 &&
      container;
      hop++
    ) {

      const leaves =
        container.querySelectorAll("*");

      for (
        const c of leaves
      ) {

        if (
          c.children.length > 0
        ) {
          continue;
        }

        const ct =
          (c.textContent || "")
            .trim();

        if (
          /^\d+$/.test(ct)
        ) {

          return parseInt(
            ct,
            10
          );

        }
      }

      container =
        container.parentElement;
    }
  }

  return null;
}

async function refreshAuditSnapshotFromServer() {

  try {

    // Give the company system a moment to finish saving.
    await new Promise(
      resolve =>
        setTimeout(
          resolve,
          700
        )
    );

    // First check current page.
    const liveCount =
      findStatCount(
        "تم تدقيقها"
      );

    if (
      liveCount !== null &&
      liveCount !== lastAuditCount
    ) {

      if (acceptAuditCount(liveCount)) {
        return liveCount;
      }

    }

    // If the visible page didn't update,
    // request a fresh copy in the background.
    const res =
      await fetch(
        location.href,
        {
          method: "GET",
          credentials: "include",
          cache: "no-store"
        }
      );

    if (!res.ok) {
      return null;
    }

    const htmlText =
      await res.text();

    const parsed =
      new DOMParser()
        .parseFromString(
          htmlText,
          "text/html"
        );

    const serverCount =
      findStatCountInRoot(
        parsed,
        "تم تدقيقها"
      );

    if (
      serverCount !== null &&
      serverCount !== lastAuditCount
    ) {

      if (acceptAuditCount(serverCount)) {
        return serverCount;
      }

    }

  } catch (e) {

    console.warn(
      "[متابعة] live audit refresh failed",
      e
    );

  }

  return null;
}

// ══════════════════════════════════════════════════════════════════
// DONE
// ══════════════════════════════════════════════════════════════════

// ══════════════════════════════════════════════════════════════════
// DEBUG HOOK
// ══════════════════════════════════════════════════════════════════
// Exposes live internal state on window so it can be inspected from
// the page's console (top context) without switching context.
// Usage in DevTools console:
//   window.__mutabaaDebug.state         (mirrors background.js's status)
//   window.__mutabaaDebug.lastPingAt
//   window.__mutabaaDebug.badgeLabel
//   window.__mutabaaDebug.visibilityState
// For the authoritative idle/break timing, inspect background.js
// itself via chrome://extensions → متابعة → "service worker" console.
if (IS_TOP_FRAME) {

  window.__mutabaaDebug = {
    get state() {
      return activityState;
    },
    get lastPingAt() {
      return lastActivityPingAt
        ? new Date(lastActivityPingAt).toLocaleTimeString()
        : null;
    },
    get badgeLabel() {
      return badgeEl ? badgeEl.textContent : null;
    },
    get visibilityState() {
      return document.visibilityState;
    }
  };

}

// ══════════════════════════════════════════════════════════════════
// QUICK TICKET REOPEN — handles the background.js context menu click
// ══════════════════════════════════════════════════════════════════
// Lives here (not process-content.js) deliberately: process-content.js
// only loads on CasesFollowUp/etc. list pages, but this needs to work
// from ANY prime-iq.com page — including the chatbox popup, where the
// employee is most likely to already have the ticket number on screen.
//
// Confirmed via DevTools Network tab (2026-09-14): reopening a closed
// ticket is a single POST, no need to load تحليل التذاكر at all.
//   POST https://prime-iq.com/myp/TicketsStaffReopenSRVL
//   Content-Type: application/x-www-form-urlencoded
//   Body: ticketIds=<رقم التذكرة>   (the ticket number, NOT the receipt/order id)
// ══════════════════════════════════════════════════════════════════

const REOPEN_URL = "https://prime-iq.com/myp/TicketsStaffReopenSRVL";
const TICKET_ID_PATTERN = /^\d{5,}$/;

async function reopenTicket(ticketId) {
  try {
    const res = await fetch(REOPEN_URL, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: "ticketIds=" + encodeURIComponent(ticketId),
    });

    if (!res.ok) {
      alert("فشلت إعادة الفتح — رمز الخطأ: " + res.status);
      return;
    }

    const text = (await res.text()).trim();
    console.log("[متابعة] reopen response for", ticketId, ":", text);

    // The server response body hasn't been confirmed for a failure case
    // yet — this treats any 200 OK as success. If a ticket that SHOULD
    // fail (already open, no permission, etc.) still shows this success
    // alert, send the raw console-logged response text above and we'll
    // add a proper success/failure check here instead of trusting res.ok.
    alert("تم إرسال طلب إعادة فتح التذكرة رقم " + ticketId + " ✅");
  } catch (e) {
    console.error("[متابعة] reopenTicket error:", e);
    alert("حدث خطأ أثناء إعادة فتح التذكرة: " + e.message);
  }
}

if (
  typeof chrome !== "undefined" &&
  chrome.runtime &&
  chrome.runtime.onMessage
) {
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.type !== "mutabaaReopenTicket") return;

    let ticketId = msg.ticketId;

    if (!ticketId || !TICKET_ID_PATTERN.test(ticketId)) {
      ticketId = prompt("أدخل رقم التذكرة:");
    }

    if (!ticketId || !TICKET_ID_PATTERN.test(ticketId.trim())) {
      if (ticketId) alert("رقم التذكرة غير صالح.");
      return;
    }

    reopenTicket(ticketId.trim());
  });
}

// ══════════════════════════════════════════════════════════════════
// QUICK TICKET REOPEN — inline button (auto-detects ticket id)
// ══════════════════════════════════════════════════════════════════
// The right-click prompt flow above still works, but it can't know
// the ticket id unless text is selected first. This adds a small
// floating button on ticket pages that reads the id straight from
// the page URL (?chatTicketId=...) and just asks for confirmation.
// ══════════════════════════════════════════════════════════════════

function getTicketIdFromPage() {
  const url = new URL(location.href);
  const fromParam = url.searchParams.get("chatTicketId");
  if (fromParam && TICKET_ID_PATTERN.test(fromParam)) return fromParam;
  return null; // add more fallbacks here once we know where else the id shows up
}

// ── Status check ─────────────────────────────────────────────────
// Confirmed via DevTools (2026-09-15): searching by ticket number on
// the AllTickets page is a POST to this same URL with tkt_id set and
// the other search fields blank. The response is the same results
// table, and a yellow "قيد المعالجة" cell in the الحالة column means
// the ticket is currently open. We don't yet know what other status
// text values mean, so only that exact text is treated as a
// confirmed "open" signal.
const REOPEN_STATUS_URL = "https://prime-iq.com/myp/Mainctrl/tickets/AllTickets?filter=1";
const KNOWN_OPEN_STATUS_TEXT = ["قيد المعالجة"];

async function fetchTicketStatus(ticketId) {
  const body = new URLSearchParams({
    tkt_id: ticketId,
    tkt_priority: "",
    tkt_relatedagent: "",
    c_custreceiptnoori: "",
    tkt_status: "",
    mcust_name: "",
    cust_name: "",
    tkt_assigned_level: "",
    fromdate: "",
    todate: "",
    chat_otherparty_assigned_emp: "",
    myClassBean: "com.app.tickets.ShowAllTickets",
    dosearch: "Search"
  });

  let res;
  try {
    res = await fetch(REOPEN_STATUS_URL, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: body.toString()
    });
  } catch (e) {
    return null; // network error — don't block the button on this
  }
  if (!res.ok) return null;

  const html = await res.text();
  const doc = new DOMParser().parseFromString(html, "text/html");
  const table = doc.querySelector('table[id^="smarty_table_com_dot_app_dot_tickets"]');
  if (!table) return null;

  const rows = table.querySelectorAll("tbody tr");
  for (const row of rows) {
    const cells = row.querySelectorAll("td");
    if (cells.length < 4) continue;
    const rowTicketId = (cells[1].textContent || "").replace(/[^\d]/g, ""); // رقم التذكرة column
    if (rowTicketId !== String(ticketId)) continue;
    return (cells[3].textContent || "").trim(); // الحالة column
  }
  return null; // ticket not in this list — could be closed, could just be on another page/filter
}

// ── Fallback: chat-log heuristic ────────────────────────────────
// There's no separate "is this ticket open/closed" element on the
// page to read, but every close/reopen action already gets logged
// as a chat bubble right in this same chatbox (e.g. "أغلق التذكرة",
// "إعادة فتح التذكرة"). So: scan the chat log for the most recent
// one of those two event bubbles and use it as the current status.
// This is a heuristic based on wording seen on 2026-09-14 — if the
// system ever logs the close/reopen event with different wording,
// this stops detecting it and just falls back to "unknown" (button
// still works, just skips the already-open check).
function getLastTicketStatusEvent() {
  const CLOSE_MARK = "أغلق التذكرة";
  const REOPEN_MARK = "فتح التذكرة"; // matches both "فتح التذكرة" and "إعادة فتح التذكرة"
  const hits = [];

  document.querySelectorAll("body *").forEach((el) => {
    if (el.id === "mutabaaInlineReopenBtn") return; // ignore our own button's label
    if (el.children.length > 0) return; // leaf nodes only — skip wrapper divs
    const text = (el.textContent || "").trim();
    if (!text) return;
    if (text.includes(CLOSE_MARK)) {
      hits.push({ type: "closed", el });
    } else if (text.includes(REOPEN_MARK)) {
      hits.push({ type: "open", el });
    }
  });

  if (hits.length === 0) return null; // no event found → unknown, don't block

  // Chat renders chronologically top-to-bottom, so the last one in
  // document order is the most recent event.
  hits.sort((a, b) =>
    a.el.compareDocumentPosition(b.el) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1
  );
  return hits[hits.length - 1].type;
}

function injectReopenButton() {
  const ticketId = getTicketIdFromPage();
  const existing = document.getElementById("mutabaaInlineReopenBtn");

  if (!ticketId) {
    if (existing) existing.remove(); // id changed / no longer on a ticket
    return;
  }
  if (existing && existing.dataset.ticketId === ticketId) return; // already showing for this ticket

  if (existing) existing.remove();

  const btn = document.createElement("button");
  btn.id = "mutabaaInlineReopenBtn";
  btn.dataset.ticketId = ticketId;
  btn.textContent = "إعادة فتح التذكرة";
  btn.style.cssText = `
    position: fixed;
    bottom: 8px;
    right: 8px;
    z-index: 999999;
    background: #d97706;
    color: #fff;
    border: none;
    border-radius: 6px;
    padding: 6px 14px;
    font-size: 13px;
    font-family: inherit;
    cursor: pointer;
    box-shadow: 0 2px 6px rgba(0,0,0,0.35);
  `;
  btn.onclick = async () => {
    btn.disabled = true;
    const originalText = btn.textContent;
    btn.textContent = "...جارِ التحقق";

    let isOpen = false;
    const liveStatus = await fetchTicketStatus(ticketId);
    if (liveStatus) {
      isOpen = KNOWN_OPEN_STATUS_TEXT.includes(liveStatus);
    } else {
      // couldn't reach/parse the live status — fall back to the chat log
      isOpen = getLastTicketStatusEvent() === "open";
    }

    btn.disabled = false;
    btn.textContent = originalText;

    if (isOpen) {
      alert("التذكرة رقم " + ticketId + " مفتوحة بالفعل — لا حاجة لإعادة فتحها.");
      return;
    }
    if (confirm("إعادة فتح التذكرة رقم " + ticketId + "؟")) {
      reopenTicket(ticketId);
    }
  };
  document.body.appendChild(btn);
}

if (location.pathname.includes("/myp/Mainctrl/tickets/")) {
  injectReopenButton();
  // ticket id shows up in the URL after the SPA finishes routing, and the
  // chatbox can be reopened for a different ticket without a full reload
  new MutationObserver(injectReopenButton).observe(document.documentElement, {
    childList: true,
    subtree: true
  });
  window.addEventListener("popstate", injectReopenButton);
}

console.log(
  "[متابعة] order tracker active"
);
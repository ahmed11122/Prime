// content-time-format.js
// Converts a 24-hour time to 12-hour AM/PM only when the user selects it
// (double-click, or click-drag to highlight). No page scanning, no
// MutationObserver, no background work — this only ever runs in response
// to a mouseup after a selection, so it costs nothing until used.
//
// Display text only: it rewrites the text node under the selection, so it
// never touches <input>, <textarea>, <select>, or contenteditable elements
// (checked below), meaning date/time pickers and anything the site reads
// back out of a field are untouched.
(function () {
  "use strict";

  const SKIP_TAGS = new Set(["INPUT", "TEXTAREA", "SELECT", "OPTION"]);

  // Exact match only — the whole selection must be just "HH:MM" or
  // "HH:MM:SS", nothing else, so selecting a time by itself (e.g. via
  // double-click-drag) converts, but selecting a sentence that happens to
  // contain a time does not.
  const FULL_TIME_RE = /^([01]?\d|2[0-3]):([0-5]\d)(:[0-5]\d)?$/;

  function to12Hour(hourStr, minuteStr, secGroup) {
    const hour = parseInt(hourStr, 10);
    const suffix = hour >= 12 ? "PM" : "AM";
    let hour12 = hour % 12;
    if (hour12 === 0) hour12 = 12;
    const seconds = secGroup || "";
    return `${hour12}:${minuteStr}${seconds} ${suffix}`;
  }

  function isEditableContext(node) {
    let el = node.nodeType === 1 ? node : node.parentElement;
    while (el) {
      if (SKIP_TAGS.has(el.tagName)) return true;
      if (el.isContentEditable) return true;
      el = el.parentElement;
    }
    return false;
  }

  function handleSelection() {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || selection.rangeCount === 0) {
      return;
    }

    const range = selection.getRangeAt(0);
    if (isEditableContext(range.startContainer)) return;

    const rawText = selection.toString();
    const trimmed = rawText.trim();
    const match = trimmed.match(FULL_TIME_RE);
    if (!match) return;

    // The selection is allowed to have extra leading/trailing whitespace
    // (people don't always drag-select pixel-perfectly), but the RANGE
    // itself still covers that whitespace. If we deleteContents() on the
    // untrimmed range, that whitespace — which is usually the only thing
    // separating the time from whatever comes right after it, like a date
    // — gets deleted too, and the converted time ends up jammed straight
    // up against the next value with nothing between them.
    //
    // So: if there's extra whitespace, shrink the range inward to cover
    // only the matched "HH:MM(:SS)" text before touching the DOM. This is
    // only safe to do automatically when the selection is a single text
    // node (the common case); if it spans multiple nodes we can't safely
    // guess where to trim, so we do nothing rather than risk corrupting
    // the surrounding text — user can just reselect more precisely.
    if (rawText !== trimmed) {
      const sameNode =
        range.startContainer === range.endContainer &&
        range.startContainer.nodeType === Node.TEXT_NODE;
      if (!sameNode) return;

      const leadTrim = rawText.length - rawText.replace(/^\s+/, "").length;
      const trailTrim = rawText.length - rawText.replace(/\s+$/, "").length;
      range.setStart(range.startContainer, range.startOffset + leadTrim);
      range.setEnd(range.endContainer, range.endOffset - trailTrim);
    }

    const converted = to12Hour(match[1], match[2], match[3]);

    range.deleteContents();
    const textNode = document.createTextNode(converted);
    range.insertNode(textNode);

    // Leave the newly-converted text selected/highlighted so the change is
    // visible, and so a repeat action (e.g. accidental re-trigger) sees
    // "HH:MM AM/PM" which no longer matches FULL_TIME_RE.
    const newRange = document.createRange();
    newRange.selectNode(textNode);
    selection.removeAllRanges();
    selection.addRange(newRange);
  }

  document.addEventListener("mouseup", handleSelection);
})();

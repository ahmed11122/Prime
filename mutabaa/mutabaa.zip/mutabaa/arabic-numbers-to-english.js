// arabic-numbers-to-english.js
// -----------------------------------------------------------------------
// Purpose: automatically convert any Arabic-Indic (٠١٢٣٤٥٦٧٨٩) or
// Extended Arabic-Indic / Persian (۰۱۲۳۴۵۶۷۸۹) digits found anywhere on
// the page into plain English/Western digits (0123456789), and keep doing
// it as new content loads (AJAX-rendered tables, smarty rows, etc.).
//
// Strategy:
//   1. Walk all text nodes in the document and replace Arabic-Indic /
//      Persian digits with their Western equivalents.
//   2. Also patch <input>/<textarea> values, so numbers typed or filled
//      into fields are normalized (on "input"/"change" and while typing).
//   3. Watch the DOM with a MutationObserver so rows added later (AJAX
//      tables, smarty grids, popups, etc.) get converted too.
//   4. Debounced + guarded against re-processing our own mutations, so it
//      won't loop or cause perf issues on large/frequently-updated tables.
// -----------------------------------------------------------------------

(function () {
  "use strict";

  // Arabic-Indic (used in most Arabic contexts) and Extended Arabic-Indic
  // (Persian/Urdu locales) digit maps -> Western 0-9.
  const DIGIT_MAP = {
    // Arabic-Indic
    "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4",
    "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9",
    // Extended Arabic-Indic (Persian)
    "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4",
    "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9",
  };

  const DIGIT_REGEX = /[٠-٩۰-۹]/g;

  function convertString(str) {
    if (!str) return str;
    return str.replace(DIGIT_REGEX, (ch) => DIGIT_MAP[ch] || ch);
  }

  function hasArabicDigits(str) {
    return !!str && DIGIT_REGEX.test(str);
  }

  // Tags whose text content we should never touch (scripts/styles etc.)
  const SKIP_TAGS = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "INPUT"]);

  // -----------------------------------------------------------------------
  // Text node conversion
  // -----------------------------------------------------------------------

  function convertTextNode(node) {
    const parentTag = node.parentNode && node.parentNode.nodeName;
    if (parentTag && SKIP_TAGS.has(parentTag)) return;
    if (hasArabicDigits(node.nodeValue)) {
      node.nodeValue = convertString(node.nodeValue);
    }
  }

  function walkAndConvert(root) {
    // If root itself is a text node.
    if (root.nodeType === Node.TEXT_NODE) {
      convertTextNode(root);
      return;
    }
    if (root.nodeType !== Node.ELEMENT_NODE && root.nodeType !== Node.DOCUMENT_NODE) {
      return;
    }

    const walker = document.createTreeWalker(
      root,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const parentTag = node.parentNode && node.parentNode.nodeName;
          if (parentTag && SKIP_TAGS.has(parentTag)) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        },
      }
    );

    const textNodes = [];
    let n;
    while ((n = walker.nextNode())) textNodes.push(n);
    textNodes.forEach(convertTextNode);

    // Also handle input/textarea values, and common attributes that show
    // numbers to the user (placeholder, value, title, aria-label).
    const fields = root.querySelectorAll
      ? root.querySelectorAll("input, textarea")
      : [];
    fields.forEach(convertFieldValue);

    const attrCarriers = root.querySelectorAll
      ? root.querySelectorAll("[placeholder], [title], [aria-label]")
      : [];
    attrCarriers.forEach(convertAttrs);
  }

  function convertFieldValue(el) {
    if (hasArabicDigits(el.value)) {
      const start = el.selectionStart;
      const end = el.selectionEnd;
      el.value = convertString(el.value);
      // Best-effort cursor restore (same length, so indices stay valid).
      if (start != null && end != null && typeof el.setSelectionRange === "function") {
        try {
          el.setSelectionRange(start, end);
        } catch (e) {
          /* ignore fields that don't support selection ranges */
        }
      }
    }
  }

  function convertAttrs(el) {
    ["placeholder", "title", "aria-label"].forEach((attr) => {
      const v = el.getAttribute(attr);
      if (hasArabicDigits(v)) {
        el.setAttribute(attr, convertString(v));
      }
    });
  }

  // -----------------------------------------------------------------------
  // Live typing: convert as the user types into any input/textarea.
  // -----------------------------------------------------------------------

  function onLiveInput(e) {
    const el = e.target;
    if (!el || (el.tagName !== "INPUT" && el.tagName !== "TEXTAREA")) return;
    convertFieldValue(el);
  }

  document.addEventListener("input", onLiveInput, true);
  document.addEventListener("change", onLiveInput, true);

  // -----------------------------------------------------------------------
  // Initial pass + MutationObserver for dynamically loaded content.
  // -----------------------------------------------------------------------

  let scheduled = false;
  let pendingRoots = new Set();

  function flush() {
    scheduled = false;
    const roots = Array.from(pendingRoots);
    pendingRoots.clear();
    roots.forEach((root) => {
      try {
        walkAndConvert(root);
      } catch (e) {
        /* ignore detached nodes */
      }
    });
  }

  function scheduleConversion(root) {
    pendingRoots.add(root);
    if (!scheduled) {
      scheduled = true;
      // Debounce with rAF/timeout so rapid AJAX table rebuilds only trigger
      // one pass instead of one per mutation.
      setTimeout(flush, 50);
    }
  }

  function init() {
    walkAndConvert(document.body);

    const observer = new MutationObserver((mutations) => {
      for (const m of mutations) {
        if (m.type === "characterData" && m.target) {
          convertTextNode(m.target);
          continue;
        }
        if (m.addedNodes && m.addedNodes.length) {
          m.addedNodes.forEach((node) => {
            if (node.nodeType === Node.ELEMENT_NODE || node.nodeType === Node.TEXT_NODE) {
              scheduleConversion(node);
            }
          });
        }
        if (m.type === "attributes" && m.target && m.target.nodeType === Node.ELEMENT_NODE) {
          if (["placeholder", "title", "aria-label", "value"].includes(m.attributeName)) {
            if (m.attributeName === "value" && (m.target.tagName === "INPUT" || m.target.tagName === "TEXTAREA")) {
              convertFieldValue(m.target);
            } else {
              convertAttrs(m.target);
            }
          }
        }
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ["placeholder", "title", "aria-label", "value"],
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();

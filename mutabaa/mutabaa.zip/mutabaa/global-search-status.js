// global-search-status.js
// -----------------------------------------------------------------------
// Purpose: on prime-iq.com's global search results page (the card grid you
// get from searching a phone number / رقم وصل), show each card's current
// status and — if it's "الواصل - شحنات سلمت بنجاح" — the date it changed
// to that status, WITHOUT having to click "تفاصيل الشحنة" into every card.
//
// How: for each card, read the auditcaseid/auditreceiptnoori out of its
// "تفاصيل الشحنة" link, fetch that detail page in the background (same-origin,
// so a plain fetch with credentials works), and parse:
//   1. the current status badge (span.badge inside the ".col-3" block at the
//      top of the page) -> the status text itself.
//   2. table[id*="AuditTrailPopUp"] -> the row matching that status text,
//      to pull the date/time it was set.
// Results are cached per auditcaseid for the life of the tab so re-renders
// (pagination, filtering) don't re-fetch every card again.
// -----------------------------------------------------------------------

(function () {
  "use strict";

  if (!location.pathname.includes("displayGlobalSearchResults")) return;

  console.log("[متابعة-status] global-search-status.js loaded on:", location.href);

  const DELIVERED_MARKER = "سلمت بنجاح"; // substring shared by "الواصل - شحنات سلمت بنجاح"
  const TURQUOISE_MARKER = "قيد المراجعة"; // "عند المندوب - قيد المراجعة"
  const RED_MARKERS = ["تعذر التوصيل", "الراجع"];
  const DATE_PATTERN = /\d{2}\/\d{2}\/\d{4}\s+\d{2}:\d{2}:\d{2}/;
  const DETAIL_URL_BASE = `${location.origin}/myp/Mainctrl/cases/displaySingleCaseInfo`;
  const ITEM_DETAILS_URL_BASE = `${location.origin}/myp/Mainctrl/cases/itemDetails`;

  // Colors per status category — checked in this order (delivered wins over
  // everything, then turquoise/red, everything else falls back to amber).
  const STATUS_COLORS = {
    delivered: "#166534", // green
    turquoise: "#0d9488",
    red: "rgb(107, 7, 7)",
    other: "#92400e", // amber
  };

  function classifyStatus(statusText) {
    const n = normalize(statusText);
    if (n.includes(normalize(DELIVERED_MARKER))) return "delivered";
    if (RED_MARKERS.some((m) => n.includes(normalize(m)))) return "red";
    if (n.includes(normalize(TURQUOISE_MARKER))) return "turquoise";
    return "other";
  }

  // auditCaseId -> "pending" | { statusText, delivered, date } | "error"
  const statusCache = new Map();

  function normalize(str) {
    return String(str || "").replace(/[أإآ]/g, "ا").replace(/\s+/g, " ").trim();
  }

  // ---- find + parse cards --------------------------------------------

  function getCaseLink(cardBody) {
    return cardBody.querySelector('a[href*="displaySingleCaseInfo"][href*="auditcaseid"]');
  }

  function extractIdsFromLink(link) {
    try {
      const url = new URL(link.getAttribute("href"), location.href);
      const auditcaseid = url.searchParams.get("auditcaseid");
      const auditreceiptnoori = url.searchParams.get("auditreceiptnoori");
      if (!auditcaseid) return null;
      return { auditcaseid, auditreceiptnoori };
    } catch (e) {
      return null;
    }
  }

  function findCardBodies() {
    return Array.from(document.querySelectorAll("div.card-body")).filter(
      (cb) => getCaseLink(cb) != null
    );
  }

  // ---- fetch + parse the detail page -----------------------------------

  function extractCurrentStatusText(doc) {
    // The badges live in the small ".col-3" block near the top of the page
    // (see screenshot: green "الواصل - شحنات سلمت بنجاح" badge + an empty
    // red "bg-danger" badge next to it). Take the first badge with real text.
    const badges = doc.querySelectorAll(".col-3 .badge, span.badge");
    for (const b of badges) {
      const text = normalize(b.textContent);
      if (text) return text;
    }
    return null;
  }

  function findHeaderIndex(table, matchesLabel) {
    const headerCells = table.querySelectorAll(
      "thead th, tr:first-child th, tr:first-child td"
    );
    let index = -1;
    headerCells.forEach((th, i) => {
      const clean = th.textContent.replace(/\s+/g, " ").trim();
      if (index === -1 && matchesLabel(clean)) index = i;
    });
    return index;
  }

  // تتبع التغيرات (table[id*="DisplaySingleCaseMoreInfo"]) logs every field
  // edit (تأجيل/سبب الإرجاع/etc.) separately, without the plain-language
  // status label that the audit trail shows. The two tables aren't linked
  // by any id — they're only linked by being logged in the same second. So:
  // collect every تتبع التغيرات row's [تاريخ -> value], then for a given
  // status row's timestamp, pull every change-log row stamped with that
  // exact same timestamp and fold their values into one reason string.
  function parseChangesLog(doc) {
    const table = doc.querySelector('table[id*="DisplaySingleCaseMoreInfo"]');
    if (!table) return [];

    const tagIdx = findHeaderIndex(table, (c) => c.includes("العامود"));
    const dateIdx = findHeaderIndex(table, (c) => c.includes("التاريخ") || c.includes("الوقت"));
    // "القيمة" matches both قبل/بعد columns — exclude "قبل" so we land on
    // "القيمة بعد التعديل" (the new value), not the old one.
    const valueIdx = findHeaderIndex(
      table,
      (c) => c.includes("القيمة") && !c.includes("قبل")
    );

    const rows = Array.from(table.querySelectorAll("tbody tr"));
    return rows
      .map((r) => {
        const cells = Array.from(r.querySelectorAll("td"));
        return {
          date: dateIdx > -1 ? (cells[dateIdx]?.textContent || "").replace(/\s+/g, " ").trim() : "",
          tag: tagIdx > -1 ? (cells[tagIdx]?.textContent || "").replace(/\s+/g, " ").trim() : "",
          value: valueIdx > -1 ? (cells[valueIdx]?.textContent || "").replace(/\s+/g, " ").trim() : "",
        };
      })
      .filter((r) => r.date);
  }

  // Some change-log rows carry no real information — e.g. "خيار التأجيل" on
  // its own just means "the تأجيل field was touched", not that a postponement
  // actually happened. Drop those so the reason line only shows the parts
  // that actually say something (تعذر التوصيل - لم يرد, etc).
  const NOISE_REASON_VALUES = new Set(["خيار التأجيل"]);

  // Shorten the wording to match how it's normally written/spoken, e.g.
  // "تعذر التوصيل" -> "تعذر توصيل". Applied to both the status label and
  // the joined reason so every status gets the same compact treatment.
  function shorten(text) {
    if (!text) return text;
    return text.replace(/تعذر التوصيل/g, "تعذر توصيل").trim();
  }

  function buildReasonForTimestamp(changesLog, ts) {
    if (!ts) return null;
    const parts = [];
    const seen = new Set();
    changesLog.forEach((c) => {
      if (c.date !== ts) return;
      const text = c.value || c.tag;
      if (!text || NOISE_REASON_VALUES.has(text)) return;
      if (!seen.has(text)) {
        seen.add(text);
        parts.push(shorten(text));
      }
    });
    return parts.length ? parts.join(" - ") : null;
  }

  // ---- نوع البضاعة (item type) — ported from process-content.js's
  // resolveItemTypeFromDoc/fetchItemTypesFromDetailsPage. Usually the value
  // sits right in the case page (smarty_singledispalycol container), but for
  // multi-item cases that cell just holds a "تفاصيل" button instead of the
  // value, which means a second fetch to itemDetails is needed to read it
  // out of that page's table.
  const ITEM_TYPE_FIELD_SUFFIX = "itemsdetails";
  const STORE_NAME_FIELD_SUFFIX = "cust_name";
  const DETAILS_LABELS = new Set(["تفاصيل", "التفاصيل"]);

  function isDetailsButtonCell(valueCell) {
    const cellText = valueCell.textContent.replace(/\s+/g, " ").trim();
    return DETAILS_LABELS.has(cellText);
  }

  async function fetchItemTypesFromDetailsPage(auditCaseId) {
    try {
      const url = `${ITEM_DETAILS_URL_BASE}?auditcaseid=${encodeURIComponent(auditCaseId)}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) return null;

      const html = await res.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const table = doc.querySelector("table");
      if (!table) return null;

      const headerCells = table.querySelectorAll("thead th");
      let typeIndex = -1;
      headerCells.forEach((th, i) => {
        if (typeIndex === -1 && th.textContent.includes("نوع البضاعة")) {
          typeIndex = i;
        }
      });
      if (typeIndex === -1) return null;

      const rows = table.querySelectorAll("tbody tr");
      const counts = new Map();
      rows.forEach((row) => {
        const cells = row.querySelectorAll("td");
        const val = cells[typeIndex]
          ? cells[typeIndex].textContent.replace(/\s+/g, " ").trim()
          : "";
        if (!val) return;
        counts.set(val, (counts.get(val) || 0) + 1);
      });
      if (counts.size === 0) return null;

      return Array.from(counts.entries())
        .map(([type, count]) => (count > 1 ? `${type} (${count})` : type))
        .join("، ");
    } catch (e) {
      console.error("[متابعة-status] fetchItemTypesFromDetailsPage error:", e);
      return null;
    }
  }

  async function resolveItemType(doc, auditCaseId) {
    const container = doc.querySelector(
      `[smarty_singledispalycol="smarty_singledispalycol_${ITEM_TYPE_FIELD_SUFFIX}_coldiv"]`
    );
    if (!container) return null;

    const valueCell = container.querySelector(".col-sm-7");
    if (!valueCell) return null;

    if (!isDetailsButtonCell(valueCell)) {
      const text = valueCell.textContent.replace(/\s+/g, " ").trim();
      return text || null;
    }

    return await fetchItemTypesFromDetailsPage(auditCaseId);
  }

  // المتجر (store name) — lives in the same kind of
  // smarty_singledispalycol container as item type, just a different
  // field suffix, and it's always a plain value cell (never a details
  // button), so no extra fetch is needed.
  function resolveStoreName(doc) {
    const container = doc.querySelector(
      `[smarty_singledispalycol="smarty_singledispalycol_${STORE_NAME_FIELD_SUFFIX}_coldiv"]`
    );
    if (!container) return null;

    const valueCell = container.querySelector(".col-sm-7");
    if (!valueCell) return null;

    const text = valueCell.textContent.replace(/\s+/g, " ").trim();
    return text || null;
  }

  function findStatusChangeDate(doc, statusText) {
    const table = doc.querySelector('table[id*="AuditTrailPopUp"]');
    if (!table || !statusText) return { date: null, reason: null };

    const changesLog = parseChangesLog(doc);
    const rows = Array.from(table.querySelectorAll("tbody tr"));
    // Walk from most recent to oldest; return the date on the first row
    // whose text matches the status we're looking for.
    for (let i = rows.length - 1; i >= 0; i--) {
      const rowText = normalize(rows[i].textContent);
      if (!rowText.includes(normalize(statusText))) continue;

      const cells = Array.from(rows[i].querySelectorAll("td"));
      for (const cell of cells) {
        const match = cell.textContent.match(DATE_PATTERN);
        if (match) {
          const reason = buildReasonForTimestamp(changesLog, match[0]);
          return { date: match[0], reason };
        }
      }
    }
    return { date: null, reason: null };
  }

  async function fetchStatus(auditCaseId) {
    try {
      const url = `${DETAIL_URL_BASE}?auditcaseid=${encodeURIComponent(auditCaseId)}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) return "error";

      const html = await res.text();
      const doc = new DOMParser().parseFromString(html, "text/html");

      const statusText = extractCurrentStatusText(doc);
      if (!statusText) return "error";

      const delivered = normalize(statusText).includes(normalize(DELIVERED_MARKER));
      const category = classifyStatus(statusText);
      const { date, reason } = findStatusChangeDate(doc, statusText);
      const itemType = await resolveItemType(doc, auditCaseId);
      const storeName = resolveStoreName(doc);

      return { statusText, delivered, category, date, reason, itemType, storeName };
    } catch (e) {
      console.error("[متابعة-status] fetchStatus error:", e);
      return "error";
    }
  }

  // ---- render -----------------------------------------------------------

  function buildBox(cardBody) {
    let box = cardBody.querySelector(".mutabaa-status-summary");
    if (!box) {
      box = document.createElement("div");
      box.className = "mutabaa-status-summary";
      box.style.cssText = [
        "display:flex",
        "align-items:center",
        "justify-content:space-between",
        "gap:6px",
        "margin-bottom:8px",
        "padding:5px 8px",
        "font-size:12px",
        "font-weight:bold",
        "border-radius:5px",
        "line-height:1.5",
      ].join(";");
      cardBody.insertBefore(box, cardBody.firstChild);
    }
    return box;
  }

  function renderPending(box) {
    box.style.background = "#374151";
    box.style.color = "#e5e7eb";
    box.textContent = "جارٍ التحقق من الحالة...";
  }

  function renderError(box, auditCaseId) {
    box.style.background = "#374151";
    box.style.color = "#fca5a5";
    box.innerHTML = "";

    const label = document.createElement("span");
    label.textContent = "تعذر التحقق من الحالة";
    box.appendChild(label);

    const retry = document.createElement("button");
    retry.type = "button";
    retry.textContent = "إعادة المحاولة";
    retry.style.cssText = [
      "font-size:11px",
      "padding:2px 6px",
      "border-radius:4px",
      "border:1px solid #9ca3af",
      "background:#9ca3af",
      "color:#fff",
      "cursor:pointer",
    ].join(";");
    retry.addEventListener("click", (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      statusCache.delete(auditCaseId);
      renderPending(box);
      loadStatusForCard(box, auditCaseId);
    });
    box.appendChild(retry);
  }

  function renderResult(box, result) {
    box.innerHTML = "";
    box.style.background = STATUS_COLORS[result.category] || STATUS_COLORS.other;
    box.style.color = "#fff";
    box.style.flexDirection = "row";
    box.style.flexWrap = "wrap";
    box.style.alignItems = "center";
    box.style.justifyContent = "flex-start";
    box.style.rowGap = "2px";

    const addPart = (text, { bold } = {}) => {
      if (!text) return;
      if (box.childElementCount > 0) {
        const sep = document.createElement("span");
        sep.style.cssText = "opacity:0.6;font-size:10px;";
        sep.textContent = "·";
        box.appendChild(sep);
      }
      const span = document.createElement("span");
      span.style.cssText = bold
        ? "white-space:nowrap;"
        : "font-weight:normal;font-size:11px;opacity:0.95;white-space:nowrap;";
      span.textContent = text;
      box.appendChild(span);
    };

    if (result.delivered) {
      addPart("✅ الواصل - شحنات سلمت بنجاح", { bold: true });
      addPart(result.date);
    } else {
      const icon = result.category === "red" ? "⛔" : result.category === "turquoise" ? "🔄" : "⏳";
      addPart(icon + " " + shorten(result.statusText || "لم يتم التسليم بعد"), { bold: true });
      addPart(result.reason);
      addPart(result.date);
    }

    if (result.storeName) {
      addPart("🏬 " + result.storeName);
    }

    if (result.itemType) {
      addPart("📦 " + result.itemType);
    }
  }

  async function loadStatusForCard(box, auditCaseId) {
    const cached = statusCache.get(auditCaseId);
    if (cached && cached !== "pending") {
      if (cached === "error") renderError(box, auditCaseId);
      else renderResult(box, cached);
      return;
    }

    statusCache.set(auditCaseId, "pending");
    const result = await fetchStatus(auditCaseId);
    statusCache.set(auditCaseId, result);

    if (result === "error") renderError(box, auditCaseId);
    else renderResult(box, result);
  }

  function applyToCard(cardBody) {
    if (cardBody.dataset.mutabaaStatusApplied === "1") return;

    const link = getCaseLink(cardBody);
    const ids = link && extractIdsFromLink(link);
    if (!ids) return;

    cardBody.dataset.mutabaaStatusApplied = "1";
    const box = buildBox(cardBody);
    renderPending(box);
    loadStatusForCard(box, ids.auditcaseid);
  }

  function applyToVisibleCards() {
    findCardBodies().forEach(applyToCard);
  }

  // ---- init + watch for AJAX-loaded / paginated cards --------------------

  let debounceTimer = null;
  function scheduleApply() {
    if (debounceTimer) clearTimeout(debounceTimer);
    debounceTimer = setTimeout(applyToVisibleCards, 300);
  }

  function init() {
    applyToVisibleCards();
    const observer = new MutationObserver((mutations) => {
      const added = mutations.some((m) => m.addedNodes && m.addedNodes.length > 0);
      if (added) scheduleApply();
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();

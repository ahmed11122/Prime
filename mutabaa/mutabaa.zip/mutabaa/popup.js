const versionEl = document.getElementById("version");
const btn = document.getElementById("checkBtn");
const statusEl = document.getElementById("status");

versionEl.textContent = "الإصدار الحالي: " + chrome.runtime.getManifest().version;

function setStatus(text, cls) {
  statusEl.textContent = text;
  statusEl.className = cls || "";
}

btn.addEventListener("click", () => {
  btn.disabled = true;
  setStatus("جارٍ التحقق...", "info");

  chrome.runtime.sendMessage({ type: "mutabaaManualUpdateCheck" }, (res) => {
    if (chrome.runtime.lastError || !res) {
      setStatus("تعذر التحقق، حاول لاحقاً.", "warn");
      btn.disabled = false;
      return;
    }

    if (res.status === "upToDate") {
      setStatus("الإضافة محدّثة (" + res.version + ")", "ok");
      btn.disabled = false;
    } else if (res.status === "updating") {
      // Extension is reloading itself right now — this popup will close
      // on its own as the extension restarts. Only the extension reloads;
      // no page/tab is touched or refreshed.
      setStatus("تم العثور على تحديث (" + res.to + ") — جارٍ التحديث...", "info");
    } else if (res.status === "cooldown") {
      setStatus("تم التحديث مؤخراً، حاول بعد دقائق قليلة.", "warn");
      btn.disabled = false;
    } else if (res.status === "error") {
      setStatus("تعذر التحقق من التحديث.", "warn");
      btn.disabled = false;
    }
  });
});


// ── Backup / restore buttons ─────────────────────────────────────
document.getElementById("backupBtn").addEventListener("click", () => {
  setStatus("جارٍ النسخ...", "info");
  chrome.runtime.sendMessage({ type: "mutabaaBackupNow" }, (res) => {
    if (!res) return setStatus("تعذر النسخ الاحتياطي.", "warn");
    if (res.status === "ok") setStatus("تم الحفظ في Downloads\\mutabaa-backup (" + res.count + ")", "ok");
    else if (res.status === "empty") setStatus("لا توجد بيانات للنسخ.", "warn");
    else setStatus("تعذر النسخ الاحتياطي.", "warn");
  });
});
const fileInput = document.getElementById("restoreFile");
document.getElementById("restoreBtn").addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", async () => {
  const f = fileInput.files[0];
  if (!f) return;
  try {
    const res = await mbRestore(JSON.parse(await f.text()));
    if (res.status === "ok") {
      setStatus("تم الاسترجاع (" + res.count + ")", "ok");
      chrome.action.setBadgeText({ text: "" });
    } else setStatus("ملف غير صالح.", "warn");
  } catch (e) {
    setStatus("ملف غير صالح.", "warn");
  }
  fileInput.value = "";
});

const versionEl = document.getElementById("version");
const btn = document.getElementById("checkBtn");
const statusEl = document.getElementById("status");

versionEl.textContent = "الإصدار الحالي: " + chrome.runtime.getManifest().version;

function setStatus(text, cls) {
  statusEl.textContent = text;
  statusEl.className = cls || "";
}

btn.addEventListener("click", () => {
  btn.disabled = true;
  setStatus("جارٍ التحقق...", "info");

  chrome.runtime.sendMessage({ type: "mutabaaManualUpdateCheck" }, (res) => {
    if (chrome.runtime.lastError || !res) {
      setStatus("تعذر التحقق، حاول لاحقاً.", "warn");
      btn.disabled = false;
      return;
    }

    if (res.status === "upToDate") {
      setStatus("الإضافة محدّثة (" + res.version + ")", "ok");
      btn.disabled = false;
    } else if (res.status === "updating") {
      // Extension is reloading itself right now — this popup will close
      // on its own as the extension restarts. Only the extension reloads;
      // no page/tab is touched or refreshed.
      setStatus("تم العثور على تحديث (" + res.to + ") — جارٍ التحديث...", "info");
    } else if (res.status === "cooldown") {
      setStatus("تم التحديث مؤخراً، حاول بعد دقائق قليلة.", "warn");
      btn.disabled = false;
    } else if (res.status === "error") {
      setStatus("تعذر التحقق من التحديث.", "warn");
      btn.disabled = false;
    }
  });
});

/*
 * content-queuemonitor.js  (simplified — no auto-claim)
 * -------------------------------------------------------------
 * Adds a floating "بدء العمل / استراحة" toggle on the CasesFollowUp page.
 *
 * Employee flow:
 *  - يضغط "بدء العمل" ويبدأ يعالج الطلبات بنفسه بشكل طبيعي (لا يوجد
 *    auto-claim بعد الآن — كان هذا الجزء غير مستقر وتم حذفه).
 *  - عند الانتهاء يضغط "استراحة" — يبدأ عداد 15:00 ظاهر على الزر.
 *  - لو ما رجع "بدء العمل" قبل ما ينتهي الـ 15 دقيقة، عنده سماحية
 *    دقيقتين إضافيتين (Grace). لو انتهت الدقيقتين وبعده ما رجع،
 *    يسجل له تحذير (warning) واحد لهذا الاستراحة.
 *  - عدد التحذيرات اليوم يظهر كـ badge صغير جنب زر "بدء العمل".
 *  - أكثر من 3 تحذيرات باليوم = يُبلّغ عنها في Firebase عشان لوحة
 *    التحكم تقدر تنزل تقييمه (المنطق نفسه على الداشبورد لسه لازم يُضاف
 *    لو تبيه يظهر هناك أيضاً).
 *
 * الحماية من "يضغط بدء العمل ويسيب الجهاز":
 *  - لو صار عدد الطلبات الحالية (تحت التدقيق) = 0 بالضبط لمدة 5 دقائق
 *    متواصلة أثناء "يعمل الآن"، يتحول تلقائيًا إلى "استراحة" — بنفس
 *    عداد الـ15 دقيقة العادي بعدها (يعني لازم يرجع "بدء العمل" قبل
 *    ما ينتهي وإلا يسجل له تحذير عادي، تمامًا متل لو ضغط "استراحة" بنفسه).
 *  - سابقًا كان فيه نسخة أقدم من هذا التحويل عند عدد <= 5 (وليس = 0
 *    بالضبط) وتم حذفها لأنها كانت تتحول أحيانًا بشكل خاطئ (فترة هدوء
 *    طبيعية، دفعة طلبات جديدة لم تصل بعد). الشرط الحالي (= 0 بالضبط،
 *    وليس <= 5) أدق وأقل عرضة لهذا الخطأ.
 *
 * ⚠ REQUIRES CONFIGURATION BELOW before this does anything useful.
 */

(function () {
  "use strict";

  // This page embeds copies of itself inside iframes (e.g. the
  // "Needs-revision-branch-customers" / "under-revision-by-emp" iframes),
  // each with its own #smarty_cancelFilter button. Content scripts run in
  // every frame by default, so without this guard the panel gets mounted
  // once per frame — which is why it was showing up duplicated. Only run
  // in the actual top-level tab.
  if (window.top !== window.self) {
    return;
  }

  // ============================================================
  // CONFIG
  // ============================================================
  const RELAY_BASE = "https://pbx.mutabaa.online";

  // شحنات فرعي بانتظار التدقيق (poolCount, see getPoolCount()) only updates
  // on a manual page refresh — it does NOT live-update in place. So a tab
  // left open for 10 minutes keeps re-reporting the same 10-minute-old
  // number every ~20s (LIVE_REPORT_MS), and if that stale report happens to
  // land AFTER some other employee's fresher one, it silently overwrites it
  // — this is what caused the 📦 badge to flicker between old and current
  // values on the dashboard. PAGE_LOADED_AT timestamps this tab's snapshot
  // so the relay can prefer whichever report is actually freshest instead
  // of whichever simply arrived last — see /queuemonitor/report in relay.js.
  const PAGE_LOADED_AT = Date.now();

  const REPORT_DEBOUNCE_MS = 800;       // debounce DOM-triggered reports
  const DEFAULT_BREAK_LIMIT_MS = 15 * 60 * 1000; // 15 min default; admin can override per-employee
  const BREAK_GRACE_MS = 2 * 60 * 1000;     // +2 min grace before a warning
  const MIN_WORK_BEFORE_BREAK_MS = 10 * 60 * 1000; // must work 10min before "استراحة" is allowed
  const TICK_MS = 1000;                 // countdown UI refresh
  const ADMIN_POLL_MS = 5000;           // was 15000 — shorter so admin popups/break changes land fast
  const LIVE_REPORT_MS = 20 * 1000;     // push fresh queueCount to Firebase periodically, not just on toggle
  const IDLE_QUEUE_ZERO_MS = 5 * 60 * 1000; // auto-switch يعمل الآن → استراحة once queueCount stays exactly 0 this long
  const OFFSHIFT_ZERO_MS = 60 * 1000;       // outside the shift window, a clean 0 this long ends the work session (no 5-min wait)
  const IDLE_CHECK_MS = 5000;               // how often to re-check queueCount for the idle timer above
  const HOARD_STUCK_MS = 60 * 60 * 1000;    // queueCount unchanged this long while "working" = treated as away too (see awayTick)
  const AWAY_GRACE_MS = 5 * 60 * 1000;      // a single continuous away stretch shorter than this never counts toward the cumulative total — see awayTick
  const MAX_BREAK_SESSION_MS = 12 * 60 * 60 * 1000; // a breakStartedAt older than this is stale (left open overnight etc.), not a real ongoing استراحة

  // Selectors confirmed against the CasesFollowUp page
  const SEL = {
    underRevisionTableBody:
      '#smarty_table_com_dot_app_dot_bussframework_dot_SingleQueue_AGENTOP_UnderRevisionByEmp tbody',
  };

  if (!location.pathname.includes("/tickets/CasesFollowUp")) return;

  // ============================================================
  // State
  // ============================================================
  let working = false;
  let breakStartedAt = null;     // when the current استراحة started
  let breakWarned = false;       // did this break session already earn a warning?
  let warningsToday = { date: todayKey(), count: 0 };

  let breakTickTimer = null;
  let idleTickTimer = null;
  let idleZeroSinceAt = null;    // when queueCount first read 0 during the current working session; null while not currently 0
    let reportDebounceTimer = null;
  let lastAdminForce = null;
  let breakLimitMs = DEFAULT_BREAK_LIMIT_MS; // may be overridden per-employee from the dashboard
  let lastShownPopupId = null; // dedupe so the same admin popup isn't shown twice
  let workStartedAt = null;      // when the current "يعمل الآن" session started (for the 10min lock)
  let shiftEnded = false;        // admin forced "إنهاء الدوام" — blocks toggling back to عمل until released
  let currentEmployeeName = null; // whoever restoreLocalState() last resolved via getEmployeeName()
  let lastAppliedWarningReset = 0; // last resetWarningsAt timestamp already applied — see pollAdminForce()
  // All-time إنذار total from Firebase (automatic + manual combined, never
  // reset by date — see warningCount in /queuemonitor/state and
  // addPersistentWarning()/addEmployeeWarning() on the relay/dashboard
  // side). This is what qm-warning-badge actually displays now; the local
  // warningsToday counter above still exists only to drive this break's
  // own warning logic and the daily "> 3 = تنزيل تقييم" server flag.
  let remoteWarningCount = 0;
  let remoteWarningsList = []; // [{text, createdAt}] — see remoteWarningCount above; feeds the badge's hover tooltip
  let lastWarningReason = null; // reason text of the most recent locally-fired warning, sent up so the relay
                                 // can log it under the employee's own name instead of a generic label
  let lastAppliedStateVersion = 0; // highest qmStateVersion this tab has applied — see registerCrossTabSync()
  let flashActive = false;       // a transient flashMessage() is currently shown on the button — see renderToggleButton()

  // Cumulative "away from real work" tracker (see awayTick() below). Unlike
  // breakWarned (which only ever fires once per استراحة session and gets
  // wiped clean by every "بدء العمل" click), this accrues across the WHOLE
  // day and toggling the button can't reset it — closes the loophole where
  // repeatedly toggling every <15min produced zero warnings for zero work.
  let awayMsToday = { date: todayKey(), ms: 0 };
  let awayWarnedUpToMs = 0;      // highest awayMsToday.ms multiple already turned into a warning
  let lastQueueCountSeen = null;
  let lastQueueCountChangedAt = null; // last time queueCount actually changed (hoarding detector)
  let awayTickerTimer = null;
  let awayLastTickAt = null;
  let awayStreakStartedAt = null; // when the CURRENT continuous away stretch began (resets whenever isAway flips back to false)
  let awayStreakCountedMs = 0;    // how much of the current streak has already been folded into awayMsToday — see awayTick
  const AWAY_TAB_ID = `${Date.now()}-${Math.random().toString(36).slice(2)}`; // unique per tab load — see claimAwayLeader()

  // Per-employee shift window, set from the admin dashboard's queue-monitor
  // tab ("HH:MM" 24h strings, e.g. "09:00"/"17:00"). null/null (the default,
  // for anyone the admin hasn't configured yet) means "no shift set — behave
  // exactly as before, away/warning tracking is always active." Once set,
  // away/warning tracking (awayTick, below) only runs INSIDE the window;
  // outside it, being logged in and working counts as overtime instead of
  // triggering warnings — being logged in but idle/on break outside the
  // window isn't tracked as anything (they're simply off the clock).
  let shiftStart = null;
  let shiftEnd = null;
  let overtimeMsToday = { date: todayKey(), ms: 0 };

  // Bug fix (see registerCrossTabSync): chrome.storage.onChanged events can
  // arrive out of order relative to this tab's own fast, successive writes
  // (e.g. an employee double/triple-clicking the toggle). Stamping every
  // persistLocalState() write with a number that only ever goes up lets the
  // listener tell "this is an old echo of a write I've since superseded"
  // apart from "this is a genuinely newer change from another tab" — plain
  // value-equality can't do that once local memory has already moved past
  // what the late echo describes.
  let __qmVerTime = 0;
  let __qmVerSeq = 0;
  function nextStateVersion() {
    const now = Date.now();
    if (now === __qmVerTime) {
      __qmVerSeq += 1;
    } else {
      __qmVerTime = now;
      __qmVerSeq = 0;
    }
    return __qmVerTime * 1000 + __qmVerSeq;
  }

  function todayKey() {
    const d = new Date();
    return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
  }

  // Bug fix: the "different employee logged in" checks below used to
  // compare raw name strings. Any harmless formatting difference between
  // two reads of the same employee's name (extra/trailing whitespace,
  // Arabic/English digit or casing quirks in mutabaaRawName) made every
  // single login look like a *different* employee, wiping local state —
  // including qmLastShownPopupId — and replaying already-seen admin
  // popups forever. Comparing trimmed/case-folded names avoids false
  // positives while still catching an actual employee switch.
  function normalizeEmployeeName(name) {
    return typeof name === "string" ? name.trim().toLowerCase().replace(/\s+/g, " ") : name;
  }

  function getEmployeeName() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(["mutabaaRawName"], (data) => {
          resolve((data && data.mutabaaRawName) || null);
        });
      } catch (e) {
        resolve(null);
      }
    });
  }

  let queueSelectorWarned = false;
  // Smooths the 📋 badge over brief getQueueCount() misses (SPA re-render,
  // navigating tabs, a modal covering the table for a second or two) —
  // display-only: idle/away/warning logic below still gets the real
  // null from getQueueCount() and treats it exactly as before. Without
  // this, the badge itself flashed "📋 ?" on every one of those transient
  // gaps even though the real count hadn't changed.
  const QUEUE_COUNT_STALE_GRACE_MS = 8000;
  let lastKnownQueueCount = null;
  let lastKnownQueueCountAt = 0;

  function findQueueBody(doc) {
    // 1) exact selector confirmed on the normal CasesFollowUp page
    let body = doc.querySelector(SEL.underRevisionTableBody);

    // 2) fallback for variants like ?superVisiorsSearch=1, where the table
    //    gets a different id — match loosely on the id fragment that's
    //    stable across them ("UnderRevisionByEmp"). Deliberately NOT falling
    //    back further to a generic "smarty_table_" or "table tbody" match:
    //    this CRM uses "smarty_table_" as a generic naming pattern shared by
    //    other tables (e.g. the pool/"Needs-revision-branch-customers" queue),
    //    so a broader match can silently return a different table's count
    //    instead of correctly reporting 0.
    if (!body) {
      body = doc.querySelector('table[id*="UnderRevisionByEmp"] tbody')
        || doc.querySelector('[id*="UnderRevisionByEmp"] tbody');
    }

    // 3) last-resort fallback: some page variants render the same queue
    //    under a completely different generated id, but the visible column
    //    headers still say "تحت التدقيق" (or similar). Walk every table on
    //    the page, look at its header row text, and use the first one whose
    //    headers mention the queue name.
    if (!body) {
      const tables = Array.from(doc.querySelectorAll("table"));
      const match = tables.find((t) => {
        const headerRow = t.querySelector("thead tr, tr");
        if (!headerRow) return false;
        const headerText = headerRow.textContent || "";
        return headerText.includes("تحت التدقيق") || headerText.includes("التدقيق");
      });
      if (match) body = match.querySelector("tbody") || match;
    }

    return body;
  }

  function countQueueRows(body) {
    const rows = Array.from(body.querySelectorAll("tr"));
    // prefer the "pointer" class seen on real order rows, since it excludes
    // header rows and empty-state rows more reliably than checking for <td>
    const pointerRows = rows.filter((tr) => tr.classList.contains("pointer"));
    if (pointerRows.length > 0) return pointerRows.length;
    // fall back to "has a data cell at all", in case a page variant doesn't
    // use the pointer class
    return rows.filter((tr) => tr.querySelector("td")).length;
  }

  function getQueueCount() {
    // 1) the top-level document — works when the table isn't inside an iframe
    let body = findQueueBody(document);
    if (body) return countQueueRows(body);

    // 2) the table may be rendered inside a same-origin iframe; this script
    //    only *mounts its UI* in the top frame (see the window.top guard
    //    above), but it can still reach into same-origin iframe documents
    //    from here to read their DOM.
    const iframes = document.querySelectorAll("iframe");
    for (let i = 0; i < iframes.length; i++) {
      try {
        const doc = iframes[i].contentDocument || iframes[i].contentWindow.document;
        if (!doc) continue;
        body = findQueueBody(doc);
        if (body) return countQueueRows(body);
      } catch (e) {
        // cross-origin iframe — can't be read from here, skip it
      }
    }

    if (!queueSelectorWarned) {
      queueSelectorWarned = true;
      console.warn(
        "[queuemonitor] couldn't find the تحت التدقيق table on this page or in any " +
        "readable iframe (neither the exact id nor fallbacks matched) — " +
        "📋 will show ? until the selector is updated for this page."
      );
    }
    // Bug fix: this used to return 0 here, which is indistinguishable from
    // a genuinely empty queue — a transient DOM miss (SPA re-render, an
    // order-detail modal covering the table, etc.) could silently look
    // exactly like "no orders" to the idle/away detectors below and start
    // ticking toward an unearned auto-break or warning. null means "don't
    // know right now"; callers must treat it as neither 0 nor non-zero.
    return null;
  }

  // ============================================================
  // Pool count ("شحنات فرعي بانتظار التدقيق")
  // ============================================================
  // Unlike getQueueCount() this isn't a table of rows — it's the
  // ready-made nav-tab counter badge for the "Needs-revision-branch-
  // customers" tab: <span id="cases_counter-branch-customers">N</span>,
  // rendered in the top-level document (not inside an iframe).
  let poolSelectorWarned = false;

  function getPoolCount() {
    // 1) exact id confirmed via devtools
    let el = document.getElementById("cases_counter-branch-customers");

    // 2) fallback: same id pattern, but just in case it ever gets
    //    namespaced/prefixed differently on some page variant
    if (!el) {
      el = document.querySelector('[id*="cases_counter-branch-customers"]');
    }

    // 3) last-resort fallback: walk every ".normal-count" badge and use
    //    the one whose ".title-with-counter" label mentions "فرعي"
    //    (the "شحنات فرعي" pool tab specifically, not some other counter).
    if (!el) {
      const candidates = Array.from(document.querySelectorAll(".title-with-counter"));
      const match = candidates.find((c) => (c.textContent || "").includes("فرعي"));
      if (match) el = match.querySelector(".normal-count, span");
    }

    if (!el) {
      if (!poolSelectorWarned) {
        poolSelectorWarned = true;
        console.warn(
          "[queuemonitor] couldn't find the شحنات فرعي pool counter badge " +
          "(#cases_counter-branch-customers) — poolCount will be omitted until " +
          "the selector is updated for this page."
        );
      }
      return null;
    }

    const n = parseInt((el.textContent || "").trim(), 10);
    return Number.isNaN(n) ? null : n;
  }

  // ============================================================
  // Relay calls
  // ============================================================
  async function reportState() {
    const name = await getEmployeeName();
    if (!name) return;

    // Logged-in employee changed without a full page reload (e.g. the CRM
    // swapped sessions in place) — reset local state before reporting
    // anything under the new name, same as the startup check in
    // restoreLocalState(), so warnings/break state never leak between
    // employees sharing a device.
    if (currentEmployeeName && normalizeEmployeeName(name) !== normalizeEmployeeName(currentEmployeeName)) {
      console.warn(
        `[queuemonitor] logged-in employee changed mid-session (${currentEmployeeName} → ${name}) — resetting local state`
      );
      currentEmployeeName = name;
      working = false;
      breakStartedAt = null;
      workStartedAt = null;
      breakWarned = false;
      shiftEnded = false;
      warningsToday = { date: todayKey(), count: 0 };
      lastWarningReason = null;
      lastShownPopupId = null;
      lastAdminForce = null; // force a fresh read of this employee's own adminForce on next poll
      lastAppliedWarningReset = 0; // different employee — their own resetWarningsAt history doesn't apply
      awayMsToday = { date: todayKey(), ms: 0 };
      awayWarnedUpToMs = 0;
      awayStreakStartedAt = null;
      awayStreakCountedMs = 0;
      overtimeMsToday = { date: todayKey(), ms: 0 };
      lastQueueCountSeen = null;
      lastQueueCountChangedAt = null;
      stopBreakClock();
      stopIdleCheck();
      persistLocalState();
      renderToggleButton();
    } else if (!currentEmployeeName) {
      currentEmployeeName = name;
    }

    const payload = {
      employeeName: name,
      queueCount: getQueueCount(),
      working,
      breakStartedAt: working ? null : breakStartedAt,
      warningsToday: warningsToday.count,
      warningsDate: warningsToday.date,
      warningReason: lastWarningReason, // reason text for the most recent local warning — see relay's warningReasonToLog
      overtimeMsToday: overtimeMsToday.ms,
      overtimeDate: overtimeMsToday.date,
    };

    const poolCount = getPoolCount();
    if (poolCount !== null) {
      payload.poolCount = poolCount;
      payload.poolCountAsOf = PAGE_LOADED_AT;
    }

    flushPendingSessions(); // opportunistic retry of any queued session events

    try {
      const res = await fetch(`${RELAY_BASE}/queuemonitor/report`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      // The relay now stamps breakStartedAt with ITS OWN clock, ignoring
      // whatever we sent — sync our local copy to that server-corrected
      // value so even THIS tab's own countdown UI can't be fooled by a
      // spoofed system clock, not just the admin dashboard. Only applies
      // while actually on استراحة; a few seconds of drift from the normal
      // request round-trip is fine and not worth chasing.
      if (!working) {
        const data = await res.json().catch(() => null);
        if (data && typeof data.breakStartedAt === "number" && data.breakStartedAt !== breakStartedAt) {
          breakStartedAt = data.breakStartedAt;
          persistLocalState();
        }
      }
    } catch (e) {
      console.warn("[queuemonitor] report failed", e);
    }
  }

  function scheduleReport() {
    clearTimeout(reportDebounceTimer);
    reportDebounceTimer = setTimeout(reportState, REPORT_DEBOUNCE_MS);
  }

  async function fetchAdminState() {
    const name = await getEmployeeName();
    if (!name) return null;
    try {
      const res = await fetch(
        `${RELAY_BASE}/queuemonitor/state?employeeName=${encodeURIComponent(name)}`
      );
      if (!res.ok) return null;
      return await res.json(); // { adminForce, targetAssign, breakLimitMinutes, popup, shiftStart, shiftEnd, warningCount }
    } catch (e) {
      return null;
    }
  }

  // ============================================================
  // Warnings
  // ============================================================
  function ensureWarningsFresh() {
    const key = todayKey();
    if (warningsToday.date !== key) {
      warningsToday = { date: key, count: 0 };
      persistLocalState();
    }
  }

  // Bug fix: breakStartedAt had no upper bound — if a tab was ever left open
  // on استراحة overnight (PC not shut down, browser just left running) or
  // the employee simply forgot to click "بدء العمل" the next morning before
  // walking away, it just kept counting from that original click, forever.
  // The dashboard would then show absurd elapsed times like "منذ 1288 دقيقة"
  // (~21 hours) on what looked to the employee like they'd just started a
  // normal break, which is confusing for everyone and not meaningful data.
  // Note: this only clears the display/session-start bookkeeping — it does
  // NOT touch awayMsToday (already date-scoped separately via
  // ensureAwayFresh, so today's real cumulative total is unaffected either
  // way) and does not forgive or grant any warnings.
  function ensureBreakSessionFresh() {
    if (breakStartedAt && (Date.now() - breakStartedAt) > MAX_BREAK_SESSION_MS) {
      breakStartedAt = Date.now(); // treat as a fresh استراحة starting now, not a multi-day-old one
      // Bug fix: this used to also reset breakWarned = false here, which
      // re-armed the per-break overrun check in awayTick() for a break that
      // never actually ended — a single continuous استراحة left open past
      // MAX_BREAK_SESSION_MS (e.g. a forgotten login over a weekend) fired a
      // brand-new warning roughly every 12h+17min after the first one, all
      // for the same uninterrupted absence. breakWarned is intentionally
      // left untouched: this reset is purely cosmetic (keeps the on-screen
      // elapsed time sane), not a real new break session, so it must not be
      // able to grant a second warning for something that already earned one.
      persistLocalState();
    }
  }

  function addWarning(reason) {
    ensureWarningsFresh();
    warningsToday.count += 1;
    lastWarningReason = reason || "تجاوز وقت الاستراحة";
    persistLocalState();
    renderToggleButton();
    scheduleReport();
    console.warn(`[queuemonitor] تحذير #${warningsToday.count} اليوم — ${lastWarningReason}`);
  }

  // ============================================================
  // Working / break switching
  // ============================================================
  // Tracks the currently-open session so we can close it out (with an end
  // time) the moment the employee flips state again. Sent to the relay as
  // its own event — separate from reportState()'s live snapshot — so the
  // admin dashboard can show a full history, not just "what's true right now".
  // Posts to /queuemonitor/session on the relay, which appends each event
  // under queueSessions/{owner}/{employeeKey}/{pushId} in Firebase so the
  // admin dashboard's session-log modal (openSessionLog) can show full
  // history, not just the live snapshot in queueMonitor/*.
  let currentSessionStartedAt = null;
  let currentSessionType = null; // 'work' | 'break'

  // ── Offline retry queue for session events ──
  // A single fetch() with no retry meant a dropped connection at the exact
  // moment an employee toggled state silently lost that session forever —
  // the UI switched fine locally, but the Firebase dashboard never got it.
  // Failed payloads are cached in chrome.storage.local and retried on the
  // normal 20s report cycle (flushPendingSessions, called from reportState)
  // until they succeed, so a temporary network blip self-heals instead of
  // being a permanent gap in the employee's logged history.
  const PENDING_SESSIONS_KEY = "qmPendingSessions";
  const MAX_PENDING_SESSIONS = 200; // cap so a long offline stretch can't grow this unbounded

  // Bug fix: queuePendingSession() and flushPendingSessions() each did their
  // own independent chrome.storage.local get-then-set round trip. If a
  // session failed and got queued at the same moment a scheduled flush was
  // already mid-flight, both could read the same starting list before
  // either had written back — whichever set() landed second silently
  // clobbered the other's change, which could drop a queued session
  // (either the newly-queued one, or one flushPendingSessions had already
  // removed after successfully sending it) without any error. Routing both
  // functions through this single promise chain makes each get+set
  // sequence wait for the previous one to fully finish before it starts its
  // own read, so the two operations can no longer interleave.
  let pendingSessionsLock = Promise.resolve();

  function withPendingSessionsLock(fn) {
    const run = pendingSessionsLock.then(fn, fn);
    pendingSessionsLock = run.then(() => undefined, () => undefined);
    return run;
  }

  function queuePendingSession(payload) {
    return withPendingSessionsLock(() => new Promise((resolve) => {
      try {
        chrome.storage.local.get([PENDING_SESSIONS_KEY], (data) => {
          const list = (data && Array.isArray(data[PENDING_SESSIONS_KEY])) ? data[PENDING_SESSIONS_KEY] : [];
          list.push(payload);
          if (list.length > MAX_PENDING_SESSIONS) list.splice(0, list.length - MAX_PENDING_SESSIONS);
          chrome.storage.local.set({ [PENDING_SESSIONS_KEY]: list }, resolve);
        });
      } catch (e) {
        resolve(); // best effort
      }
    }));
  }

  async function sendSessionPayload(payload) {
    const res = await fetch(`${RELAY_BASE}/queuemonitor/session`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(`relay responded ${res.status}`);
  }

  function flushPendingSessions() {
    return withPendingSessionsLock(() => new Promise((resolve) => {
      try {
        chrome.storage.local.get([PENDING_SESSIONS_KEY], async (data) => {
          const list = (data && Array.isArray(data[PENDING_SESSIONS_KEY])) ? data[PENDING_SESSIONS_KEY] : [];
          if (!list.length) return resolve();
          const stillPending = [];
          for (const payload of list) {
            try {
              await sendSessionPayload(payload);
            } catch (e) {
              stillPending.push(payload); // keep it queued, try again next flush
            }
          }
          chrome.storage.local.set({ [PENDING_SESSIONS_KEY]: stillPending }, () => {
            if (stillPending.length < list.length) {
              console.info(`[queuemonitor] flushed ${list.length - stillPending.length} queued session event(s)`);
            }
            resolve();
          });
        });
      } catch (e) {
        resolve();
      }
    }));
  }

  async function reportSessionEvent(type, startedAt, endedAt, reason) {
    const name = await getEmployeeName();
    if (!name) return;
    const payload = { employeeName: name, type, startedAt, endedAt, reason: reason || "manual" };
    try {
      await sendSessionPayload(payload);
    } catch (e) {
      console.warn("[queuemonitor] session report failed — queuing for retry", e);
      queuePendingSession(payload);
    }
  }

  function setWorking(nextWorking, { fromAdmin = false, fromIdle = false } = {}) {
    const now = Date.now();
    const reason = fromAdmin ? "admin" : (fromIdle ? "idle-auto" : "manual");

    // close out whatever session was open before flipping
    if (currentSessionType) {
      reportSessionEvent(currentSessionType, currentSessionStartedAt, now, reason);
    }

    working = nextWorking;
    if (working) {
      breakStartedAt = null;
      breakWarned = false;
      workStartedAt = now;
      if (!fromAdmin && !fromIdle) {
        // Employee pressed بدء العمل: end the away stretch now. Otherwise, with an
        // empty queue (count 0 still counts as away) the same streak that started
        // on the break kept growing and could fire a warning right after returning.
        // Time already folded into awayMsToday stays counted — only the open streak resets.
        awayStreakStartedAt = null;
        awayStreakCountedMs = 0;
      }
      stopBreakClock();
      startIdleCheck();
      startLockClock();
    } else {
      workStartedAt = null;
      breakStartedAt = Date.now();
      breakWarned = false;
      stopLockClock();
      stopIdleCheck();
      startBreakClock();
    }

    currentSessionType = working ? "work" : "break";
    currentSessionStartedAt = now;

    persistLocalState();
    renderToggleButton();
    scheduleReport();
  }

  function persistLocalState() {
    const version = nextStateVersion();
    lastAppliedStateVersion = version; // this tab's memory already reflects this version as of right now
    try {
      chrome.storage.local.set({
        qmEmployeeName: currentEmployeeName,
        qmWorking: working,
        qmBreakStartedAt: breakStartedAt,
        qmWorkStartedAt: workStartedAt,
        qmBreakWarned: breakWarned,
        qmWarningsToday: warningsToday,
        qmLastWarningReason: lastWarningReason,
        qmLastShownPopupId: lastShownPopupId,
        qmShiftEnded: shiftEnded,
        qmLastAppliedWarningReset: lastAppliedWarningReset,
        qmAwayMsToday: awayMsToday,
        qmAwayWarnedUpToMs: awayWarnedUpToMs,
        qmAwayStreakStartedAt: awayStreakStartedAt,
        qmAwayStreakCountedMs: awayStreakCountedMs,
        qmOvertimeMsToday: overtimeMsToday,
        qmStateVersion: version,
        qmLastAdminForce: lastAdminForce,
      });
    } catch (e) {
      /* ignore */
    }
  }

  // Local state (working/break/warnings/shiftEnded) is saved per-browser,
  // not per-employee. If a different employee logs in on the same
  // computer/browser profile, mutabaaRawName changes but this old state
  // would otherwise be reused and reported under the new name — e.g. an
  // employee inheriting someone else's break warnings from earlier that
  // day. So on every load, compare the currently logged-in name against
  // whichever name the saved state belongs to; if they differ, wipe the
  // state clean before restoring anything.
  function restoreLocalState() {
    return new Promise((resolve) => {
      getEmployeeName().then((name) => {
        currentEmployeeName = name;
        try {
          chrome.storage.local.get(
            ["qmEmployeeName", "qmWorking", "qmBreakStartedAt", "qmWorkStartedAt", "qmBreakWarned", "qmWarningsToday", "qmLastWarningReason", "qmLastShownPopupId", "qmShiftEnded", "qmLastAppliedWarningReset", "qmAwayMsToday", "qmAwayWarnedUpToMs", "qmAwayStreakStartedAt", "qmAwayStreakCountedMs", "qmOvertimeMsToday", "qmStateVersion", "qmLastAdminForce"],
            (data) => {
              const savedForDifferentEmployee =
                name && data && data.qmEmployeeName &&
                normalizeEmployeeName(data.qmEmployeeName) !== normalizeEmployeeName(name);

              if (savedForDifferentEmployee) {
                console.warn(
                  `[queuemonitor] logged-in employee changed (${data.qmEmployeeName} → ${name}) — resetting local work/break/warning state`
                );
                working = false;
                breakStartedAt = null;
                workStartedAt = null;
                breakWarned = false;
                shiftEnded = false;
                warningsToday = { date: todayKey(), count: 0 };
                lastShownPopupId = null;
                lastAppliedWarningReset = 0; // different employee — their own resetWarningsAt history doesn't apply
                awayMsToday = { date: todayKey(), ms: 0 }; // different employee — their own away-time history doesn't apply
                awayWarnedUpToMs = 0;
                awayStreakStartedAt = null;
                awayStreakCountedMs = 0;
                overtimeMsToday = { date: todayKey(), ms: 0 };
                lastQueueCountSeen = null;
                lastQueueCountChangedAt = null;
                persistLocalState(); // overwrite the stale state immediately
                resolve();
                return;
              }

              working = !!(data && data.qmWorking);
              // Bug fix: lastAdminForce used to live only in memory, so it
              // reset to null on every page load/login. If an admin ever
              // clicked "إجبار عمل"/"إجبار استراحة" and never clicked "إلغاء
              // الإجبار" afterward, the same old force value sits in Firebase
              // forever — and with lastAdminForce back at null, the very
              // first pollAdminForce() after login treated that stale value
              // as brand new and reapplied it, silently overriding whatever
              // the employee had just done (e.g. flipping them back to عمل a
              // second after they clicked استراحة, which also reset
              // workStartedAt and triggered the 10-minute "ليس الآن" lock on
              // their very next click). Restoring the last-applied value
              // here means a given admin force is only ever acted on once.
              lastAdminForce = (data && typeof data.qmLastAdminForce !== "undefined") ? data.qmLastAdminForce : null;
              breakStartedAt = (data && data.qmBreakStartedAt) || null;
              breakWarned = !!(data && data.qmBreakWarned);
              shiftEnded = !!(data && data.qmShiftEnded);
              lastAppliedWarningReset = (data && typeof data.qmLastAppliedWarningReset === "number") ? data.qmLastAppliedWarningReset : 0;
              awayMsToday = (data && data.qmAwayMsToday && data.qmAwayMsToday.date === todayKey()) ? data.qmAwayMsToday : { date: todayKey(), ms: 0 };
              awayWarnedUpToMs = (data && typeof data.qmAwayWarnedUpToMs === "number") ? data.qmAwayWarnedUpToMs : 0;
              awayStreakStartedAt = (data && typeof data.qmAwayStreakStartedAt === "number") ? data.qmAwayStreakStartedAt : null;
              awayStreakCountedMs = (data && typeof data.qmAwayStreakCountedMs === "number") ? data.qmAwayStreakCountedMs : 0;
              overtimeMsToday = (data && data.qmOvertimeMsToday && data.qmOvertimeMsToday.date === todayKey()) ? data.qmOvertimeMsToday : { date: todayKey(), ms: 0 };
              lastAppliedStateVersion = (data && typeof data.qmStateVersion === "number") ? data.qmStateVersion : 0;
              const hadWorkStartedAt = !!(data && data.qmWorkStartedAt);
              workStartedAt = hadWorkStartedAt ? data.qmWorkStartedAt : (working ? Date.now() : null);
              if (working && !hadWorkStartedAt) {
                // first time we've seen this employee working without a saved
                // start time (e.g. was already working before this feature
                // existed) — save it now so the NEXT refresh reads the same
                // value instead of generating a fresh Date.now() every time.
                try {
                  chrome.storage.local.set({ qmWorkStartedAt: workStartedAt });
                } catch (e) { /* ignore */ }
              }
              if (data && data.qmWarningsToday && data.qmWarningsToday.date === todayKey()) {
                warningsToday = data.qmWarningsToday;
              } else {
                warningsToday = { date: todayKey(), count: 0 };
              }
              lastWarningReason = (data && data.qmLastWarningReason) || null;
              lastShownPopupId = (data && data.qmLastShownPopupId) || null;
              resolve();
            }
          );
        } catch (e) {
          resolve();
        }
      });
    });
  }

  // ============================================================
  // Admin popup — one-off message pushed from the dashboard, shown
  // immediately (next poll, up to ADMIN_POLL_MS delay) as a modal
  // overlay on top of the page so it can't be missed/scrolled past.
  // ============================================================
  function showAdminPopup(popup) {
    lastShownPopupId = popup.id;
    persistLocalState();

    // Avoid stacking if one is already showing (e.g. rapid re-poll race)
    const existing = document.getElementById("qm-popup-overlay");
    if (existing) existing.remove();

    const overlay = document.createElement("div");
    overlay.id = "qm-popup-overlay";
    overlay.style.cssText = `
      position: fixed; inset: 0; z-index: 2147483647;
      background: rgba(15,23,42,0.55);
      display: flex; align-items: center; justify-content: center;
      font-family: inherit;
    `;

    const box = document.createElement("div");
    box.style.cssText = `
      background: #fff; border-radius: 14px; padding: 24px 26px;
      max-width: 420px; width: 90%; box-shadow: 0 20px 60px rgba(0,0,0,0.35);
      direction: rtl; text-align: right;
    `;
    box.innerHTML = `
      <div style="font-size:15px;font-weight:800;color:#0f172a;margin-bottom:10px;display:flex;align-items:center;gap:8px;">
        <span>📢</span><span>رسالة من الإدارة</span>
      </div>
      <div style="font-size:14px;color:#334155;white-space:pre-wrap;line-height:1.6;margin-bottom:18px;"></div>
      <div style="text-align:left;">
        <button id="qm-popup-ok" type="button" style="
          border:none;border-radius:8px;padding:8px 22px;font-weight:700;font-size:13px;
          cursor:pointer;background:linear-gradient(135deg,#2563eb,#3b82f6);color:#fff;">حسناً</button>
      </div>
    `;
    // set message via textContent to avoid any HTML injection from the admin-entered text
    box.querySelector("div[style*='white-space']").textContent = popup.text || "";

    overlay.appendChild(box);
    document.body.appendChild(overlay);

    // Tell the relay this popup was seen so it clears `popup` in Firebase —
    // that's what actually stops it reappearing on OTHER devices/browsers
    // for this employee (see /queuemonitor/popup-ack in relay.js). The
    // local lastShownPopupId/chrome.storage bookkeeping above is still kept
    // as a same-tab/same-browser guard against re-showing it before this
    // ack round-trips, but is no longer what makes dismissal permanent.
    const ackPopupSeen = () => {
      if (!currentEmployeeName) return;
      fetch(`${RELAY_BASE}/queuemonitor/popup-ack`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ employeeName: currentEmployeeName, popupId: popup.id }),
      }).catch(() => {}); // best-effort — a missed ack just means one extra repeat, not a stuck state
    };

    const close = () => { overlay.remove(); ackPopupSeen(); };
    box.querySelector("#qm-popup-ok").onclick = close;
    overlay.onclick = (e) => { if (e.target === overlay) close(); };
  }

  // ============================================================
  // Break countdown (15:00 then +2:00 grace, then 1 warning)
  // ============================================================
  function startBreakClock() {
    if (shiftEnded) return; // shift-end isn't a real استراحة — no countdown/warning applies
    stopBreakClock();
    breakTickTimer = setInterval(() => {
      if (working || !breakStartedAt) return stopBreakClock();
      // Warning-firing used to live here (once per session, via breakWarned)
      // but that let an employee wipe the slate by clicking "بدء العمل"
      // right before the limit hit, over and over, all day, for zero
      // warnings. That decision now lives in awayTick() (cumulative across
      // toggles) — this timer is UI-only: it just keeps the countdown text
      // moving. breakWarned/breakStartedAt are still kept in sync for
      // display and cross-tab/admin state, just not used to gate warnings.
      renderToggleButton();
    }, TICK_MS);
  }

  function stopBreakClock() {
    if (breakTickTimer) clearInterval(breakTickTimer);
    breakTickTimer = null;
  }

  // ============================================================
  // Idle detection — DISABLED. This used to auto-switch يعمل الآن →
  // استراحة once the "تحت التدقيق" queue count read exactly 0 for 5
  // minutes straight, silently and with no way for the employee to tell
  // it happened. It kept firing while an employee was genuinely working
  // (e.g. a single case open long enough that it drops out of that
  // table), so per instruction it no longer runs at all — the ONLY thing
  // that switches an employee to استراحة now is the employee pressing
  // the button themselves. startIdleCheck()/stopIdleCheck() are left in
  // place as no-ops (rather than removed) since several call sites below
  // still call them; stopIdleCheck() still clears a leftover timer if
  // one somehow exists, it just never gets one to clear anymore.
  // ============================================================
  function startIdleCheck() {
    stopIdleCheck(); // no-op beyond this — see comment above
  }

  function stopIdleCheck() {
    if (idleTickTimer) clearInterval(idleTickTimer);
    idleTickTimer = null;
    idleZeroSinceAt = null;
  }

  // ============================================================
  // Cumulative "away from real work" tracker.
  //
  // Runs continuously all day (started once in init(), never stopped by
  // toggling), independent of the idle-check above. It closes two real
  // loopholes the old per-session breakWarned logic had:
  //
  //  1) "Reset loop": toggling "بدء العمل" used to zero out breakStartedAt
  //     AND breakWarned for free. An employee could go idle → get
  //     auto-switched to استراحة at 5min → click "بدء العمل" again just
  //     before the 15min limit → repeat forever, for literally zero
  //     warnings despite doing zero work all day.
  //  2) "Hostage order": the idle detector only ever looked for queueCount
  //     EXACTLY 0. Holding one single order open without ever touching it
  //     kept the count at 1 forever and was completely invisible to it.
  //
  // Away time here accrues whenever, each tick:
  //   - working === false (a real استراحة), OR
  //   - working === true but queueCount reads a confirmed 0, OR
  //   - working === true but queueCount hasn't changed at all in
  //     HOARD_STUCK_MS (holding order(s) without progress).
  // and a warning fires each time the running total crosses a new
  // multiple of (breakLimitMs + BREAK_GRACE_MS) — so the debt is
  // cumulative across the whole day and can't be wiped by toggling.
  // ============================================================
  function ensureAwayFresh() {
    const key = todayKey();
    if (awayMsToday.date !== key) {
      awayMsToday = { date: key, ms: 0 };
      awayWarnedUpToMs = 0;
      persistLocalState();
    }
  }

  function ensureOvertimeFresh() {
    const key = todayKey();
    if (overtimeMsToday.date !== key) {
      overtimeMsToday = { date: key, ms: 0 };
      persistLocalState();
    }
  }

  // "HH:MM" -> minutes since local midnight, or null if unset/unparseable.
  function parseHHMM(s) {
    if (typeof s !== "string") return null;
    const m = /^(\d{1,2}):(\d{2})$/.exec(s.trim());
    if (!m) return null;
    const h = parseInt(m[1], 10), min = parseInt(m[2], 10);
    if (h < 0 || h > 23 || min < 0 || min > 59) return null;
    return h * 60 + min;
  }

  // Whether `now` falls inside [shiftStart, shiftEnd) using the employee's
  // own local clock — same local-time basis todayKey()/the rest of this
  // file already relies on. Handles an overnight shift (e.g. 22:00→06:00)
  // by wrapping past midnight. Returns true (i.e. "always tracked") when no
  // shift is configured, so employees with nothing set behave exactly as
  // before this feature existed.
  function isWithinShift(now) {
    const startMin = parseHHMM(shiftStart);
    const endMin = parseHHMM(shiftEnd);
    if (startMin === null || endMin === null) return true;
    // Bug fix: this used to read the EMPLOYEE'S DEVICE clock (now.getHours()),
    // but shiftStart/shiftEnd are set by the admin as Baghdad time — same
    // basis the relay and dashboard use. Any employee whose OS timezone isn't
    // Baghdad (very common: UTC, or just a different regional setting) was
    // silently being judged against the wrong window — sometimes hours off —
    // which could mark someone "off-shift" while they were actively working
    // their real shift, or the reverse. Compute Baghdad time from the
    // timestamp itself instead of trusting the device's local calendar.
    const ts = now instanceof Date ? now.getTime() : Date.now();
    const bd = new Date(ts + 3 * 60 * 60 * 1000);
    const nowMin = bd.getUTCHours() * 60 + bd.getUTCMinutes();
    if (startMin === endMin) return true; // degenerate/misconfigured — don't silently disable tracking
    if (startMin < endMin) return nowMin >= startMin && nowMin < endMin;
    return nowMin >= startMin || nowMin < endMin; // overnight wrap
  }

  // Bug fix: awayTick() used to run identically in every open tab of this
  // page with no coordination between them (unlike working/breakStartedAt,
  // which already had registerCrossTabSync). If an employee had more than
  // one tab open — common, people duplicate tabs — EACH tab independently
  // noticed the same idle period and independently fired its own warning,
  // all writing the same Firebase record. Over a long idle stretch with
  // several threshold-crossings this multiplies fast (3 tabs × several
  // crossings = the 1→4 / 2→24 jumps reported). This lock makes only one
  // tab at a time — the "leader" — allowed to run the accrual/warning math;
  // the others skip their own tick entirely. Leadership is a simple
  // heartbeat in chrome.storage.local: whichever tab last renewed it within
  // AWAY_LEADER_STALE_MS keeps it, and if that tab closes/freezes, any
  // other open tab picks it up automatically on its next tick.
  const AWAY_LEADER_STALE_MS = IDLE_CHECK_MS * 3; // generous vs. background-tab timer throttling

  function claimAwayLeader() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(["qmAwayTickerLeader"], (data) => {
          const rec = data && data.qmAwayTickerLeader;
          const now = Date.now();
          const iAmAlreadyLeader = rec && rec.tabId === AWAY_TAB_ID;
          const leaderIsStale = !rec || (now - rec.at) > AWAY_LEADER_STALE_MS;
          if (!iAmAlreadyLeader && !leaderIsStale) {
            resolve(false); // someone else holds a fresh lease — sit this tick out
            return;
          }
          chrome.storage.local.set(
            { qmAwayTickerLeader: { tabId: AWAY_TAB_ID, at: now } },
            () => resolve(true)
          );
        });
      } catch (e) {
        resolve(true); // storage unavailable — fail open rather than never accrue at all
      }
    });
  }

  function awayTick() {
    const now = Date.now();
    const delta = awayLastTickAt ? Math.max(0, now - awayLastTickAt) : 0;
    awayLastTickAt = now;
    if (shiftEnded) return; // إنهاء الدوام isn't a real استراحة — doesn't accrue away time

    claimAwayLeader().then((isLeader) => {
      if (!isLeader) return; // another open tab already owns this tick — don't double-count

      // This tab just became (or re-confirmed) leader — re-read the latest
      // persisted totals first, in case a *different* tab was leader a
      // moment ago and moved them forward since this tab's in-memory copy
      // was last updated. Cross-tab sync mirrors these for the UI already,
      // but re-reading here right before the accrual decision closes the
      // remaining race window instead of relying on that propagation.
      chrome.storage.local.get(
        ["qmAwayMsToday", "qmAwayWarnedUpToMs", "qmAwayStreakStartedAt", "qmAwayStreakCountedMs", "qmWarningsToday", "qmOvertimeMsToday"],
        (data) => {
          const key = todayKey();
          if (data && data.qmAwayMsToday && data.qmAwayMsToday.date === key) {
            awayMsToday = data.qmAwayMsToday;
          }
          if (data && typeof data.qmAwayWarnedUpToMs === "number") {
            awayWarnedUpToMs = data.qmAwayWarnedUpToMs;
          }
          if (data && typeof data.qmAwayStreakStartedAt === "number") {
            awayStreakStartedAt = data.qmAwayStreakStartedAt;
          }
          if (data && typeof data.qmAwayStreakCountedMs === "number") {
            awayStreakCountedMs = data.qmAwayStreakCountedMs;
          }
          if (data && data.qmWarningsToday && data.qmWarningsToday.date === key) {
            warningsToday = data.qmWarningsToday;
          }
          if (data && data.qmOvertimeMsToday && data.qmOvertimeMsToday.date === key) {
            overtimeMsToday = data.qmOvertimeMsToday;
          }

          ensureAwayFresh();
          ensureOvertimeFresh();

          const count = getQueueCount();
          if (count !== null && count !== lastQueueCountSeen) {
            lastQueueCountSeen = count;
            lastQueueCountChangedAt = now;
          }
          // count === null (selector miss) intentionally leaves
          // lastQueueCountSeen/lastQueueCountChangedAt untouched — same
          // "don't let a transient DOM miss corrupt the signal" reasoning
          // as elsewhere.

          if (delta > 0 && !isWithinShift(new Date(now))) {
            // Outside this employee's configured shift window: don't run
            // the away/warning system at all — being logged in but idle or
            // on break off-shift isn't a violation of anything, there's no
            // shift to be "away" from. Being logged in AND actively working
            // off-shift, though, is real overtime worth tracking.
            if (working) {
              overtimeMsToday.ms += delta;
              persistLocalState();
            }
            return;
          }

          // Break overrun: limit + 2 min grace (the same countdown the employee
          // sees) ran out and they're still on استراحة -> one warning per break.
          // Only the leader tab gets here, so multiple tabs can't double-fire.
          ensureBreakSessionFresh();
          if (!working && breakStartedAt && !breakWarned &&
              (now - breakStartedAt) >= breakLimitMs + BREAK_GRACE_MS) {
            breakWarned = true; // set first so the persisted state carries it
            addWarning("تجاوز وقت الاستراحة");
          }

          // The "hoarded/stuck queue count while working" cumulative warning
          // ("تجاوز وقت العمل بدون تحديث الطلبات") used to fire here based only
          // on how long queueCount had gone unchanged — with no way to tell a
          // genuinely working employee (mid-batch, just hasn't updated yet)
          // apart from someone actually away. Employees were getting warned
          // while visibly "working" on the admin dashboard, which undermined
          // trust in the whole warning system. Now only a real استراحة
          // overrun (checked just above) produces a warning; this branch no
          // longer runs. The away/streak state below is left in place
          // (still reset on employee/day change elsewhere) but no longer
          // accrues — harmless dead state, kept rather than ripped out to
          // avoid touching the storage/cross-tab-sync plumbing that still
          // reads it.
          if (awayStreakStartedAt !== null) {
            awayStreakStartedAt = null;
            awayStreakCountedMs = 0;
            persistLocalState();
          }
        }
      );
    });
  }

  function startAwayTicker() {
    stopAwayTicker();
    awayLastTickAt = Date.now();
    awayTickerTimer = setInterval(awayTick, IDLE_CHECK_MS);
  }

  function stopAwayTicker() {
    if (awayTickerTimer) clearInterval(awayTickerTimer);
    awayTickerTimer = null;
  }

  // ============================================================
  // Admin override polling (manager can still force working/break)
  // ============================================================
  async function pollAdminForce() {
    const state = await fetchAdminState();
    if (!state) return;

    // Per-employee break duration, set from the dashboard's queue-monitor tab.
    const nextBreakMs = (typeof state.breakLimitMinutes === "number" && state.breakLimitMinutes > 0)
      ? state.breakLimitMinutes * 60 * 1000
      : DEFAULT_BREAK_LIMIT_MS;
    if (nextBreakMs !== breakLimitMs) {
      breakLimitMs = nextBreakMs;
      renderToggleButton(); // reflect new countdown immediately
    }

    // Per-employee shift window, set from the dashboard's queue-monitor tab.
    // null/null means "not set" — away/warning tracking stays always-on.
    shiftStart = (typeof state.shiftStart === "string") ? state.shiftStart : null;
    shiftEnd = (typeof state.shiftEnd === "string") ? state.shiftEnd : null;

    // All-time إنذار badge — see remoteWarningCount declaration above.
    const nextWarningCount = (typeof state.warningCount === "number") ? state.warningCount : 0;
    remoteWarningsList = Array.isArray(state.warnings) ? state.warnings : [];
    if (nextWarningCount !== remoteWarningCount) {
      remoteWarningCount = nextWarningCount;
      renderToggleButton(); // reflect a new/reset إنذار count immediately
    }

    const force = state.adminForce || null;
    if (force !== lastAdminForce) {
      lastAdminForce = force;
      // Persist immediately so a stuck/never-released admin force isn't
      // treated as "new" again on the next login/reload (see restoreLocalState).
      persistLocalState();

      if (force === "ended") {
        // admin ended the shift — force off work and block toggling back
        // to عمل until the admin releases them (clears adminForce).
        shiftEnded = true;
        if (working) setWorking(false, { fromAdmin: true });
        stopBreakClock();
        breakStartedAt = null; // not a real استراحة — no countdown/warning applies
        breakWarned = false;
        persistLocalState();
        renderToggleButton();
      } else {
        // Bug fix: this used to check `force === "working"`/`force === "break"`
        // and, separately, `else if (shiftEnded)` to handle a release from a
        // previously-ended shift. If an admin clicked "force work" (or
        // "force break") directly on an employee who was already in the
        // "ended" state — without first clicking "release" — both branches
        // ran in the same poll: setWorking(true) correctly flipped working
        // to true, but the shiftEnded-release branch then ALSO ran right
        // after it (since force !== "ended"), stomping breakStartedAt back
        // to Date.now() and starting the break clock even though the
        // employee had just been marked as working. Clearing shiftEnded
        // first and only falling back to the "resume on break" behavior
        // when the admin didn't also specify an explicit working/break
        // force keeps the two effects from fighting each other.
        const wasShiftEnded = shiftEnded;
        if (wasShiftEnded) shiftEnded = false;

        if (force === "working" && !working) {
          setWorking(true, { fromAdmin: true });
        } else if (force === "break" && working) {
          setWorking(false, { fromAdmin: true });
        } else if (wasShiftEnded) {
          // released with no explicit working/break force — resume as a
          // normal استراحة (employee still needs to press "بدء العمل" themselves).
          breakStartedAt = Date.now();
          breakWarned = false;
          currentSessionType = "break";
          currentSessionStartedAt = breakStartedAt;
          startBreakClock();
        }

        if (wasShiftEnded) {
          persistLocalState();
          renderToggleButton();
        }
      }
    }

    // Instant popup pushed from the admin dashboard for this employee.
    if (state.popup && state.popup.id && state.popup.id !== lastShownPopupId) {
      showAdminPopup(state.popup);
    }

    // Admin pressed "🧹 تصفير التحذيرات" — only act on a *newer* timestamp
    // than the last one we already applied, since resetWarningsAt stays
    // set in Firebase indefinitely (it's not cleared after use). Without
    // this guard every poll after a reset would keep wiping out any new
    // warning that accrues afterward, forever.
    if (typeof state.resetWarningsAt === "number" && state.resetWarningsAt > lastAppliedWarningReset) {
      lastAppliedWarningReset = state.resetWarningsAt;
      warningsToday = { date: todayKey(), count: 0 };
      // (breakWarned intentionally left as-is: clearing it would re-fire the
      // overrun warning within seconds for a break that is already past its limit.)
      // Without this, awayMsToday.ms stays above the threshold that just
      // got "reset", and the very next awayTick() (within IDLE_CHECK_MS)
      // would fire a fresh warning right back — silently undoing the
      // admin's reset click.
      awayMsToday = { date: todayKey(), ms: 0 };
      awayWarnedUpToMs = 0;
      persistLocalState();
      renderToggleButton();
      scheduleReport(); // push the cleared count back to the dashboard promptly
    }
  }
  setInterval(pollAdminForce, ADMIN_POLL_MS);

  // ============================================================
  // Mount the panel inline, right next to the header's global search bar
  // (div.search-bar.flex-grow-1), which only exists once in the top
  // document's header — avoids the iframe-duplication issue entirely.
  function findAnchorButtons() {
    const byClass = document.querySelector(".search-bar.flex-grow-1");
    if (byClass) return [byClass];
    return [];
  }

  function buildToggleButton() {
    const btn = document.createElement("button");
    btn.id = "qm-toggle-btn";
    btn.type = "button";
    btn.style.cssText = `
      padding: 4px 14px; border: none; border-radius: 30px;
      font-size: 13px; font-weight: 700; font-family: inherit;
      cursor: pointer; white-space: nowrap;
    `;
    btn.onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (shiftEnded) return; // button already reads "بانتظار المشرف" and is disabled
      if (working) {
        const elapsed = Date.now() - (workStartedAt || Date.now());
        if (elapsed < MIN_WORK_BEFORE_BREAK_MS) return; // button already shows the unlock countdown
      }
      setWorking(!working);
    };
    return btn;
  }

  // Read-only STATUS pill — tells the employee what state they are in right
  // now. The button next to it is purely the ACTION (what pressing does).
  // Before, one button tried to be both, with a green dot on a red
  // background while working, which is what made the state ambiguous.
  function buildStatusPill() {
    const pill = document.createElement("span");
    pill.id = "qm-status-pill";
    pill.style.cssText = `
      padding: 4px 12px; border-radius: 30px; font-size: 13px; font-weight: 800;
      font-family: inherit; white-space: nowrap; display: inline-block;
      user-select: none;
    `;
    return pill;
  }

  function buildWarningBadge() {
    const badge = document.createElement("span");
    badge.id = "qm-warning-badge";
    badge.style.cssText = `
      padding: 2px 8px; border-radius: 30px; font-size: 12px; font-weight: 700;
      font-family: inherit; white-space: nowrap; display: inline-block;
      background: #fee2e2; color: #b91c1c;
    `;
    return badge;
  }

  function buildQueueCountBadge() {
    const badge = document.createElement("span");
    badge.id = "qm-queue-badge";
    badge.style.cssText = `
      padding: 2px 8px; border-radius: 30px; font-size: 12px; font-weight: 700;
      font-family: inherit; white-space: nowrap; display: inline-block;
      background: #dbeafe; color: #1d4ed8;
    `;
    return badge;
  }

  function mountToggleButton() {
    if (document.getElementById("qm-panel")) {
      renderToggleButton();
      return;
    }

    const anchorBtn = findAnchorButtons()[0];
    if (!anchorBtn) return;

    const panel = document.createElement("div");
    panel.id = "qm-panel";
    panel.style.cssText = `
      display: inline-flex; align-items: center; gap: 8px;
      padding: 5px 10px; border-radius: 12px; margin-inline-start: 8px;
      background: rgba(15, 23, 42, 0.28);
      vertical-align: middle; direction: rtl;
    `;

    const badge = buildWarningBadge();
    const btn = buildToggleButton();
    const pill = buildStatusPill();
    const queueBadge = buildQueueCountBadge();
    panel.appendChild(pill);
    panel.appendChild(btn);
    panel.appendChild(queueBadge);
    panel.appendChild(badge);

    anchorBtn.insertAdjacentElement("afterend", panel);

    renderToggleButton();
  }

  function flashMessage(text, durationMs = 1200) {
    const btn = document.getElementById("qm-toggle-btn");
    if (!btn) return;
    flashActive = true;
    btn.textContent = text;
    btn.style.background = "linear-gradient(135deg,#64748b,#94a3b8)";
    clearTimeout(btn._lockHintTimer);
    btn._lockHintTimer = setTimeout(() => {
      flashActive = false;
      renderToggleButton(); // recompute from current state, not a stale captured snapshot
    }, durationMs);
  }

  function formatCountdown(ms) {
    const total = Math.max(0, Math.floor(ms / 1000));
    const m = Math.floor(total / 60);
    const s = total % 60;
    return `${m}:${String(s).padStart(2, "0")}`;
  }

  // Ticks once a second only while the "استراحة" button is still locked
  // (first 10 min of work), so the unlock countdown moves. Stops itself.
  let lockTickTimer = null;
  function stopLockClock() {
    if (lockTickTimer) clearInterval(lockTickTimer);
    lockTickTimer = null;
  }
  function startLockClock() {
    stopLockClock();
    if (!working || !workStartedAt) return;
    if (Date.now() - workStartedAt >= MIN_WORK_BEFORE_BREAK_MS) return;
    lockTickTimer = setInterval(() => {
      if (!working || !workStartedAt || Date.now() - workStartedAt >= MIN_WORK_BEFORE_BREAK_MS) stopLockClock();
      renderToggleButton();
    }, TICK_MS);
  }

  function renderToggleButton() {
    const btn = document.getElementById("qm-toggle-btn");
    const badge = document.getElementById("qm-warning-badge");
    const queueBadge = document.getElementById("qm-queue-badge");
    if (!btn) return;

    // Bug fix: warningsToday.date used to only refresh when a new warning
    // actually fired or the page reloaded. An employee working straight
    // through midnight with no warning/refresh kept reporting yesterday's
    // date, silently freezing their warning count instead of rolling it
    // over. renderToggleButton() already runs every 10s regardless of
    // activity (see the setInterval in init()), so checking here is enough
    // to catch the rollover promptly without a dedicated timer.
    ensureWarningsFresh();
    ensureBreakSessionFresh();

    // queue count badge — how many orders (rows in تحت التدقيق) this employee currently has
    const n = getQueueCount(); // also reused below for the on-break reminder — real value, untouched by the smoothing below
    if (n !== null) {
      lastKnownQueueCount = n;
      lastKnownQueueCountAt = Date.now();
    }
    if (queueBadge) {
      const staleButRecent = n === null && lastKnownQueueCount !== null &&
        (Date.now() - lastKnownQueueCountAt) < QUEUE_COUNT_STALE_GRACE_MS;
      if (n !== null) {
        queueBadge.textContent = `📋 ${n}`;
        queueBadge.title = `عدد الطلبات الحالية: ${n}`;
      } else if (staleButRecent) {
        queueBadge.textContent = `📋 ${lastKnownQueueCount}`;
        queueBadge.title = `آخر عدد معروف: ${lastKnownQueueCount} (يجري التحديث...)`;
      } else {
        queueBadge.textContent = `📋 ?`;
        queueBadge.title = "تعذر قراءة عدد الطلبات الحالية على هذه الصفحة الآن";
      }
    }

    // warning badge — the all-time إنذار total (automatic + manual, see
    // remoteWarningCount above), not the local same-day count. The daily
    // count still separately decides the ">3 today" eval-impact styling.
    if (badge) {
      if (remoteWarningCount > 0) {
        const overEval = warningsToday.count > 3;
        badge.style.display = "inline-block";
        badge.textContent = `⚠️ ${remoteWarningCount}`;
        // Hover tooltip lists every reason, not just the count — same
        // warnings/{pushId} log the admin dashboard's own badge tooltip
        // reads (see warnings in /queuemonitor/state above).
        const reasonLines = remoteWarningsList.length
          ? remoteWarningsList.map(w => {
              const when = w && w.createdAt ? new Date(w.createdAt).toLocaleString("ar-IQ") : "—";
              return `${when} — ${(w && w.text) || "بدون سبب مذكور"}`;
            }).join("\n")
          : "لا توجد تفاصيل مسجلة";
        badge.title = `${remoteWarningCount} إنذار إجمالاً${overEval ? ` — ${warningsToday.count} اليوم، سيؤثر على التقييم` : ""}\n\n${reasonLines}`;
        badge.style.background = overEval ? "#fecaca" : "#fee2e2";
        badge.style.color = overEval ? "#7f1d1d" : "#b91c1c";
      } else {
        badge.style.display = "none";
      }
    }

    // Bug fix: flashMessage() used to capture the button's text/color at
    // click time and restore it verbatim after its timeout. But this
    // function also runs on its own timers in between (every 10s always,
    // every 1s while on break) — so if the real state changed during that
    // window, the flash's restore overwrote it with stale text, leaving the
    // button showing wrong info for up to 10 seconds. Skipping the
    // text-setting logic below while a flash is active — and having
    // flashMessage() call this function fresh when it expires, instead of
    // restoring its own stale snapshot — keeps the button always reflecting
    // current state once the flash clears.
    if (flashActive) return;

    const pill = document.getElementById("qm-status-pill");
    const setPill = (text, bg, color, title) => {
      if (!pill) return;
      pill.textContent = text;
      pill.style.background = bg;
      pill.style.color = color;
      pill.title = title || "";
    };
    const setAction = (text, bg, color, title, disabled) => {
      btn.textContent = text;
      btn.style.background = bg;
      btn.style.color = color;
      btn.title = title || "";
      btn.disabled = !!disabled;
      btn.style.cursor = disabled ? "not-allowed" : "pointer";
      btn.style.opacity = disabled ? "0.75" : "1";
    };

    if (shiftEnded) {
      setPill("⏹️ انتهى الدوام", "#475569", "#fff", "انتهى الدوام لهذا اليوم — بانتظار المشرف");
      setAction("بانتظار المشرف", "#cbd5e1", "#334155", "", true);
      return;
    }

    if (working) {
      setPill("🟢 يعمل الآن", "#16a34a", "#fff", "أنت الآن في وضع العمل");
      const lockLeft = MIN_WORK_BEFORE_BREAK_MS - (Date.now() - (workStartedAt || Date.now()));
      if (lockLeft > 0) {
        // Disabled until MIN_WORK_BEFORE_BREAK_MS passes. No timer/hint shown —
        // lockTick re-renders in the background and enables it when time is up.
        setAction("☕ أخذ استراحة", "#cbd5e1", "#334155", "", true);
        if (!lockTickTimer) startLockClock();
      } else {
        setAction("☕ أخذ استراحة", "#ffffff", "#0f172a", "اضغط لأخذ استراحة", false);
      }
      return;
    }

    // on break
    const waitingNote = (typeof n === "number" && n > 0) ? ` · ${n} طلب بانتظارك` : "";
    // Break stages, driven by the per-employee limit from the dashboard:
    //   1) countdown of breakLimitMs
    //   2) "وقت سماح" countdown of BREAK_GRACE_MS (2 min)
    //   3) warning fires (see awayTick) and the pill turns red
    // Outside the employee's configured shift no warning applies, so no timer.
    const breakElapsed = breakStartedAt ? Date.now() - breakStartedAt : 0;
    const graceEndsAt = breakLimitMs + BREAK_GRACE_MS;
    if (!isWithinShift(new Date())) {
      setPill("☕ في استراحة", "#f59e0b", "#7c2d12", "");
    } else if (breakWarned || breakElapsed >= graceEndsAt) {
      setPill("🔴 تجاوزت الوقت", "#dc2626", "#fff", "تم تسجيل تحذير");
    } else if (breakElapsed >= breakLimitMs) {
      setPill(`⏰ وقت سماح · ${formatCountdown(graceEndsAt - breakElapsed)}`, "#ea580c", "#fff", "");
    } else {
      setPill(`☕ في استراحة · ${formatCountdown(breakLimitMs - breakElapsed)}`, "#f59e0b", "#7c2d12", "");
    }
    setAction(`▶ بدء العمل${waitingNote}`, "#16a34a", "#fff",
      waitingNote ? `عندك ${n} طلب بانتظارك — اضغط لبدء العمل` : "اضغط لبدء العمل", false);
  }

  // ============================================================
  // Cross-tab sync
  // ============================================================
  // chrome.storage.local is shared by every tab in the same browser
  // profile, but each tab keeps its own in-memory copy of working/
  // breakStartedAt/etc — nothing previously kept them in sync, so
  // toggling to "عمل" in one tab left any other open tab still
  // believing it was on استراحة, with its own break-clock timer still
  // ticking down toward a warning the employee never actually earned.
  // This listens for storage changes written by ANY tab (including
  // this one — see the "already in sync" no-op check below, which
  // makes this safe to receive our own writes too) and re-applies them
  // immediately, so every open tab reflects the same state within
  // milliseconds instead of only on next page load or admin poll.
  function registerCrossTabSync() {
    if (!chrome.storage || !chrome.storage.onChanged) return;
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      const relevantKeys = ["qmWorking", "qmBreakStartedAt", "qmWorkStartedAt", "qmBreakWarned", "qmShiftEnded", "qmEmployeeName", "qmWarningsToday", "qmAwayMsToday", "qmAwayWarnedUpToMs", "qmOvertimeMsToday"];
      if (!relevantKeys.some((k) => k in changes)) return;

      // Bug fix: chrome.storage.onChanged doesn't guarantee delivery order
      // relative to this tab's OWN subsequent writes. If the employee
      // double/triple-clicks the toggle fast enough, a second click can
      // change local memory (and fire its own write) before the first
      // click's write echoes back here. When that late echo arrives, plain
      // value-equality can't tell "stale echo of a write I've since
      // superseded" apart from "genuinely newer change from another tab" —
      // memory has already moved on, so the stale echo looks exactly like
      // an external change and gets applied, silently reverting the
      // employee to an older state (and re-persisting it from there,
      // corrupting every tab). qmStateVersion only ever increases, so a
      // change whose version isn't newer than what this tab already
      // applied is always safe to ignore.
      if ("qmStateVersion" in changes) {
        const incomingVersion = changes.qmStateVersion.newValue;
        if (typeof incomingVersion === "number" && incomingVersion <= lastAppliedStateVersion) {
          return;
        }
      }

      // If this change is tagged for a different employee than the one this
      // tab is tracking, ignore it (shouldn't normally happen mid-session).
      const newEmployeeName = "qmEmployeeName" in changes ? changes.qmEmployeeName.newValue : currentEmployeeName;
      if (currentEmployeeName && newEmployeeName && newEmployeeName !== currentEmployeeName) return;

      const newWorking = "qmWorking" in changes ? !!changes.qmWorking.newValue : working;
      const newBreakStartedAt = "qmBreakStartedAt" in changes ? (changes.qmBreakStartedAt.newValue || null) : breakStartedAt;
      const newWorkStartedAt = "qmWorkStartedAt" in changes ? (changes.qmWorkStartedAt.newValue || null) : workStartedAt;
      const newBreakWarned = "qmBreakWarned" in changes ? !!changes.qmBreakWarned.newValue : breakWarned;
      const newShiftEnded = "qmShiftEnded" in changes ? !!changes.qmShiftEnded.newValue : shiftEnded;
      // These three are informational-only for a non-leader tab (see
      // claimAwayLeader/awayTick) — just keep the badge/UI accurate here,
      // the actual accrual math only ever runs in whichever tab currently
      // holds the leader lease.
      if ("qmWarningsToday" in changes && changes.qmWarningsToday.newValue) {
        warningsToday = changes.qmWarningsToday.newValue;
      }
      if ("qmAwayMsToday" in changes && changes.qmAwayMsToday.newValue) {
        awayMsToday = changes.qmAwayMsToday.newValue;
      }
      if ("qmAwayWarnedUpToMs" in changes && typeof changes.qmAwayWarnedUpToMs.newValue === "number") {
        awayWarnedUpToMs = changes.qmAwayWarnedUpToMs.newValue;
      }
      if ("qmOvertimeMsToday" in changes && changes.qmOvertimeMsToday.newValue) {
        overtimeMsToday = changes.qmOvertimeMsToday.newValue;
      }

      // Record that we've now seen at least this version, whether or not
      // anything below actually changes — otherwise a later stale echo at
      // this same version could slip past the check above.
      if ("qmStateVersion" in changes && typeof changes.qmStateVersion.newValue === "number") {
        lastAppliedStateVersion = changes.qmStateVersion.newValue;
      }

      // Already matches what this tab already has (e.g. this event is just
      // this same tab's own write echoing back) — nothing to do for
      // timers/toggle state. warningsToday/awayMsToday/awayWarnedUpToMs are
      // applied above unconditionally and get their own repaint here
      // regardless, since they don't affect which timers should be running.
      if (
        newWorking === working &&
        newBreakStartedAt === breakStartedAt &&
        newWorkStartedAt === workStartedAt &&
        newBreakWarned === breakWarned &&
        newShiftEnded === shiftEnded
      ) {
        renderToggleButton();
        return;
      }

      console.info("[queuemonitor] state changed in another tab — syncing this tab to match");
      working = newWorking;
      breakStartedAt = newBreakStartedAt;
      workStartedAt = newWorkStartedAt;
      breakWarned = newBreakWarned;
      shiftEnded = newShiftEnded;

      // Don't re-report the session event or push a new report here — the
      // tab where the toggle actually happened already did that. This tab
      // just needs its own timers/UI to reflect reality.
      stopBreakClock();
      stopLockClock();
      if (working && !shiftEnded) startLockClock();
      stopIdleCheck(); // this tab isn't the one that toggled — just stop its own idle timer, cross-tab sync doesn't need it to fire here
      if (!working && breakStartedAt && !shiftEnded) startBreakClock();
      renderToggleButton();
    });
  }

  // ============================================================
  // Init
  // ============================================================
  function init() {
    registerCrossTabSync();
    restoreLocalState().then(() => {
      mountToggleButton();
      // Bug fix: this used to disconnect the observer for good the first
      // time the button was found mounted. That's fine as long as the panel
      // stays in the DOM forever, but this CRM's header is an SPA-style
      // region that can re-render later (common on these pages) — if it
      // does, the panel gets removed and, with the observer already gone,
      // nothing ever remounts it: the toggle UI disappears for the rest of
      // the session (only a full page reload brings it back), even though
      // the background reporting keeps running invisibly. Keeping the
      // observer alive lets mountToggleButton() re-run (and re-mount, since
      // it already no-ops when "#qm-panel" is still present) on every
      // future DOM change, so the panel self-heals instead of needing a
      // reload.
      // Bug fix (round 2): the self-heal fix above was right that the
      // observer shouldn't disconnect for good, but calling
      // mountToggleButton() directly on every mutation record was too
      // expensive — this CRM page (CasesFollowUp) mutates its own DOM
      // constantly (live tables, polling widgets), so with
      // subtree:true/childList:true on document.documentElement this fired
      // on nearly every DOM twitch anywhere on the page. Since the panel
      // normally already exists, mountToggleButton() fell straight through
      // to renderToggleButton() -> getQueueCount(), which runs several
      // querySelector calls across the whole document plus a loop over
      // every iframe trying to read contentDocument — real work, repeated
      // dozens/hundreds of times a second on a busy page, which is exactly
      // what froze the tab ("Page Unresponsive"). renderToggleButton()
      // already runs on its own timers (every 10s, plus every 1s while on
      // break) — it doesn't need to also run on every unrelated mutation.
      // All the self-heal behavior actually needs is a cheap, debounced
      // check for whether "#qm-panel" is still there, and to only pay for
      // a real mount attempt when it truly isn't.
      let mountCheckTimer = null;
      const mountObserver = new MutationObserver(() => {
        if (mountCheckTimer) return; // a check is already scheduled — this mutation will be covered by it
        mountCheckTimer = setTimeout(() => {
          mountCheckTimer = null;
          if (!document.getElementById("qm-panel")) mountToggleButton();
        }, 300);
      });
      mountObserver.observe(document.documentElement, {
        childList: true,
        subtree: true,
      });
      if (working) { startIdleCheck(); startLockClock(); }
      else if (breakStartedAt) startBreakClock();
      startAwayTicker(); // always on, independent of working/break toggling — see awayTick()

      // Open the initial session record for this page load, using the
      // REAL start time restored from storage — not Date.now(). Bug fix:
      // this used to always stamp Date.now() here, so if an employee
      // worked for 4 hours and then refreshed the tab, the next session-
      // close event would report only "since the refresh" as the work
      // duration, silently truncating the logged session length.
      currentSessionType = working ? "work" : "break";
      currentSessionStartedAt = working ? (workStartedAt || Date.now()) : (breakStartedAt || Date.now());

      scheduleReport();
      pollAdminForce();
      // keep the order-count badge live as رows are claimed/finished
      setInterval(renderToggleButton, 10000);
      // and push that same live count to the admin dashboard periodically —
      // reportState() otherwise only fires on toggle/warning, so without this
      // the dashboard's count freezes at whatever it was when work started
      // even though the employee's own page count keeps changing.
      setInterval(reportState, LIVE_REPORT_MS);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();

/*
 * content-queuemonitor.js  (simplified — no auto-claim)
 * -------------------------------------------------------------
 * Adds a floating "بدء العمل / استراحة" toggle on the CasesFollowUp page.
 *
 * Employee flow:
 *  - يضغط "بدء العمل" ويبدأ يعالج الطلبات بنفسه بشكل طبيعي (لا يوجد
 *    auto-claim بعد الآن — كان هذا الجزء غير مستقر وتم حذفه).
 *  - عند الانتهاء يضغط "استراحة" — يبدأ عداد 15:00 ظاهر على الزر.
 *  - لو ما رجع "بدء العمل" قبل ما ينتهي الـ 15 دقيقة، عنده سماحية
 *    دقيقتين إضافيتين (Grace). لو انتهت الدقيقتين وبعده ما رجع،
 *    يسجل له تحذير (warning) واحد لهذا الاستراحة.
 *  - عدد التحذيرات اليوم يظهر كـ badge صغير جنب زر "بدء العمل".
 *  - أكثر من 3 تحذيرات باليوم = يُبلّغ عنها في Firebase عشان لوحة
 *    التحكم تقدر تنزل تقييمه (المنطق نفسه على الداشبورد لسه لازم يُضاف
 *    لو تبيه يظهر هناك أيضاً).
 *
 * الحماية من "يضغط بدء العمل ويسيب الجهاز":
 *  - كل 5 دقائق (IDLE_CHECK_INTERVAL_MS) وهو working=true، نتأكد من
 *    عدد الصفوف في "تحت التدقيق". لو العدد > 5 => شغّال فعلاً.
 *    لو <= 5 => يتحول تلقائياً لـ "استراحة" (ونفس عداد الـ 15+2 يبدأ
 *    من هناك، فلو فعلاً غايب راح ياخذ تحذير تلقائياً).
 *
 * ⚠ REQUIRES CONFIGURATION BELOW before this does anything useful.
 */

(function () {
  "use strict";

  // This page embeds copies of itself inside iframes (e.g. the
  // "Needs-revision-branch-customers" / "under-revision-by-emp" iframes),
  // each with its own #smarty_cancelFilter button. Content scripts run in
  // every frame by default, so without this guard the panel gets mounted
  // once per frame — which is why it was showing up duplicated. Only run
  // in the actual top-level tab.
  if (window.top !== window.self) {
    return;
  }

  // ============================================================
  // CONFIG
  // ============================================================
  const RELAY_BASE = "https://pbx.mutabaa.online";

  const REPORT_DEBOUNCE_MS = 800;       // debounce DOM-triggered reports
  const DEFAULT_BREAK_LIMIT_MS = 15 * 60 * 1000; // 15 min default; admin can override per-employee
  const BREAK_GRACE_MS = 2 * 60 * 1000;     // +2 min grace before a warning
  const IDLE_CHECK_INTERVAL_MS = 5 * 60 * 1000; // ASSUMPTION — adjust if needed
  const IDLE_QUEUE_THRESHOLD = 5;       // > this => confirmed working
  const MIN_WORK_BEFORE_BREAK_MS = 10 * 60 * 1000; // must work 10min before "استراحة" is allowed
  const TICK_MS = 1000;                 // countdown UI refresh
  const ADMIN_POLL_MS = 5000;           // was 15000 — shorter so admin popups/break changes land fast
  const LIVE_REPORT_MS = 20 * 1000;     // push fresh queueCount to Firebase periodically, not just on toggle

  // Selectors confirmed against the CasesFollowUp page
  const SEL = {
    underRevisionTableBody:
      '#smarty_table_com_dot_app_dot_bussframework_dot_SingleQueue_AGENTOP_UnderRevisionByEmp tbody',
  };

  if (!location.pathname.includes("/tickets/CasesFollowUp")) return;

  // ============================================================
  // State
  // ============================================================
  let working = false;
  let breakStartedAt = null;     // when the current استراحة started
  let breakWarned = false;       // did this break session already earn a warning?
  let warningsToday = { date: todayKey(), count: 0 };

  let breakTickTimer = null;
  let idleCheckTimer = null;
  let reportDebounceTimer = null;
  let lastAdminForce = null;
  let breakLimitMs = DEFAULT_BREAK_LIMIT_MS; // may be overridden per-employee from the dashboard
  let lastShownPopupId = null; // dedupe so the same admin popup isn't shown twice
  let workStartedAt = null;      // when the current "يعمل الآن" session started (for the 10min lock)
  let shiftEnded = false;        // admin forced "إنهاء الدوام" — blocks toggling back to عمل until released
  let currentEmployeeName = null; // whoever restoreLocalState() last resolved via getEmployeeName()
  let lastAppliedWarningReset = 0; // last resetWarningsAt timestamp already applied — see pollAdminForce()

  function todayKey() {
    const d = new Date();
    return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
  }

  function getEmployeeName() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(["mutabaaRawName"], (data) => {
          resolve((data && data.mutabaaRawName) || null);
        });
      } catch (e) {
        resolve(null);
      }
    });
  }

  let queueSelectorWarned = false;

  function findQueueBody(doc) {
    // 1) exact selector confirmed on the normal CasesFollowUp page
    let body = doc.querySelector(SEL.underRevisionTableBody);

    // 2) fallback for variants like ?superVisiorsSearch=1, where the table
    //    gets a different id — match loosely on the id fragment that's
    //    stable across them ("UnderRevisionByEmp"). Deliberately NOT falling
    //    back further to a generic "smarty_table_" or "table tbody" match:
    //    this CRM uses "smarty_table_" as a generic naming pattern shared by
    //    other tables (e.g. the pool/"Needs-revision-branch-customers" queue),
    //    so a broader match can silently return a different table's count
    //    instead of correctly reporting 0.
    if (!body) {
      body = doc.querySelector('table[id*="UnderRevisionByEmp"] tbody')
        || doc.querySelector('[id*="UnderRevisionByEmp"] tbody');
    }

    // 3) last-resort fallback: some page variants render the same queue
    //    under a completely different generated id, but the visible column
    //    headers still say "تحت التدقيق" (or similar). Walk every table on
    //    the page, look at its header row text, and use the first one whose
    //    headers mention the queue name.
    if (!body) {
      const tables = Array.from(doc.querySelectorAll("table"));
      const match = tables.find((t) => {
        const headerRow = t.querySelector("thead tr, tr");
        if (!headerRow) return false;
        const headerText = headerRow.textContent || "";
        return headerText.includes("تحت التدقيق") || headerText.includes("التدقيق");
      });
      if (match) body = match.querySelector("tbody") || match;
    }

    return body;
  }

  function countQueueRows(body) {
    const rows = Array.from(body.querySelectorAll("tr"));
    // prefer the "pointer" class seen on real order rows, since it excludes
    // header rows and empty-state rows more reliably than checking for <td>
    const pointerRows = rows.filter((tr) => tr.classList.contains("pointer"));
    if (pointerRows.length > 0) return pointerRows.length;
    // fall back to "has a data cell at all", in case a page variant doesn't
    // use the pointer class
    return rows.filter((tr) => tr.querySelector("td")).length;
  }

  function getQueueCount() {
    // 1) the top-level document — works when the table isn't inside an iframe
    let body = findQueueBody(document);
    if (body) return countQueueRows(body);

    // 2) the table may be rendered inside a same-origin iframe; this script
    //    only *mounts its UI* in the top frame (see the window.top guard
    //    above), but it can still reach into same-origin iframe documents
    //    from here to read their DOM.
    const iframes = document.querySelectorAll("iframe");
    for (let i = 0; i < iframes.length; i++) {
      try {
        const doc = iframes[i].contentDocument || iframes[i].contentWindow.document;
        if (!doc) continue;
        body = findQueueBody(doc);
        if (body) return countQueueRows(body);
      } catch (e) {
        // cross-origin iframe — can't be read from here, skip it
      }
    }

    if (!queueSelectorWarned) {
      queueSelectorWarned = true;
      console.warn(
        "[queuemonitor] couldn't find the تحت التدقيق table on this page or in any " +
        "readable iframe (neither the exact id nor fallbacks matched) — " +
        "📋 will show 0 until the selector is updated for this page."
      );
    }
    return 0;
  }

  // ============================================================
  // Pool count ("شحنات فرعي بانتظار التدقيق")
  // ============================================================
  // Unlike getQueueCount() this isn't a table of rows — it's the
  // ready-made nav-tab counter badge for the "Needs-revision-branch-
  // customers" tab: <span id="cases_counter-branch-customers">N</span>,
  // rendered in the top-level document (not inside an iframe).
  let poolSelectorWarned = false;

  function getPoolCount() {
    // 1) exact id confirmed via devtools
    let el = document.getElementById("cases_counter-branch-customers");

    // 2) fallback: same id pattern, but just in case it ever gets
    //    namespaced/prefixed differently on some page variant
    if (!el) {
      el = document.querySelector('[id*="cases_counter-branch-customers"]');
    }

    // 3) last-resort fallback: walk every ".normal-count" badge and use
    //    the one whose ".title-with-counter" label mentions "فرعي"
    //    (the "شحنات فرعي" pool tab specifically, not some other counter).
    if (!el) {
      const candidates = Array.from(document.querySelectorAll(".title-with-counter"));
      const match = candidates.find((c) => (c.textContent || "").includes("فرعي"));
      if (match) el = match.querySelector(".normal-count, span");
    }

    if (!el) {
      if (!poolSelectorWarned) {
        poolSelectorWarned = true;
        console.warn(
          "[queuemonitor] couldn't find the شحنات فرعي pool counter badge " +
          "(#cases_counter-branch-customers) — poolCount will be omitted until " +
          "the selector is updated for this page."
        );
      }
      return null;
    }

    const n = parseInt((el.textContent || "").trim(), 10);
    return Number.isNaN(n) ? null : n;
  }

  // ============================================================
  // Relay calls
  // ============================================================
  async function reportState() {
    const name = await getEmployeeName();
    if (!name) return;

    // Logged-in employee changed without a full page reload (e.g. the CRM
    // swapped sessions in place) — reset local state before reporting
    // anything under the new name, same as the startup check in
    // restoreLocalState(), so warnings/break state never leak between
    // employees sharing a device.
    if (currentEmployeeName && name !== currentEmployeeName) {
      console.warn(
        `[queuemonitor] logged-in employee changed mid-session (${currentEmployeeName} → ${name}) — resetting local state`
      );
      currentEmployeeName = name;
      working = false;
      breakStartedAt = null;
      workStartedAt = null;
      shiftEnded = false;
      warningsToday = { date: todayKey(), count: 0 };
      lastShownPopupId = null;
      lastAdminForce = null; // force a fresh read of this employee's own adminForce on next poll
      lastAppliedWarningReset = 0; // different employee — their own resetWarningsAt history doesn't apply
      stopBreakClock();
      stopIdleCheck();
      persistLocalState();
      renderToggleButton();
    } else if (!currentEmployeeName) {
      currentEmployeeName = name;
    }

    const payload = {
      employeeName: name,
      queueCount: getQueueCount(),
      working,
      breakStartedAt: working ? null : breakStartedAt,
      warningsToday: warningsToday.count,
      warningsDate: warningsToday.date,
    };

    const poolCount = getPoolCount();
    if (poolCount !== null) payload.poolCount = poolCount;

    try {
      await fetch(`${RELAY_BASE}/queuemonitor/report`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
    } catch (e) {
      console.warn("[queuemonitor] report failed", e);
    }
  }

  function scheduleReport() {
    clearTimeout(reportDebounceTimer);
    reportDebounceTimer = setTimeout(reportState, REPORT_DEBOUNCE_MS);
  }

  async function fetchAdminState() {
    const name = await getEmployeeName();
    if (!name) return null;
    try {
      const res = await fetch(
        `${RELAY_BASE}/queuemonitor/state?employeeName=${encodeURIComponent(name)}`
      );
      if (!res.ok) return null;
      return await res.json(); // { adminForce, targetAssign, breakLimitMinutes, popup }
    } catch (e) {
      return null;
    }
  }

  // ============================================================
  // Warnings
  // ============================================================
  function ensureWarningsFresh() {
    const key = todayKey();
    if (warningsToday.date !== key) {
      warningsToday = { date: key, count: 0 };
      persistLocalState();
    }
  }

  function addWarning() {
    ensureWarningsFresh();
    warningsToday.count += 1;
    persistLocalState();
    renderToggleButton();
    scheduleReport();
    console.warn(`[queuemonitor] تحذير #${warningsToday.count} اليوم — تجاوز وقت الاستراحة`);
  }

  // ============================================================
  // Working / break switching
  // ============================================================
  // Tracks the currently-open session so we can close it out (with an end
  // time) the moment the employee flips state again. Sent to the relay as
  // its own event — separate from reportState()'s live snapshot — so the
  // admin dashboard can show a full history, not just "what's true right now".
  // NOTE: this POSTs to /queuemonitor/session; relay.js needs a handler that
  // appends each event under queueSessions/{owner}/{employeeKey}/{pushId} in
  // Firebase (mirroring how it already writes queueMonitor/*). That handler
  // isn't in this file, so add it on the relay side for this to show up.
  let currentSessionStartedAt = null;
  let currentSessionType = null; // 'work' | 'break'

  async function reportSessionEvent(type, startedAt, endedAt) {
    const name = await getEmployeeName();
    if (!name) return;
    try {
      await fetch(`${RELAY_BASE}/queuemonitor/session`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ employeeName: name, type, startedAt, endedAt }),
      });
    } catch (e) {
      console.warn("[queuemonitor] session report failed", e);
    }
  }

  function setWorking(nextWorking, { fromAdmin = false, fromIdle = false } = {}) {
    const now = Date.now();

    // close out whatever session was open before flipping
    if (currentSessionType) {
      reportSessionEvent(currentSessionType, currentSessionStartedAt, now);
    }

    working = nextWorking;
    if (working) {
      breakStartedAt = null;
      breakWarned = false;
      workStartedAt = now;
      stopBreakClock();
      startIdleCheck();
    } else {
      workStartedAt = null;
      breakStartedAt = Date.now();
      breakWarned = false;
      stopIdleCheck();
      startBreakClock();
    }

    currentSessionType = working ? "work" : "break";
    currentSessionStartedAt = now;

    persistLocalState();
    renderToggleButton();
    scheduleReport();
  }

  function persistLocalState() {
    try {
      chrome.storage.local.set({
        qmEmployeeName: currentEmployeeName,
        qmWorking: working,
        qmBreakStartedAt: breakStartedAt,
        qmWorkStartedAt: workStartedAt,
        qmWarningsToday: warningsToday,
        qmLastShownPopupId: lastShownPopupId,
        qmShiftEnded: shiftEnded,
        qmLastAppliedWarningReset: lastAppliedWarningReset,
      });
    } catch (e) {
      /* ignore */
    }
  }

  // Local state (working/break/warnings/shiftEnded) is saved per-browser,
  // not per-employee. If a different employee logs in on the same
  // computer/browser profile, mutabaaRawName changes but this old state
  // would otherwise be reused and reported under the new name — e.g. an
  // employee inheriting someone else's break warnings from earlier that
  // day. So on every load, compare the currently logged-in name against
  // whichever name the saved state belongs to; if they differ, wipe the
  // state clean before restoring anything.
  function restoreLocalState() {
    return new Promise((resolve) => {
      getEmployeeName().then((name) => {
        currentEmployeeName = name;
        try {
          chrome.storage.local.get(
            ["qmEmployeeName", "qmWorking", "qmBreakStartedAt", "qmWorkStartedAt", "qmWarningsToday", "qmLastShownPopupId", "qmShiftEnded", "qmLastAppliedWarningReset"],
            (data) => {
              const savedForDifferentEmployee =
                name && data && data.qmEmployeeName && data.qmEmployeeName !== name;

              if (savedForDifferentEmployee) {
                console.warn(
                  `[queuemonitor] logged-in employee changed (${data.qmEmployeeName} → ${name}) — resetting local work/break/warning state`
                );
                working = false;
                breakStartedAt = null;
                workStartedAt = null;
                shiftEnded = false;
                warningsToday = { date: todayKey(), count: 0 };
                lastShownPopupId = null;
                lastAppliedWarningReset = 0; // different employee — their own resetWarningsAt history doesn't apply
                persistLocalState(); // overwrite the stale state immediately
                resolve();
                return;
              }

              working = !!(data && data.qmWorking);
              breakStartedAt = (data && data.qmBreakStartedAt) || null;
              shiftEnded = !!(data && data.qmShiftEnded);
              lastAppliedWarningReset = (data && typeof data.qmLastAppliedWarningReset === "number") ? data.qmLastAppliedWarningReset : 0;
              const hadWorkStartedAt = !!(data && data.qmWorkStartedAt);
              workStartedAt = hadWorkStartedAt ? data.qmWorkStartedAt : (working ? Date.now() : null);
              if (working && !hadWorkStartedAt) {
                // first time we've seen this employee working without a saved
                // start time (e.g. was already working before this feature
                // existed) — save it now so the NEXT refresh reads the same
                // value instead of generating a fresh Date.now() every time.
                try {
                  chrome.storage.local.set({ qmWorkStartedAt: workStartedAt });
                } catch (e) { /* ignore */ }
              }
              if (data && data.qmWarningsToday && data.qmWarningsToday.date === todayKey()) {
                warningsToday = data.qmWarningsToday;
              } else {
                warningsToday = { date: todayKey(), count: 0 };
              }
              lastShownPopupId = (data && data.qmLastShownPopupId) || null;
              resolve();
            }
          );
        } catch (e) {
          resolve();
        }
      });
    });
  }

  // ============================================================
  // Admin popup — one-off message pushed from the dashboard, shown
  // immediately (next poll, up to ADMIN_POLL_MS delay) as a modal
  // overlay on top of the page so it can't be missed/scrolled past.
  // ============================================================
  function showAdminPopup(popup) {
    lastShownPopupId = popup.id;
    persistLocalState();

    // Avoid stacking if one is already showing (e.g. rapid re-poll race)
    const existing = document.getElementById("qm-popup-overlay");
    if (existing) existing.remove();

    const overlay = document.createElement("div");
    overlay.id = "qm-popup-overlay";
    overlay.style.cssText = `
      position: fixed; inset: 0; z-index: 2147483647;
      background: rgba(15,23,42,0.55);
      display: flex; align-items: center; justify-content: center;
      font-family: inherit;
    `;

    const box = document.createElement("div");
    box.style.cssText = `
      background: #fff; border-radius: 14px; padding: 24px 26px;
      max-width: 420px; width: 90%; box-shadow: 0 20px 60px rgba(0,0,0,0.35);
      direction: rtl; text-align: right;
    `;
    box.innerHTML = `
      <div style="font-size:15px;font-weight:800;color:#0f172a;margin-bottom:10px;display:flex;align-items:center;gap:8px;">
        <span>📢</span><span>رسالة من الإدارة</span>
      </div>
      <div style="font-size:14px;color:#334155;white-space:pre-wrap;line-height:1.6;margin-bottom:18px;"></div>
      <div style="text-align:left;">
        <button id="qm-popup-ok" type="button" style="
          border:none;border-radius:8px;padding:8px 22px;font-weight:700;font-size:13px;
          cursor:pointer;background:linear-gradient(135deg,#2563eb,#3b82f6);color:#fff;">حسناً</button>
      </div>
    `;
    // set message via textContent to avoid any HTML injection from the admin-entered text
    box.querySelector("div[style*='white-space']").textContent = popup.text || "";

    overlay.appendChild(box);
    document.body.appendChild(overlay);

    const close = () => overlay.remove();
    box.querySelector("#qm-popup-ok").onclick = close;
    overlay.onclick = (e) => { if (e.target === overlay) close(); };
  }

  // ============================================================
  // Break countdown (15:00 then +2:00 grace, then 1 warning)
  // ============================================================
  function startBreakClock() {
    if (shiftEnded) return; // shift-end isn't a real استراحة — no countdown/warning applies
    stopBreakClock();
    breakTickTimer = setInterval(() => {
      if (working || !breakStartedAt) return stopBreakClock();
      const elapsed = Date.now() - breakStartedAt;
      if (!breakWarned && elapsed >= breakLimitMs + BREAK_GRACE_MS) {
        breakWarned = true;
        addWarning();
      }
      renderToggleButton();
    }, TICK_MS);
  }

  function stopBreakClock() {
    if (breakTickTimer) clearInterval(breakTickTimer);
    breakTickTimer = null;
  }

  // ============================================================
  // Idle detection — "بدء العمل" but not actually processing anything
  // ============================================================
  function startIdleCheck() {
    stopIdleCheck();
    idleCheckTimer = setInterval(() => {
      if (!working) return stopIdleCheck();
      const count = getQueueCount();
      if (count <= IDLE_QUEUE_THRESHOLD) {
        console.warn(`[queuemonitor] idle check: queue=${count} <= ${IDLE_QUEUE_THRESHOLD} — auto switching to استراحة`);
        setWorking(false, { fromIdle: true });
      }
    }, IDLE_CHECK_INTERVAL_MS);
  }

  function stopIdleCheck() {
    if (idleCheckTimer) clearInterval(idleCheckTimer);
    idleCheckTimer = null;
  }

  // ============================================================
  // Admin override polling (manager can still force working/break)
  // ============================================================
  async function pollAdminForce() {
    const state = await fetchAdminState();
    if (!state) return;

    // Per-employee break duration, set from the dashboard's queue-monitor tab.
    const nextBreakMs = (typeof state.breakLimitMinutes === "number" && state.breakLimitMinutes > 0)
      ? state.breakLimitMinutes * 60 * 1000
      : DEFAULT_BREAK_LIMIT_MS;
    if (nextBreakMs !== breakLimitMs) {
      breakLimitMs = nextBreakMs;
      renderToggleButton(); // reflect new countdown immediately
    }

    const force = state.adminForce || null;
    if (force !== lastAdminForce) {
      lastAdminForce = force;
      if (force === "working" && !working) setWorking(true, { fromAdmin: true });
      if (force === "break" && working) setWorking(false, { fromAdmin: true });

      if (force === "ended") {
        // admin ended the shift — force off work and block toggling back
        // to عمل until the admin releases them (clears adminForce).
        shiftEnded = true;
        if (working) setWorking(false, { fromAdmin: true });
        stopBreakClock();
        breakStartedAt = null; // not a real استراحة — no countdown/warning applies
        breakWarned = false;
        persistLocalState();
        renderToggleButton();
      } else if (shiftEnded) {
        // admin just released a previously-ended shift — resume as a
        // normal استراحة (employee still needs to press "بدء العمل" themselves).
        shiftEnded = false;
        breakStartedAt = Date.now();
        breakWarned = false;
        currentSessionType = "break";
        currentSessionStartedAt = breakStartedAt;
        startBreakClock();
        persistLocalState();
        renderToggleButton();
      }
    }

    // Instant popup pushed from the admin dashboard for this employee.
    if (state.popup && state.popup.id && state.popup.id !== lastShownPopupId) {
      showAdminPopup(state.popup);
    }

    // Admin pressed "🧹 تصفير التحذيرات" — only act on a *newer* timestamp
    // than the last one we already applied, since resetWarningsAt stays
    // set in Firebase indefinitely (it's not cleared after use). Without
    // this guard every poll after a reset would keep wiping out any new
    // warning that accrues afterward, forever.
    if (typeof state.resetWarningsAt === "number" && state.resetWarningsAt > lastAppliedWarningReset) {
      lastAppliedWarningReset = state.resetWarningsAt;
      warningsToday = { date: todayKey(), count: 0 };
      breakWarned = false;
      persistLocalState();
      renderToggleButton();
      scheduleReport(); // push the cleared count back to the dashboard promptly
    }
  }
  setInterval(pollAdminForce, ADMIN_POLL_MS);

  // ============================================================
  // Mount the panel inline, right next to the header's global search bar
  // (div.search-bar.flex-grow-1), which only exists once in the top
  // document's header — avoids the iframe-duplication issue entirely.
  function findAnchorButtons() {
    const byClass = document.querySelector(".search-bar.flex-grow-1");
    if (byClass) return [byClass];
    return [];
  }

  function buildToggleButton() {
    const btn = document.createElement("button");
    btn.id = "qm-toggle-btn";
    btn.type = "button";
    btn.style.cssText = `
      padding: 4px 14px; border: none; border-radius: 30px;
      font-size: 13px; font-weight: 700; font-family: inherit;
      cursor: pointer; white-space: nowrap;
    `;
    btn.onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (shiftEnded) {
        flashMessage("⏹️ بانتظار المشرف");
        return;
      }
      if (working) {
        const elapsed = Date.now() - (workStartedAt || Date.now());
        if (elapsed < MIN_WORK_BEFORE_BREAK_MS) {
          flashLockedHint(MIN_WORK_BEFORE_BREAK_MS - elapsed);
          return;
        }
      }
      setWorking(!working);
    };
    return btn;
  }

  function buildWarningBadge() {
    const badge = document.createElement("span");
    badge.id = "qm-warning-badge";
    badge.style.cssText = `
      padding: 2px 8px; border-radius: 30px; font-size: 12px; font-weight: 700;
      font-family: inherit; white-space: nowrap; display: inline-block;
      background: #fee2e2; color: #b91c1c;
    `;
    return badge;
  }

  function buildQueueCountBadge() {
    const badge = document.createElement("span");
    badge.id = "qm-queue-badge";
    badge.style.cssText = `
      padding: 2px 8px; border-radius: 30px; font-size: 12px; font-weight: 700;
      font-family: inherit; white-space: nowrap; display: inline-block;
      background: #dbeafe; color: #1d4ed8;
    `;
    return badge;
  }

  function mountToggleButton() {
    if (document.getElementById("qm-panel")) {
      renderToggleButton();
      return;
    }

    const anchorBtn = findAnchorButtons()[0];
    if (!anchorBtn) return;

    const panel = document.createElement("div");
    panel.id = "qm-panel";
    panel.style.cssText = `
      display: inline-flex; align-items: center; gap: 8px;
      padding: 5px 10px; border-radius: 12px; margin-inline-start: 8px;
      background: rgba(15, 23, 42, 0.28);
      vertical-align: middle; direction: rtl;
    `;

    const badge = buildWarningBadge();
    const btn = buildToggleButton();
    const queueBadge = buildQueueCountBadge();
    panel.appendChild(btn);
    panel.appendChild(queueBadge);
    panel.appendChild(badge);

    anchorBtn.insertAdjacentElement("afterend", panel);

    renderToggleButton();
  }

  function flashLockedHint(remainingMs) {
    flashMessage("🔒 ليس الآن");
  }

  function flashMessage(text, durationMs = 1200) {
    const btn = document.getElementById("qm-toggle-btn");
    if (!btn) return;
    const prevText = btn.textContent;
    const prevBg = btn.style.background;
    btn.textContent = text;
    btn.style.background = "linear-gradient(135deg,#64748b,#94a3b8)";
    clearTimeout(btn._lockHintTimer);
    btn._lockHintTimer = setTimeout(() => {
      btn.textContent = prevText;
      btn.style.background = prevBg;
    }, durationMs);
  }

  function formatCountdown(ms) {
    const total = Math.max(0, Math.floor(ms / 1000));
    const m = Math.floor(total / 60);
    const s = total % 60;
    return `${m}:${String(s).padStart(2, "0")}`;
  }

  function renderToggleButton() {
    const btn = document.getElementById("qm-toggle-btn");
    const badge = document.getElementById("qm-warning-badge");
    const queueBadge = document.getElementById("qm-queue-badge");
    if (!btn) return;

    // queue count badge — how many orders (rows in تحت التدقيق) this employee currently has
    if (queueBadge) {
      const n = getQueueCount();
      queueBadge.textContent = `📋 ${n}`;
      queueBadge.title = `عدد الطلبات الحالية: ${n}`;
    }

    // warning badge
    if (badge) {
      if (warningsToday.count > 0) {
        badge.style.display = "inline-block";
        badge.textContent = `⚠️ ${warningsToday.count}`;
        badge.title = warningsToday.count > 3
          ? `${warningsToday.count} تحذيرات اليوم — سيؤثر على التقييم`
          : `${warningsToday.count} تحذير اليوم`;
        badge.style.background = warningsToday.count > 3 ? "#fecaca" : "#fee2e2";
        badge.style.color = warningsToday.count > 3 ? "#7f1d1d" : "#b91c1c";
      } else {
        badge.style.display = "none";
      }
    }

    if (shiftEnded) {
      btn.style.background = "linear-gradient(135deg,#475569,#64748b)";
      btn.style.color = "#fff";
      btn.textContent = `⏹️ انتهى الدوام`;
      btn.title = "انتهى الدوام لهذا اليوم — بانتظار المشرف";
      return;
    }

    if (working) {
      btn.style.background = "linear-gradient(135deg,#dc2626,#ef4444)";
      btn.style.color = "#fff";
      btn.textContent = `🟢 يعمل الآن`;
      btn.title = "اضغط لأخذ استراحة";
      return;
    }

    // on break — show countdown / overtime state
    const elapsed = breakStartedAt ? Date.now() - breakStartedAt : 0;
    if (elapsed < breakLimitMs) {
      const remaining = breakLimitMs - elapsed;
      btn.style.background = "linear-gradient(135deg,#16a34a,#22c55e)";
      btn.style.color = "#fff";
      btn.textContent = `🟡 استراحة — ${formatCountdown(remaining)}`;
      btn.title = "اضغط لبدء العمل";
    } else if (elapsed < breakLimitMs + BREAK_GRACE_MS) {
      const remaining = breakLimitMs + BREAK_GRACE_MS - elapsed;
      btn.style.background = "linear-gradient(135deg,#f59e0b,#fbbf24)";
      btn.style.color = "#7c2d12";
      btn.textContent = `⏰ سماحية — ${formatCountdown(remaining)}`;
      btn.title = "انتهى وقت الاستراحة، سماحية دقيقتين قبل التحذير";
    } else {
      btn.style.background = "linear-gradient(135deg,#b91c1c,#dc2626)";
      btn.style.color = "#fff";
      btn.textContent = `🔴 تجاوز الوقت — بدء العمل`;
      btn.title = "تم تسجيل تحذير — اضغط لبدء العمل";
    }
  }

  // ============================================================
  // Init
  // ============================================================
  function init() {
    restoreLocalState().then(() => {
      mountToggleButton();
      const mountObserver = new MutationObserver(() => {
        mountToggleButton();
        if (document.getElementById("qm-toggle-btn")) mountObserver.disconnect();
      });
      mountObserver.observe(document.documentElement, {
        childList: true,
        subtree: true,
      });
      if (working) startIdleCheck();
      else if (breakStartedAt) startBreakClock();

      // open the initial session record for this page load, picking up
      // whichever state was restored from local storage
      currentSessionType = working ? "work" : "break";
      currentSessionStartedAt = working ? Date.now() : (breakStartedAt || Date.now());

      scheduleReport();
      pollAdminForce();
      // keep the order-count badge live as رows are claimed/finished
      setInterval(renderToggleButton, 10000);
      // and push that same live count to the admin dashboard periodically —
      // reportState() otherwise only fires on toggle/warning, so without this
      // the dashboard's count freezes at whatever it was when work started
      // even though the employee's own page count keeps changing.
      setInterval(reportState, LIVE_REPORT_MS);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();

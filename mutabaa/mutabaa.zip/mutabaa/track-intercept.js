// track-intercept.js
// Runs in every frame of the tickets pages AND inside the تتبع page itself.
// Catches clicks on popitup(...) buttons (تتبع / تتبع الاشعارات / التفاصيل /
// عرض صور الشحنة) and asks the TOP window (track-modal-top.js) to show them in
// floating boxes. Falls back to the normal popup if the top window doesn't answer.
// Must be listed BEFORE process-content.js in the manifest.
(function () {
  "use strict";
  if (window.__mutabaaTrackIntercept) return;
  window.__mutabaaTrackIntercept = true;

  const MSG_OPEN = "mutabaa-track-open";
  const MSG_ACK = "mutabaa-track-ack";
  const PARTS = ["displaySingleCaseInfo", "CaseNotificationsTrackingPopUp", "itemDetails", "CaseMediaPopUp", "chatbox"];

  function openInTop(url) {
    let acked = false;
    const onAck = (ev) => {
      if (ev.data && ev.data.type === MSG_ACK && ev.data.url === url) acked = true;
    };
    window.addEventListener("message", onAck);
    try { window.top.postMessage({ type: MSG_OPEN, url }, "*"); } catch (e) {}
    setTimeout(() => {
      window.removeEventListener("message", onAck);
      if (!acked) window.open(url, "", "width=1100,height=650,resizable=yes,scrollbars=yes");
    }, 400);
  }

  document.addEventListener("click", (e) => {
    const el = e.target instanceof Element ? e.target.closest("[onclick]") : null;
    if (!el) return;
    const oc = el.getAttribute("onclick") || "";
    if (!PARTS.some((p) => oc.includes(p))) return;
    const m = oc.match(/popitup\s*\(\s*['"]([^'"]+)['"]/);
    if (!m) return;
    let url;
    try { url = new URL(m[1], location.href).href; } catch (err) { return; }
    e.preventDefault();
    e.stopImmediatePropagation();
    openInTop(url);
  }, true);

  // --- Re-open ticket: reload ONLY this frame (not the whole page) ---------
  // After pressing «اعادة فتح التذكرة» the ticket page has to be reloaded before
  // the employee can type. Inside the floating box a normal reload (F5) would
  // reload the whole main page, so we reload just this frame ourselves.
  const REOPEN_TEXT = "اعادة فتح التذكرة";
  const REOPEN_RELOAD_DELAY_MS = 1500; // time for the site's own request to finish
  const norm = (t) => String(t || "").replace(/[أإآ]/g, "ا").replace(/\s+/g, " ").trim();
  document.addEventListener("click", (e) => {
    const el = e.target instanceof Element ? e.target.closest("button, a, input, [onclick]") : null;
    if (!el) return;
    if (!norm(el.textContent || el.value).includes(REOPEN_TEXT)) return;
    setTimeout(() => { try { location.reload(); } catch (err) {} }, REOPEN_RELOAD_DELAY_MS);
  }, true);
})();

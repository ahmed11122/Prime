// track-modal-top.js — runs ONLY in the top window (all_frames:false).
// Shows order pages (تتبع, تتبع الاشعارات, التفاصيل, صور الشحنة) as draggable,
// resizable floating boxes above the whole page. Several can be open at once.
(function () {
  "use strict";
  if (window.top !== window) return;
  if (window.__mutabaaTrackHost) return;
  window.__mutabaaTrackHost = true;

  const MSG_OPEN = "mutabaa-track-open";
  const MSG_ACK = "mutabaa-track-ack";
  const TITLES = {
    displaySingleCaseInfo: "تتبع الطلب",
    CaseNotificationsTrackingPopUp: "تتبع الاشعارات",
    itemDetails: "التفاصيل",
    CaseMediaPopUp: "صور الشحنة",
    chatbox: "عرض التذكرة",
  };
  const GEOM_KEY = "mutabaa_track_geom";
  const MIN_W = 420, MIN_H = 300;

  const mk = (tag, css, text) => {
    const el = document.createElement(tag);
    if (css) el.style.cssText = css;
    if (text != null) el.textContent = text;
    return el;
  };
  const btnCss = (bg) =>
    "border:0;border-radius:6px;padding:4px 10px;font-size:12px;cursor:pointer;color:#fff;background:" + bg + ";";

  function safeStorage(fn) {
    try { if (chrome?.runtime?.id) fn(chrome.storage.local); } catch (e) {}
  }

  let overlay = null;
  let zCounter = 1;
  let mainGeom = null; // saved geometry of the main تتبع box
  const wins = []; // open windows, each {url, box, z, close}

  function ensureOverlay() {
    if (overlay) return;
    overlay = mk("div", "display:none;position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.45);");
    overlay.className = "mutabaa-track-modal";
    document.documentElement.appendChild(overlay);
    overlay.addEventListener("mousedown", (e) => { if (e.target === overlay) closeTop(); });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && wins.length) closeTop();
    }, true);
    safeStorage((s) => s.get([GEOM_KEY], (res) => {
      const g = res && res[GEOM_KEY];
      if (g && [g.left, g.top, g.width, g.height].every(Number.isFinite)) mainGeom = g;
    }));
  }

  function closeTop() {
    if (!wins.length) return;
    wins.reduce((a, b) => (b.z > a.z ? b : a)).close();
  }

  function kindOf(url) {
    const path = new URL(url).pathname;
    return Object.keys(TITLES).find((k) => path.includes(k)) || null;
  }

  function createWindow(url, kind) {
    ensureOverlay();
    const isMain = kind === "displaySingleCaseInfo";
    const idx = wins.length;
    let geom = null;

    function defaultGeom() {
      const width = Math.min(isMain ? 1350 : 1000, Math.round(window.innerWidth * 0.95));
      const height = Math.round(window.innerHeight * (isMain ? 0.9 : 0.8));
      return {
        left: Math.round((window.innerWidth - width) / 2) - idx * 30,
        top: Math.max(0, Math.round((window.innerHeight - height) / 2) + idx * 30),
        width, height,
      };
    }
    const clampGeom = (g) => {
      const width = Math.min(Math.max(MIN_W, g.width), window.innerWidth);
      const height = Math.min(Math.max(MIN_H, g.height), window.innerHeight);
      return {
        left: Math.min(Math.max(-width + 120, g.left), window.innerWidth - 120),
        top: Math.min(Math.max(0, g.top), window.innerHeight - 40),
        width, height,
      };
    };

    const box = mk("div",
      "position:fixed;background:#111827;border:1px solid #4b5563;border-radius:10px;" +
      "box-shadow:0 10px 40px rgba(0,0,0,.6);display:flex;flex-direction:column;overflow:hidden;direction:rtl;");
    const head = mk("div",
      "display:flex;align-items:center;justify-content:space-between;gap:8px;padding:6px 10px;" +
      "background:#1f2937;color:#f3f4f6;font-size:14px;cursor:move;user-select:none;touch-action:none;");
    // direction:rtl -> first child sits on the RIGHT: buttons first, title after.
    const btns = mk("span", "display:flex;gap:6px;");
    const closeBtn = mk("button", btnCss("#dc2626"), "إغلاق ✕");
    const popBtn = mk("button", btnCss("#374151"), "فتح في نافذة");
    const reloadBtn = mk("button", btnCss("#2563eb"), "تحديث ⟳");
    closeBtn.type = popBtn.type = reloadBtn.type = "button";
    btns.append(closeBtn, popBtn, reloadBtn);
    const title = mk("span", "font-weight:bold;", (TITLES[kind] || "عرض") + "  (اسحب من هنا للتحريك)");
    head.append(btns, title);

    const body = mk("div", "position:relative;flex:1;min-height:0;");
    const msg = mk("div",
      "position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#9ca3af;font-size:14px;",
      "جاري التحميل...");
    const shield = mk("div", "display:none;position:absolute;inset:0;z-index:5;");
    body.append(msg, shield);
    box.append(head, body);

    const gripCss = (side) =>
      "position:absolute;bottom:0;" + side + ":0;width:18px;height:18px;z-index:6;touch-action:none;" +
      "cursor:" + (side === "right" ? "nwse-resize" : "nesw-resize") + ";" +
      "background:linear-gradient(" + (side === "right" ? "135deg" : "225deg") +
      ",transparent 50%,#9ca3af 50%,#9ca3af 60%,transparent 60%,transparent 72%,#9ca3af 72%,#9ca3af 82%,transparent 82%);";
    const gripR = mk("div", gripCss("right"));
    const gripL = mk("div", gripCss("left"));
    box.append(gripR, gripL);

    const w = { url, box, z: 0, close: null };
    const bringToFront = () => { w.z = ++zCounter; box.style.zIndex = String(w.z); };

    function applyGeom() {
      geom = clampGeom(geom);
      box.style.left = geom.left + "px";
      box.style.top = geom.top + "px";
      box.style.width = geom.width + "px";
      box.style.height = geom.height + "px";
    }
    const persist = () => {
      if (isMain) { mainGeom = geom; safeStorage((s) => s.set({ [GEOM_KEY]: geom })); }
    };

    function startInteraction(e, mode) {
      if (e.button !== undefined && e.button !== 0) return;
      if (e.target instanceof Element && e.target.closest("button")) return;
      e.preventDefault();
      const el = e.currentTarget;
      el.setPointerCapture(e.pointerId);
      shield.style.display = "block";
      const start = { x: e.clientX, y: e.clientY, g: { ...geom } };
      const onMove = (ev) => {
        const dx = ev.clientX - start.x, dy = ev.clientY - start.y;
        if (mode === "move") geom = { ...start.g, left: start.g.left + dx, top: start.g.top + dy };
        else if (mode === "resize-right") geom = { ...start.g, width: start.g.width + dx, height: start.g.height + dy };
        else {
          const width = Math.max(MIN_W, start.g.width - dx);
          geom = { ...start.g, width, left: start.g.left + (start.g.width - width), height: start.g.height + dy };
        }
        applyGeom();
      };
      const onUp = () => {
        el.removeEventListener("pointermove", onMove);
        el.removeEventListener("pointerup", onUp);
        el.removeEventListener("pointercancel", onUp);
        shield.style.display = "none";
        persist();
      };
      el.addEventListener("pointermove", onMove);
      el.addEventListener("pointerup", onUp);
      el.addEventListener("pointercancel", onUp);
    }
    head.addEventListener("pointerdown", (e) => startInteraction(e, "move"));
    gripR.addEventListener("pointerdown", (e) => startInteraction(e, "resize-right"));
    gripL.addEventListener("pointerdown", (e) => startInteraction(e, "resize-left"));
    head.addEventListener("dblclick", () => { geom = defaultGeom(); applyGeom(); persist(); });
    box.addEventListener("pointerdown", bringToFront, true);
    const onResize = () => applyGeom();
    window.addEventListener("resize", onResize);

    let frame = document.createElement("iframe");
    frame.style.cssText = "position:absolute;inset:0;width:100%;height:100%;border:0;background:#fff;";
    frame.addEventListener("load", () => {
      let blocked = false;
      try {
        const href = frame.contentWindow.location.href;
        if (!href || href.startsWith("chrome-error:")) blocked = true;
        else if (href === "about:blank") return;
      } catch (e) { blocked = true; }
      if (blocked) {
        msg.textContent = "تعذر عرض الصفحة هنا. اضغط «فتح في نافذة».";
        msg.style.display = "flex";
      } else msg.style.display = "none";
    });
    body.appendChild(frame);

    w.close = () => {
      window.removeEventListener("resize", onResize);
      frame.src = "about:blank";
      frame.remove();
      box.remove();
      const i = wins.indexOf(w);
      if (i !== -1) wins.splice(i, 1);
      if (!wins.length) overlay.style.display = "none";
    };
    closeBtn.addEventListener("click", w.close);
    // Reload only this box's page (never the main window).
    reloadBtn.addEventListener("click", () => {
      msg.textContent = "جاري التحميل...";
      msg.style.display = "flex";
      try { frame.contentWindow.location.reload(); } catch (e) { frame.src = frame.src; }
    });
    popBtn.addEventListener("click", () => {
      w.close();
      window.open(url, "", "width=1100,height=650,resizable=yes,scrollbars=yes");
    });

    geom = isMain && mainGeom ? { ...mainGeom } : defaultGeom();
    overlay.appendChild(box);
    overlay.style.display = "block";
    applyGeom();
    bringToFront();
    wins.push(w);
    frame.src = url;
    return w;
  }

  window.addEventListener("message", (ev) => {
    const d = ev.data;
    if (!d || d.type !== MSG_OPEN || typeof d.url !== "string") return;
    let u;
    try { u = new URL(d.url, location.href); } catch (e) { return; }
    if (!/(^|\.)prime-iq\.com$/.test(u.hostname)) return;
    const kind = kindOf(u.href);
    if (!kind) return;
    try { ev.source && ev.source.postMessage({ type: MSG_ACK, url: d.url }, "*"); } catch (e) {}
    ensureOverlay();
    const existing = wins.find((x) => x.url === u.href);
    if (existing) { existing.z = ++zCounter; existing.box.style.zIndex = String(existing.z); return; }
    createWindow(u.href, kind);
  });
})();

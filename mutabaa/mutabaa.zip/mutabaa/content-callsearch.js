// ══════════════════════════════════════════════════════════════════
// متابعة — content-callsearch.js
// Runs on the company site. Adds a button that opens a small panel:
// type a phone number, get back EVERY matching call recording from
// the PBX (via the relay), not just the most recent one, with
// play/download per row.
//
// Talks to the relay (relay.js) over the internet tunnel, NOT
// directly to the PBX — the browser on the company site can't reach
// 192.168.9.30 anyway, that's the whole reason the relay + tunnel
// exists.
// ══════════════════════════════════════════════════════════════════

// TODO: swap this for wherever the localtunnel/relay ends up living
// long-term (it can change if the tunnel URL changes).
const CALLSEARCH_RELAY_BASE = "https://pbx.mutabaa.online";

// ── Button placement ────────────────────────────────────────────
// Goes right next to the page's "عرض الشحنات الخاصة بالموظفين" button.
// Unlike the per-row "حفظ" buttons (which are dynamic, sometimes
// live inside an iframe, and vary in markup between page templates),
// this button is a single, always-present toolbar button near the
// top of every ticket/case page — a much more reliable anchor.
function findSaveButtons() {
  return Array.from(document.querySelectorAll("button")).filter((btn) => {
    const text = (btn.textContent || "").replace(/\s+/g, " ").trim();
    return text.includes("عرض الشحنات الخاصة بالموظفين");
  });
}

function makeCallSearchButton() {
  const btn = document.createElement("button");
  btn.className = "mutabaaCallSearchBtn";
  btn.type = "button"; // never submit the حفظ button's surrounding <form>
  btn.textContent = "📞 اتصالات";
  btn.style.cssText = `
    margin-right: 6px;
    margin-top: 5px;
    padding: 4px 14px;
    background: linear-gradient(135deg,#1d4ed8,#2563eb);
    color: #fff;
    border: none;
    border-radius: 30px;
    font-size: 13px;
    font-weight: 600;
    font-family: inherit;
    cursor: pointer;
    box-shadow: 0 2px 6px rgba(37,99,235,0.35);
  `;
  btn.onclick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    togglePanel(btn);
  };
  return btn;
}

function mountCallSearchButtons() {
  findSaveButtons().forEach((saveBtn) => {
    const next = saveBtn.nextElementSibling;
    if (next && next.classList && next.classList.contains("mutabaaCallSearchBtn")) return;
    saveBtn.insertAdjacentElement("afterend", makeCallSearchButton());
  });
}

// ── Panel ────────────────────────────────────────────────────────
let panelEl = null;

function togglePanel(anchorBtn) {
  if (panelEl) {
    panelEl.remove();
    panelEl = null;
    return;
  }
  panelEl = buildPanel(anchorBtn);
  document.body.appendChild(panelEl);
  panelEl.querySelector("input").focus();
}

function buildPanel(anchorBtn) {
  const panel = document.createElement("div");
  panel.id = "mutabaaCallSearchPanel";

  let posCss = "position: fixed; bottom: 16px; left: 16px;";
  if (anchorBtn) {
    const rect = anchorBtn.getBoundingClientRect();
    const width = 380;
    let left = rect.left;
    if (left + width > window.innerWidth - 8) left = window.innerWidth - width - 8;
    if (left < 8) left = 8;
    posCss = "position: fixed; top: " + (rect.bottom + 6) + "px; left: " + left + "px;";
  }

  panel.style.cssText = `
    ${posCss}
    z-index: 999999;
    width: 380px;
    height: auto;
    max-height: 75vh;
    min-width: 300px;
    min-height: 0;
    display: flex;
    flex-direction: column;
    background: #fff;
    color: #1f2430;
    border-radius: 14px;
    box-shadow: 0 12px 32px rgba(15,23,42,0.22), 0 2px 8px rgba(15,23,42,0.12);
    font-family: "Segoe UI", "Cairo", system-ui, sans-serif;
    font-size: 13px;
    direction: rtl;
    overflow: hidden;
    border: 1px solid #e7e9ee;
  `;

  const todayStr = new Date().toISOString().slice(0, 10);

  panel.innerHTML = `
    <div data-role="dragHandle" style="padding:14px 16px 12px; background:linear-gradient(135deg,#1d4ed8,#2563eb); color:#fff; cursor:move; user-select:none; touch-action:none; flex-shrink:0;">
      <div style="display:flex; align-items:center; gap:8px; margin-bottom:10px;">
        <span style="font-size:16px;">📞</span>
        <span style="font-weight:600; font-size:14px; flex:1;">بحث سجل المكالمات</span>
        <button data-role="close" type="button" title="إغلاق"
          style="background:rgba(255,255,255,0.18); border:none; color:#fff; width:24px; height:24px; border-radius:50%; font-size:14px; line-height:1; cursor:pointer; flex-shrink:0; display:flex; align-items:center; justify-content:center;">✕</button>
      </div>
      <div style="display:flex; gap:6px;">
        <input type="text" data-role="number" placeholder="رقم الهاتف" inputmode="tel"
          style="flex:1; padding:8px 10px; border:none; border-radius:8px; font-size:13px; outline:none;" />
        <button data-role="go" style="padding:8px 16px; border:none; border-radius:8px; background:#fff; color:#1d4ed8; font-weight:600; cursor:pointer; transition:opacity .15s;">بحث</button>
      </div>
      <div style="display:flex; gap:8px; align-items:center; margin-top:8px;">
        <label style="color:rgba(255,255,255,0.85); white-space:nowrap; font-size:11px;">من</label>
        <input type="date" data-role="from" value="${todayStr}"
          style="flex:1; padding:5px 6px; border:none; border-radius:6px; font-size:11px; outline:none;" />
        <label style="color:rgba(255,255,255,0.85); white-space:nowrap; font-size:11px;">إلى</label>
        <input type="date" data-role="to" value="${todayStr}"
          style="flex:1; padding:5px 6px; border:none; border-radius:6px; font-size:11px; outline:none;" />
      </div>
    </div>
    <div data-role="status" style="padding:8px 16px; color:#6b7280; font-size:12px; border-bottom:1px solid #f0f1f4; flex-shrink:0;"></div>
    <div data-role="results" style="overflow-y:auto; flex:1; min-height:32px;"></div>
    <div data-role="resizeHandle" title="تكبير/تصغير"
      style="position:absolute; left:0; bottom:0; width:26px; height:26px; cursor:nesw-resize; touch-action:none; display:flex; align-items:flex-end; justify-content:flex-start; padding:5px; pointer-events:none;">
      <svg viewBox="0 0 16 16" width="16" height="16" style="pointer-events:auto;"><path d="M14 2L2 14M14 8L8 14" stroke="#9ca3af" stroke-width="2" fill="none"/></svg>
    </div>
  `;

  const input = panel.querySelector('[data-role="number"]');
  const fromInput = panel.querySelector('[data-role="from"]');
  const toInput = panel.querySelector('[data-role="to"]');
  const goBtn = panel.querySelector('[data-role="go"]');
  const statusEl = panel.querySelector('[data-role="status"]');
  const resultsEl = panel.querySelector('[data-role="results"]');
  const closeBtn = panel.querySelector('[data-role="close"]');
  const dragHandle = panel.querySelector('[data-role="dragHandle"]');
  const resizeHandle = panel.querySelector('[data-role="resizeHandle"]');
  const resizeGrip = resizeHandle.querySelector("svg");

  closeBtn.onclick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    panel.remove();
    panelEl = null;
  };

  // Both drag and resize use Pointer Events + setPointerCapture instead
  // of plain mouse events. Without capture, a fast mouse movement can
  // slip past the small handle in a single frame — the browser then
  // has no element to keep sending "mousemove" to (or it starts
  // selecting page text instead), so tracking stalls until you creep
  // the mouse back over the handle. Pointer capture locks all pointer
  // events to the handle itself, from mousedown to mouseup, regardless
  // of how fast the cursor moves or what it passes over.

  // ── Dragging ─────────────────────────────────────────────────────
  // Once the user drags, the panel switches from "anchored under the
  // button" to fixed top/left coordinates, and stays put even while
  // they scroll the page (position: fixed).
  (function enableDrag() {
    let startX = 0, startY = 0, startLeft = 0, startTop = 0;

    dragHandle.addEventListener("pointerdown", (e) => {
      if (e.target.closest("input, select, textarea, button")) return;
      dragHandle.setPointerCapture(e.pointerId);
      const rect = panel.getBoundingClientRect();
      startX = e.clientX;
      startY = e.clientY;
      startLeft = rect.left;
      startTop = rect.top;
      panel.style.left = startLeft + "px";
      panel.style.top = startTop + "px";
      panel.style.bottom = "auto";
      panel.style.right = "auto";
      document.body.style.userSelect = "none";
      e.preventDefault();
    });

    dragHandle.addEventListener("pointermove", (e) => {
      if (!dragHandle.hasPointerCapture(e.pointerId)) return;
      let newLeft = startLeft + (e.clientX - startX);
      let newTop = startTop + (e.clientY - startY);
      const maxLeft = window.innerWidth - 40;
      const maxTop = window.innerHeight - 40;
      newLeft = Math.max(-panel.offsetWidth + 60, Math.min(newLeft, maxLeft));
      newTop = Math.max(0, Math.min(newTop, maxTop));
      panel.style.left = newLeft + "px";
      panel.style.top = newTop + "px";
    });

    function endDrag(e) {
      if (dragHandle.hasPointerCapture(e.pointerId)) {
        dragHandle.releasePointerCapture(e.pointerId);
      }
      document.body.style.userSelect = "";
    }
    dragHandle.addEventListener("pointerup", endDrag);
    dragHandle.addEventListener("pointercancel", endDrag);
  })();

  // ── Resizing ─────────────────────────────────────────────────────
  (function enableResize() {
    let startX = 0, startY = 0, startWidth = 0, startHeight = 0, startLeft = 0;

    resizeGrip.addEventListener("pointerdown", (e) => {
      resizeGrip.setPointerCapture(e.pointerId);
      const rect = panel.getBoundingClientRect();
      startX = e.clientX;
      startY = e.clientY;
      startWidth = rect.width;
      startHeight = rect.height;
      startLeft = rect.left;
      panel.style.left = startLeft + "px";
      panel.style.top = rect.top + "px";
      panel.style.bottom = "auto";
      panel.style.right = "auto";
      document.body.style.userSelect = "none";
      e.preventDefault();
      e.stopPropagation();
    });

    resizeGrip.addEventListener("pointermove", (e) => {
      if (!resizeGrip.hasPointerCapture(e.pointerId)) return;
      // Handle sits bottom-left: dragging left/down grows the panel,
      // so the left edge has to move with it to keep the right edge fixed.
      const deltaX = e.clientX - startX;
      const newWidth = Math.max(300, Math.min(startWidth - deltaX, window.innerWidth - 16));
      const newHeight = Math.max(220, Math.min(startHeight + (e.clientY - startY), window.innerHeight - 16));
      panel.style.width = newWidth + "px";
      panel.style.height = newHeight + "px";
      panel.style.maxHeight = "none";
      panel.style.left = (startLeft + (startWidth - newWidth)) + "px";
    });

    function endResize(e) {
      if (resizeGrip.hasPointerCapture(e.pointerId)) {
        resizeGrip.releasePointerCapture(e.pointerId);
      }
      document.body.style.userSelect = "";
    }
    resizeGrip.addEventListener("pointerup", endResize);
    resizeGrip.addEventListener("pointercancel", endResize);
  })();

  panel.style.position = "fixed";

  async function runSearch() {
    const number = input.value.trim();
    if (!number) return;
    const startDate = fromInput.value || todayStr;
    const endDate = toInput.value || startDate;
    resultsEl.innerHTML = "";
    statusEl.textContent = "...جارِ البحث";
    goBtn.disabled = true;

    try {
      const res = await fetch(
        `${CALLSEARCH_RELAY_BASE}/cdr/search?number=${encodeURIComponent(number)}` +
          `&start_date=${encodeURIComponent(startDate)}&end_date=${encodeURIComponent(endDate)}`
      );
      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        statusEl.textContent = "خطأ: " + (errJson.error || res.status);
        return;
      }
      const data = await res.json();
      const rowEntries = renderResults(data.records || [], resultsEl);
      statusEl.textContent = data.count
        ? `${data.count} نتيجة`
        : "لا توجد نتائج لهذا الرقم في هذه الفترة";
      // Fire-and-forget: recordings attach themselves to rows above
      // whenever /search/list comes back, however long that takes.
      fetchAndAttachRecordings(number, rowEntries, startDate, endDate);
    } catch (e) {
      console.error("[متابعة] call search error:", e);
      statusEl.textContent = "تعذر الاتصال بالخادم";
    } finally {
      goBtn.disabled = false;
    }
  }

  goBtn.onclick = runSearch;
  [input, fromInput, toInput].forEach((el) => {
    el.addEventListener("keydown", (e) => {
      if (e.key === "Enter") runSearch();
    });
  });

  return panel;
}

// Arabic labels + a rough color per PBX disposition, so a glance at
// the list tells you what happened without reading English.
const STATUS_MAP = {
  ANSWERED: { label: "تم الرد", color: "#16a34a" },
  "NO ANSWER": { label: "لا يوجد رد", color: "#d97706" },
  BUSY: { label: "مشغول", color: "#d97706" },
  ABANDONED: { label: "تم الإنهاء", color: "#6b7280" },
  FAILED: { label: "فشلت", color: "#dc2626" },
  VOICEMAIL: { label: "بريد صوتي", color: "#2563eb" },
};

// Builds a filename like 202609132210-357-07815777137.wav instead of
// a meaningless numeric recording id — call time (YYYYMMDDHHmm),
// caller's extension (pulled out of "الاسم<357>" if present, else the
// raw caller string), and the callee number.
function buildRecordingFilename(rec) {
  let stamp = "call";
  const m = String(rec.time || "").match(
    /^(\d{1,2})\/(\d{1,2})\/(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})$/
  );
  if (m) {
    const [, d, mo, y, hh, mm] = m;
    stamp = `${y}${mo.padStart(2, "0")}${d.padStart(2, "0")}${hh.padStart(2, "0")}${mm}`;
  }

  function shortNumber(raw) {
    if (!raw) return "unknown";
    const bracketed = String(raw).match(/<(\d+)>/);
    if (bracketed) return bracketed[1];
    const digits = String(raw).replace(/[^\d]/g, "");
    return digits || String(raw).replace(/[^\w]/g, "");
  }

  return `${stamp}-${shortNumber(rec.caller)}-${shortNumber(rec.callee)}.wav`;
}

// ── Client-side recording matching ──────────────────────────────────
// /cdr/search no longer waits on the PBX's /recording/search (it can
// take ~11s and a fixed server-side timeout just meant matches were
// randomly missing). Instead: render the CDR rows immediately, then
// separately call /search/list (existing endpoint) in the background
// and match its results to already-rendered rows by call time once
// it comes back — mirrors relay.js's matchRecordingsToCdr/
// parsePbxTimeFlexible so the tolerance/format handling stays in sync.
const RECORDING_MATCH_TOLERANCE_MS = 15 * 1000;

function parsePbxTimeFlexible(str) {
  if (!str) return null;
  let m = str.match(/^(\d{1,2}):(\d{2}):(\d{2})\s+(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) {
    const [, hh, mm, ss, d, mo, y] = m;
    return new Date(+y, +mo - 1, +d, +hh, +mm, +ss).getTime();
  }
  m = str.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})$/);
  if (m) {
    const [, d, mo, y, hh, mm, ss] = m;
    return new Date(+y, +mo - 1, +d, +hh, +mm, +ss).getTime();
  }
  return null;
}

// rowEntries: [{ rec, row }] in the order rendered. Mutates nothing;
// returns a Map from rec (object identity) -> matched recording id.
function matchRecordingsToRows(rowEntries, recordingList) {
  const recordingsWithTs = recordingList
    .map((r) => ({ r, ts: parsePbxTimeFlexible(r.time) }))
    .filter((x) => x.ts !== null);

  const matches = new Map();
  for (const entry of rowEntries) {
    const cdrTs = parsePbxTimeFlexible(entry.rec.time);
    if (cdrTs === null) continue;
    let best = null;
    let bestDiff = Infinity;
    for (const { r, ts } of recordingsWithTs) {
      const diff = Math.abs(ts - cdrTs);
      if (diff < bestDiff) {
        bestDiff = diff;
        best = r;
      }
    }
    if (best && bestDiff <= RECORDING_MATCH_TOLERANCE_MS) {
      matches.set(entry.rec, best.id);
    }
  }
  return matches;
}

// Builds and attaches the audio player + download link to a row's
// footer, once we know its recordingId — same markup as the inline
// version in renderResults, factored out so it can run later too.
function attachPlayer(footer, rec, recordingId) {
  const audio = document.createElement("audio");
  audio.controls = true;
  audio.preload = "none";
  audio.style.cssText = "height:30px; flex:1; border-radius:6px;";
  audio.src = `${CALLSEARCH_RELAY_BASE}/play?id=${encodeURIComponent(recordingId)}`;
  audio.onerror = () => audio.remove();

  const downloadLink = document.createElement("a");
  downloadLink.textContent = "⬇ تحميل";
  const niceName = buildRecordingFilename(rec);
  downloadLink.href = `${CALLSEARCH_RELAY_BASE}/play?id=${encodeURIComponent(recordingId)}&download=1&filename=${encodeURIComponent(niceName)}`;
  downloadLink.style.cssText = "color:#2563eb; white-space:nowrap; text-decoration:none; font-size:11px; font-weight:600;";

  footer.prepend(downloadLink);
  footer.prepend(audio);
}

// Fires after rows are already on screen. Fetches /search/list
// (can take a while) and injects players into rows as matches land —
// never blocks the initial render.
async function fetchAndAttachRecordings(number, rowEntries, startDate, endDate) {
  if (!rowEntries.length) return;
  try {
    let url = `${CALLSEARCH_RELAY_BASE}/search/list?number=${encodeURIComponent(number)}`;
    if (startDate) {
      url += `&start_date=${encodeURIComponent(startDate)}&end_date=${encodeURIComponent(endDate || startDate)}`;
    }
    const res = await fetch(url);
    if (!res.ok) return;
    const data = await res.json();
    const matches = matchRecordingsToRows(rowEntries, data.records || []);
    matches.forEach((recordingId, rec) => {
      const entry = rowEntries.find((e) => e.rec === rec);
      if (entry && !entry.rec.recordingId) {
        entry.rec.recordingId = recordingId;
        attachPlayer(entry.footer, entry.rec, recordingId);
      }
    });
  } catch (e) {
    console.warn("[متابعة] recording match fetch failed:", e);
  }
}

function statusBadge(status) {
  const info = STATUS_MAP[status] || { label: status || "—", color: "#6b7280" };
  return `<span style="color:#fff; background:${info.color}; padding:2px 10px; border-radius:20px; font-size:11px; font-weight:600; white-space:nowrap;">${info.label}</span>`;
}

function formatDuration(seconds) {
  const n = Number(seconds);
  if (!Number.isFinite(n)) return seconds || "—";
  const m = Math.floor(n / 60);
  const s = Math.floor(n % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}

// ── "تنبيه" button — lets the employee flag a specific call for the
// admin's attention (e.g. "this one needs a callback" / "check this
// call"). Posts the call's details to the relay, which forwards it
// as a Telegram message. See relay.js's /cdr/alert handler for the
// bot token / chat id setup.
function makeAlertButton(rec) {
  const btn = document.createElement("button");
  btn.type = "button";
  btn.textContent = "🔔 تنبيه";
  btn.style.cssText = `
    padding: 4px 10px;
    border: 1px solid #f59e0b;
    border-radius: 20px;
    background: #fffbeb;
    color: #b45309;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    white-space: nowrap;
    transition: background .15s;
  `;

  btn.onclick = async () => {
    btn.disabled = true;
    btn.textContent = "...جارِ الإرسال";
    try {
      const res = await fetch(`${CALLSEARCH_RELAY_BASE}/cdr/alert`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          time: rec.time,
          caller: rec.caller,
          callee: rec.callee,
          status: rec.status,
          duration: rec.duration,
          routingDuration: rec.routingDuration,
          pageUrl: location.href,
        }),
      });
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || res.status);
      btn.textContent = "✅ تم الإرسال";
      btn.style.background = "#f0fdf4";
      btn.style.borderColor = "#16a34a";
      btn.style.color = "#15803d";
    } catch (e) {
      console.error("[متابعة] alert send failed:", e);
      btn.textContent = "⚠️ فشل الإرسال";
      btn.disabled = false;
    }
  };

  return btn;
}

function renderResults(records, container) {
  container.innerHTML = "";
  if (!records.length) return [];

  const rowEntries = [];
  records.forEach((rec) => {
    const row = document.createElement("div");
    row.style.cssText = `
      padding: 12px 16px;
      border-bottom: 1px solid #f0f1f4;
      display: flex;
      flex-direction: column;
      gap: 6px;
      transition: background .15s;
    `;
    row.onmouseenter = () => (row.style.background = "#fafbfc");
    row.onmouseleave = () => (row.style.background = "transparent");

    const line1 = document.createElement("div");
    line1.style.cssText = "display:flex; justify-content:space-between; align-items:center;";
    line1.innerHTML = `
      <span style="color:#111827; font-weight:600; font-size:12.5px;">${rec.time || "—"}</span>
      ${statusBadge(rec.status)}
    `;

    const line2 = document.createElement("div");
    line2.style.cssText = "color:#4b5563; font-size:12px; display:flex; gap:6px; align-items:center;";
    line2.innerHTML = `<span style="color:#9ca3af;">من</span> <span style="font-weight:500;">${rec.caller || "—"}</span> <span style="color:#9ca3af;">←</span> <span style="color:#9ca3af;">إلى</span> <span style="font-weight:500;">${rec.callee || "—"}</span>`;

    // Every call gets total + routing duration now, not just answered
    // ones — routing duration is the time until it was picked up (or
    // gave up ringing), total duration is the whole call.
    const line3 = document.createElement("div");
    line3.style.cssText = "color:#9ca3af; font-size:11px; display:flex; gap:14px;";
    line3.innerHTML = `
      <span>⏱ المدة الكلية: <strong style="color:#6b7280;">${formatDuration(rec.duration)}</strong></span>
      <span>📶 مدة التوجيه: <strong style="color:#6b7280;">${formatDuration(rec.routingDuration)}</strong></span>
    `;

    const footer = document.createElement("div");
    footer.style.cssText = "display:flex; align-items:center; gap:8px; margin-top:2px;";

    // Only rows we could match to an actual recording (by call time,
    // cross-referenced against the recording module — see relay.js)
    // get a player. No match = no player, instead of a broken one.
    if (rec.recordingId) {
      const audio = document.createElement("audio");
      audio.controls = true;
      // "none" was blocking the browser from ever learning the file's
      // duration/byte-length up front, so the seek bar had nothing to
      // seek within until the whole file had streamed in — it looked
      // like you could only ever hear it from the start. "metadata"
      // fetches just the header (a small Range request) immediately,
      // which is enough for the scrubber to work right away, as long
      // as the relay's /play endpoint honors Range requests (206
      // Partial Content + Accept-Ranges: bytes) — see relay.js.
      audio.preload = "metadata";
      audio.style.cssText = "height:30px; flex:1; border-radius:6px;";
      audio.src = `${CALLSEARCH_RELAY_BASE}/play?id=${encodeURIComponent(rec.recordingId)}`;
      audio.onerror = () => audio.remove();

      const downloadLink = document.createElement("a");
      downloadLink.textContent = "⬇ تحميل";
      const niceName = buildRecordingFilename(rec);
      downloadLink.href = `${CALLSEARCH_RELAY_BASE}/play?id=${encodeURIComponent(rec.recordingId)}&download=1&filename=${encodeURIComponent(niceName)}`;
      downloadLink.style.cssText = "color:#2563eb; white-space:nowrap; text-decoration:none; font-size:11px; font-weight:600;";

      footer.appendChild(audio);
      footer.appendChild(downloadLink);
    }

    footer.appendChild(makeAlertButton(rec));

    row.appendChild(line1);
    row.appendChild(line2);
    row.appendChild(line3);
    row.appendChild(footer);
    container.appendChild(row);
    rowEntries.push({ rec, row, footer });
  });
  return rowEntries;
}

// ── Per-employee permission gate ────────────────────────────────────
// Admin toggles this per employee from "صلاحيات الإضافة" in the admin
// dashboard (extensionPermissions/{owner}/{employeeName}/callSearch).
// Default (no record, or lookup fails) is ALLOWED — so a brand-new
// employee, or a hiccup reaching the relay, never breaks the feature
// for everyone; only an explicit "false" hides it. Reuses the same
// cached employee name content.js already reads from the page, so
// this script doesn't need its own name-scraping logic.
const CALLSEARCH_PERMISSION_CACHE_KEY = "mutabaaCallSearchAllowed";
const CALLSEARCH_PERMISSION_CACHE_MS = 6 * 60 * 60 * 1000; // 6h

async function isCallSearchAllowed() {
  try {
    const cached = await new Promise((resolve) =>
      chrome.storage.local.get([CALLSEARCH_PERMISSION_CACHE_KEY], resolve)
    );
    const entry = cached[CALLSEARCH_PERMISSION_CACHE_KEY];
    if (entry && Date.now() - entry.at < CALLSEARCH_PERMISSION_CACHE_MS) {
      return entry.allowed;
    }

    const nameData = await new Promise((resolve) =>
      chrome.storage.local.get(["mutabaaRawName"], resolve)
    );
    const employeeName = nameData.mutabaaRawName;
    if (!employeeName) return true; // don't know who this is yet — fail open

    const res = await fetch(
      `${CALLSEARCH_RELAY_BASE}/permissions/callsearch?employeeName=${encodeURIComponent(employeeName)}`
    );
    if (!res.ok) return true; // relay hiccup — fail open, don't punish everyone
    const data = await res.json();
    const allowed = data.allowed !== false;

    chrome.storage.local.set({
      [CALLSEARCH_PERMISSION_CACHE_KEY]: { allowed, at: Date.now() },
    });
    return allowed;
  } catch (e) {
    console.warn("[متابعة] call search permission check failed, defaulting to allowed:", e);
    return true;
  }
}

(async () => {
  const allowed = await isCallSearchAllowed();
  if (!allowed) {
    console.log("[متابعة] call search widget disabled for this employee by admin");
    return;
  }
  mountCallSearchButtons();
  new MutationObserver(mountCallSearchButtons).observe(document.documentElement, {
    childList: true,
    subtree: true,
  });
  console.log("[متابعة] call search widget active");
})();

// ══════════════════════════════════════════════════════════════════
// متابعة — content-yeastar.js
// Runs on https://192.168.9.30:8088/* (Yeastar P-Series PBX web UI).
// ══════════════════════════════════════════════════════════════════
// Job:
//  1. On the login page, pull the pending creds background.js stashed
//     for us and auto-fill + submit the form.
//  2. Detect when we've LEFT the login page (successful login) and
//     tell background.js so it can clear the "pending" flag.
//  3. Detect when we're back ON the login page after having been
//     logged in — i.e. the PBX session ended — and tell background.js
//     so it can trigger the badala tab to release the line.
// ══════════════════════════════════════════════════════════════════

const FILL_RETRY_MS = 400;
const FILL_RETRY_MAX = 15; // ~6s of retrying while the SPA finishes rendering

function isLoginPage() {
  // Primary signal: Yeastar's web client routes to /login when logged
  // out, regardless of what's mounted (visible or not) in the DOM at
  // that moment — cheaper and more reliable than inspecting elements.
  const path = (window.location.pathname + window.location.hash).toLowerCase();
  if (path.includes("/login")) return true;

  // Fallback for builds/routes where the URL doesn't change: a naive
  // `document.querySelector('input[type="password"])` can be fooled
  // forever by any password input the SPA keeps mounted-but-hidden
  // elsewhere (a closed "change password" modal, a settings panel not
  // currently open, etc.) — Ant Design apps commonly do this. Require
  // the input to actually be visible AND sitting inside a real form
  // before treating it as evidence of being on the login screen.
  const passInputs = document.querySelectorAll('input[type="password"]');
  for (const input of passInputs) {
    const rect = input.getBoundingClientRect();
    const style = window.getComputedStyle(input);
    const isVisible =
      rect.width > 0 &&
      rect.height > 0 &&
      style.display !== "none" &&
      style.visibility !== "hidden";
    if (isVisible && (input.closest("form") || document.querySelector("#login-btn"))) {
      return true;
    }
  }

  return false;
}

function findField(kind) {
  // Yeastar's login form field names vary by firmware build, so try a
  // few reasonable selectors rather than hard-coding one id.
  if (kind === "username") {
    return document.querySelector(
      'input[type="text"][name*="user" i], ' +
      'input[type="text"][placeholder*="Username" i], ' +
      'input[autocomplete="username"], ' +
      'input[name="username"], input#username'
    );
  }
  return document.querySelector(
    'input[type="password"][name*="pass" i], ' +
    'input[type="password"][placeholder*="Password" i], ' +
    'input[autocomplete="current-password"], ' +
    'input[type="password"]'
  );
}

function findLoginButton() {
  // Ant Design's login button (id="login-btn", type="submit") often has
  // no readable textContent at fill-time — its label is painted in
  // asynchronously — so text matching alone misses it. Try the known
  // id first, then fall back to text matching for other PBX builds.
  const byId = document.querySelector("#login-btn, button[type='submit']");
  if (byId) return byId;

  const candidates = Array.from(document.querySelectorAll("button, input[type='submit'], div[role='button']"));
  return candidates.find((el) =>
    /log\s*in|login|دخول/i.test(el.textContent || el.value || "")
  );
}

function setNativeValue(el, value) {
  const proto = Object.getPrototypeOf(el);
  const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
  setter.call(el, value);
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
}

function tryFill(creds, attemptsLeft) {
  const userField = findField("username");
  const passField = findField("password");

  if (!userField || !passField) {
    if (attemptsLeft > 0) {
      setTimeout(() => tryFill(creds, attemptsLeft - 1), FILL_RETRY_MS);
    }
    return;
  }

  setNativeValue(userField, creds.username || "");
  setNativeValue(passField, creds.password || "");

  setTimeout(() => {
    const btn = findLoginButton();
    if (btn) btn.click();
  }, 150);
}

// ── On load: are we the login page, and do we have pending creds? ──
// The Yeastar UI is a slow-rendering SPA — at document_idle the login
// form (and its password input) frequently hasn't been painted yet.
// A single synchronous isLoginPage() check at this point can wrongly
// conclude "not the login page", which used to immediately clear the
// pending creds (yeastarLoginSucceeded) and later misfire a false
// yeastarLoggedOut once the form actually appeared — releasing the
// badala line without ever having filled or submitted anything.
// So: poll for the login form for a few seconds before deciding the
// page is genuinely past login rather than just still loading.
const INITIAL_DETECT_MS = 400;
const INITIAL_DETECT_MAX = 15; // ~6s, matches FILL_RETRY window

// Login state is kept in sessionStorage, not a plain JS variable.
// A real session expiry often ends in a full page navigation/reload
// straight to the login screen — that re-injects this content script
// from scratch, wiping any in-memory variable back to its default
// before it ever gets to compare "was I logged in a moment ago?".
// sessionStorage survives exactly that kind of reload (it's cleared
// only when the tab/session truly ends), so the transition is still
// caught even across a hard navigation, not just SPA route changes.
const SESSION_KEY = "mutabaaYeastarWasLoggedIn";

function wasLoggedIn() {
  return sessionStorage.getItem(SESSION_KEY) === "true";
}

function markLoggedIn(loggedIn) {
  if (loggedIn) sessionStorage.setItem(SESSION_KEY, "true");
  else sessionStorage.removeItem(SESSION_KEY);
}

let initialStateSettled = false;

function detectInitialState(attemptsLeft) {
  if (isLoginPage()) {
    // If sessionStorage says we were logged in right before this load,
    // this IS the logout transition — a reload landed straight on the
    // login screen instead of us catching it via the poller below.
    if (wasLoggedIn()) {
      console.log("[متابعة] PBX logout detected on reload — notifying background");
      chrome.runtime.sendMessage({ type: "yeastarLoggedOut" });
    }
    markLoggedIn(false);
    initialStateSettled = true;

    chrome.runtime.sendMessage({ type: "yeastarRequestPendingCreds" }, (resp) => {
      if (resp && resp.pending) {
        tryFill(resp.pending, FILL_RETRY_MAX);
      }
    });
    return;
  }

  if (attemptsLeft > 0) {
    setTimeout(() => detectInitialState(attemptsLeft - 1), INITIAL_DETECT_MS);
    return;
  }

  // Genuinely no login form after several seconds of polling — we're
  // past login. Safe to clear any stale pending creds now.
  markLoggedIn(true);
  initialStateSettled = true;
  chrome.runtime.sendMessage({ type: "yeastarLoginSucceeded" });
}

detectInitialState(INITIAL_DETECT_MAX);

// ── Watch for a login→dashboard→login roundtrip (session ended) ────
// Covers the SPA-route-change case (no reload at all) that the
// reload-based check in detectInitialState() can't see.
setInterval(() => {
  if (!initialStateSettled) return; // initial detection still settling

  const onLoginNow = isLoginPage();
  if (wasLoggedIn() && onLoginNow) {
    chrome.runtime.sendMessage({ type: "yeastarLoggedOut" });
  }
  markLoggedIn(!onLoginNow);
}, 3000);

// ── Force a real PBX logout on request ──────────────────────────────
// Fired by background.js in two cases:
//   a) the employee clicked "إغلاق البدالة" manually on the badala grid
//   b) we're reusing this tab for a DIFFERENT line's creds and need to
//      drop the current session first (see badalaClaimed in background.js)
// Yeastar's own top-right account menu is an Ant Design dropdown; the
// menu item itself (#h_logout) only renders once the dropdown is open,
// so we may need to open it first via its trigger before we can click it.
const LOGOUT_RETRY_MS = 300;
const LOGOUT_RETRY_MAX = 15; // ~4.5s for the SPA to render the menu

function findLogoutMenuItem() {
  const item = document.querySelector("#h_logout");
  if (!item) return null;
  // #h_logout is ALWAYS present in the DOM (Ant Design keeps the menu
  // mounted), so existence alone doesn't mean the dropdown is open.
  // Check the actual dropdown wrapper is visible instead.
  const wrapper = item.closest(".ant-dropdown");
  if (!wrapper) return null;
  if (wrapper.classList.contains("ant-dropdown-hidden")) return null;
  const rect = wrapper.getBoundingClientRect();
  if (rect.width === 0 || rect.height === 0) return null;
  return item;
}

function findHeaderAccountTrigger() {
  // Confirmed via devtools: the account dropdown's trigger is this
  // exact element in the top-right header.
  return document.querySelector("#headerAccountInfo");
}

function findLogoutConfirmButton() {
  // Ant Design's logout menu item can pop a confirmation modal
  // ("are you sure you want to log out?") before the session actually
  // ends. Clicking #h_logout alone then leaves the tab stuck on this
  // dialog forever, with no error and no visible sign anything failed.
  return document.querySelector(
    ".ant-modal-confirm-btns .ant-btn-primary, .ant-modal-confirm-btns button:last-child"
  );
}

function forceStorageLogoutFallback(reason) {
  // The PBX's own local/session storage holds its auth tokens.
  // Clearing it and forcing a hard navigation to /login ends the
  // session even without ever finding (or successfully triggering)
  // the logout button — this only touches the PBX page's own storage,
  // nothing belonging to the extension or to prime-iq.com/mutabaa.online.
  console.warn("[متابعة] " + reason + " — falling back to clearing local session and redirecting to /login");
  try {
    localStorage.clear();
    sessionStorage.clear();
  } catch (e) {
    // Ignore — storage may be restricted in this context.
  }
  window.location.href = "https://192.168.9.30:8088/login";
}

function attemptLogoutClick(attemptsLeft) {
  // A confirmation modal from a previous click may already be open.
  const confirmBtn = findLogoutConfirmButton();
  if (confirmBtn) {
    confirmBtn.click();
    console.log("[متابعة] clicked PBX logout confirmation button");
    return;
  }

  const item = findLogoutMenuItem();
  if (item) {
    item.click();
    console.log("[متابعة] clicked PBX logout menu item");
    // The confirmation modal (if this build shows one) renders shortly
    // after — give it a moment, then click it too.
    setTimeout(() => {
      const btn = findLogoutConfirmButton();
      if (btn) {
        btn.click();
        console.log("[متابعة] clicked PBX logout confirmation button");
      }

      // Verify the click(s) actually ended the session rather than
      // assuming success just because something was clickable — a
      // menu item can fire and still leave the session open (backend
      // hiccup, unexpected extra confirmation step, etc.), and nothing
      // upstream of this function otherwise checks the outcome.
      setTimeout(() => {
        if (!isLoginPage()) {
          forceStorageLogoutFallback("PBX still on dashboard after clicking logout");
        }
      }, 1200);
    }, 250);
    return;
  }

  // Dropdown not open yet — try to open it.
  const trigger = findHeaderAccountTrigger();
  if (trigger) {
    trigger.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true }));
    trigger.dispatchEvent(new MouseEvent("mouseover", { bubbles: true }));
    trigger.click();
  }

  if (attemptsLeft > 0) {
    setTimeout(() => attemptLogoutClick(attemptsLeft - 1), LOGOUT_RETRY_MS);
  } else {
    // Last resort: the menu/trigger selectors may not match this PBX
    // firmware build at all.
    forceStorageLogoutFallback("could not find/open the PBX account menu to force-logout");
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== "forceLogout") return;

  console.log("[متابعة] forceLogout message received in this tab");

  if (isLoginPage()) {
    console.log("[متابعة] already on login page — requesting pending creds instead");
    // Already logged out — this tab is just waiting to be filled with
    // whatever creds are pending now (e.g. a different line's creds
    // arrived after this tab was already sitting on the login page).
    chrome.runtime.sendMessage({ type: "yeastarRequestPendingCreds" }, (resp) => {
      if (resp && resp.pending) tryFill(resp.pending, FILL_RETRY_MAX);
    });
    sendResponse({ ok: true, path: "already-login" });
    return;
  }

  console.log("[متابعة] not on login page — attempting logout click");
  attemptLogoutClick(LOGOUT_RETRY_MAX);
  sendResponse({ ok: true, path: "attempting-click" });
});

console.log("[متابعة] yeastar login watcher active");

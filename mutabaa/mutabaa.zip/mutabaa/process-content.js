// process-content.js
// -----------------------------------------------------------------------
// Purpose: prevent lost work when the PC/tab crashes or reloads while an
// employee is mid-way through choosing a case's disposition
// (حالة صحيحة / تعذر توصيل + سبب الراجع / موجل + تاريخ / اعادة توصيل / لا يرد
// على المتابعة).
//
// Strategy:
//   1. Every relevant <select>/<input> lives inside a <tr smartykeycolval="...">.
//      That attribute (mirrored in a hidden input smarty_c_id_hidden_smartyrow_N)
//      is the REAL, stable order id — not the smartyrow_N index, which just
//      reflects render position and shifts as rows load/reorder.
//   2. On every "change" event inside such a row, we snapshot all of that
//      row's relevant fields into chrome.storage.local, keyed by the order id.
//   3. On load, and whenever new rows appear (the table is populated/refreshed
//      via AJAX), we look up each visible row's order id in storage and, if a
//      saved choice exists, show a small colored dot next to the row number
//      with a tooltip describing the last choice and how long ago it was made.
//   4. We deliberately do NOT auto-fill the dropdowns from the cache — only
//      show the reminder — so we never risk silently applying a stale choice
//      to what might now be a different case state. The employee decides.
//   5. Old entries are purged after MAX_AGE_MS so storage doesn't grow forever.
//
// This file is independent from content.js (order start/end + activity
// tracking) and touches a completely different part of the page.
// -----------------------------------------------------------------------
//
// PERFORMANCE NOTES (marked [PERF] below): bounded LRU caches, AbortController
// for in-flight fetches, throttled storage cleanup, coalesced mutation handling.
// -----------------------------------------------------------------------

(function () {
  "use strict";

  console.log("[متابعة-process] process-content.js loaded on:", location.href);

  // [PERF] Centralized config — tune these to control resource usage
  const CONFIG = {
    MAX_CACHE_SIZE: 150,           // [PERF] Prevent unbounded Map growth
    MUTATION_DEBOUNCE_MS: 300,
    CLEANUP_INTERVAL_MS: 60 * 1000,
    MAX_AGE_MS: 2 * 60 * 60 * 1000,
    DEADLINE_CACHE_TTL_MS: 3 * 60 * 1000,
    SUMMARY_DISPLAY_MS: 10000,
    // [PERF] Throttle storage cleanup — don't scan all keys every minute
    STORAGE_CLEANUP_INTERVAL_MS: 5 * 60 * 1000,
  };

  // ---------------------------------------------------------------------
  // Extension context guards (unchanged logic, condensed)
  // ---------------------------------------------------------------------
  function isExtensionContextValid() {
    try { return !!(chrome && chrome.runtime && chrome.runtime.id); }
    catch (e) { return false; }
  }

  if (typeof chrome !== "undefined" && chrome.storage?.local) {
    const wrap = (fn, fallback) => (...args) => {
      if (!isExtensionContextValid()) {
        const cb = args[args.length - 1];
        if (typeof cb === "function") setTimeout(() => cb(fallback), 0);
        return;
      }
      try { return fn(...args); }
      catch (e) {
        const cb = args[args.length - 1];
        if (typeof cb === "function") setTimeout(() => cb(fallback), 0);
      }
    };
    chrome.storage.local.get = wrap(chrome.storage.local.get.bind(chrome.storage.local), {});
    chrome.storage.local.set = wrap(chrome.storage.local.set.bind(chrome.storage.local), null);
    chrome.storage.local.remove = wrap(chrome.storage.local.remove.bind(chrome.storage.local), null);
  }

  function isContextInvalidatedError(err) {
    const msg = err && (err.message || String(err));
    return typeof msg === "string" && msg.includes("Extension context invalidated");
  }
  window.addEventListener("error", (e) => {
    if (isContextInvalidatedError(e.error || e)) e.preventDefault();
  });
  window.addEventListener("unhandledrejection", (e) => {
    if (isContextInvalidatedError(e.reason)) e.preventDefault();
  });

  const ALLOWED_PATHS = [
    "/tickets/CasesFollowUp",
    "/tickets/under-revision-by-emp",
    "/tickets/Needs-revision-branch-customers",
  ];

  // ---------------------------------------------------------------------
  // Internal request rules (unchanged)
  // ---------------------------------------------------------------------
  const INTERNAL_REQUEST_NEIGHBORHOODS = [
    "حي العامل", "العامرية", "المحمودية", "ابو غريب", "اليرموك",
    "حي العدل", "حي الجامعة", "حي القادسية", "القادسية", "السيدية",
    "نفق الشرطة", "الحارثية", "حي القاهرة", "حي تونس", "الكريعات",
    "كريعات", "الشعلة", "الحرية",
  ];
  const INTERNAL_MATCH_EXCLUSIONS = [
    { ifAddressContains: "كفاءات", blockNeighborhood: "السيدية" },
  ];

  function normalizeAlif(str) {
    return String(str || "").replace(/[أإآ]/g, "ا");
  }

  function isInternalAddress(rawAddress) {
    const addressText = normalizeAlif(String(rawAddress || "").replace(/\s+/g, " ").trim());
    if (!addressText || !addressText.includes(normalizeAlif("بغداد"))) return false;
    return INTERNAL_REQUEST_NEIGHBORHOODS.some((n) => {
      if (!n?.trim()) return false;
      if (!addressText.includes(normalizeAlif(n.trim()))) return false;
      const blocked = INTERNAL_MATCH_EXCLUSIONS.some(
        (ex) => ex.blockNeighborhood === n && addressText.includes(normalizeAlif(ex.ifAddressContains))
      );
      return !blocked;
    });
  }

  // ---------------------------------------------------------------------
  // Order details page (early return, unchanged logic)
  // ---------------------------------------------------------------------
  if (location.pathname.includes("displaySingleCaseInfo")) {
    initDetailsPageBadge();
    return;
  }

  function initDetailsPageBadge() {
    const BADGE_CLASS = "mutabaa-internal-detail-badge";
    const clean = (t) => String(t || "").replace(/\s+/g, " ").trim();

    function getFieldValue(attrPart, labelText) {
      let container = document.querySelector(`[smarty_singledispalycol*="${attrPart}_coldiv"]`);
      if (!container) {
        for (const c of document.querySelectorAll("[smarty_singledispalycol]")) {
          const h = c.querySelector("h6");
          if (h && normalizeAlif(clean(h.textContent)) === normalizeAlif(labelText)) {
            container = c; break;
          }
        }
      }
      if (!container) return null;
      const valueCell = container.querySelector(".col-sm-7");
      return valueCell ? clean(valueCell.textContent) : null;
    }

    function findAddressText() {
      const state = getFieldValue("c_rcv_state", "المحافظة");
      const city = getFieldValue("c_rcv_district", "المدينة");
      if (state === null && city === null) return null;
      return clean(`${state || ""} - ${city || ""}`);
    }

    function findStatusBadge() {
      let el = document.querySelector(`.row.mb-2 .col-3 .badge:not(.${BADGE_CLASS})`);
      if (el && clean(el.textContent)) return el;
      for (const b of document.querySelectorAll(`.col-3 .badge:not(.${BADGE_CLASS})`)) {
        if (clean(b.textContent)) return b;
      }
      for (const b of document.querySelectorAll(`.badge:not(.${BADGE_CLASS})`)) {
        if (/المندوب|المراجعة|الفرع|تدقيق/.test(clean(b.textContent))) return b;
      }
      return null;
    }

    function apply() {
      const statusBadge = findStatusBadge();
      if (!statusBadge) return;
      const host = statusBadge.parentElement;
      const addressText = findAddressText();
      let badge = host.querySelector(`.${BADGE_CLASS}`);
      const internal = addressText !== null && isInternalAddress(addressText);

      if (!internal) {
        badge?.remove();
        console.log("[متابعة-process] details: not internal / address not found:", addressText);
        return;
      }
      if (badge) return;

      badge = document.createElement("span");
      badge.className = `badge bg-danger ${BADGE_CLASS}`;
      badge.textContent = "طلب داخلي";
      badge.style.cssText = "font-size:13px;display:table;clear:both;position:static;float:none;margin:10px 0;line-height:1.5;padding:5px 10px;";
      statusBadge.insertAdjacentElement("afterend", badge);
    }

    let timer = null;
    const schedule = () => {
      if (timer) clearTimeout(timer);
      timer = setTimeout(apply, 250);
    };

    apply();
    new MutationObserver((mutations) => {
      if (mutations.every((m) => m.target.closest?.(`.${BADGE_CLASS}`))) return;
      schedule();
    }).observe(document.documentElement, { childList: true, subtree: true });
  }

  if (!ALLOWED_PATHS.some((p) => location.pathname.includes(p))) {
    console.log("[متابعة-process] skipped — path not in allowed list:", location.pathname);
    return;
  }

  console.log("[متابعة-process] path matched, initializing...");

  const STORAGE_PREFIX = "procstate_";
  const FIELD_ID_PATTERN = /_smartyrow_\d+/;

  // -----------------------------------------------------------------------
  // [PERF] Bounded cache with LRU eviction — prevents memory leaks
  // -----------------------------------------------------------------------
  class BoundedCache {
    constructor(maxSize) {
      this.maxSize = maxSize;
      this.map = new Map();
    }
    get(key) {
      const val = this.map.get(key);
      if (val !== undefined) {
        // Refresh recency
        this.map.delete(key);
        this.map.set(key, val);
      }
      return val;
    }
    set(key, value) {
      if (this.map.has(key)) this.map.delete(key);
      this.map.set(key, value);
      if (this.map.size > this.maxSize) {
        // Evict oldest (first key)
        const oldest = this.map.keys().next().value;
        this.map.delete(oldest);
      }
    }
    delete(key) { this.map.delete(key); }
    has(key) { return this.map.has(key); }
    keys() { return this.map.keys(); }
    get size() { return this.map.size; }
  }

  // [PERF] Replace unbounded Maps with bounded caches
  const deadlineCache = new BoundedCache(CONFIG.MAX_CACHE_SIZE);
  const rowSummaryCache = new BoundedCache(CONFIG.MAX_CACHE_SIZE);
  const rowSummaryHideTimers = new Map(); // Small: only active timers

  // [PERF] Track pending fetches to allow cancellation
  const pendingFetches = new Map(); // orderId -> AbortController

  // -----------------------------------------------------------------------
  // Helpers (unchanged)
  // -----------------------------------------------------------------------
  function log(...args) {
    if (true) console.log("[متابعة-process]", ...args);
  }

  const getRow = (el) => el.closest("tr[smartykeycolval]");
  const getOrderId = (row) => row?.getAttribute("smartykeycolval");
  const fieldBaseKey = (id) => id.replace(/_smartyrow_\d+.*/, "");
  const storageKey = (orderId) => STORAGE_PREFIX + orderId;

  function readFieldValue(el) {
    if (el.tagName === "SELECT") {
      const opt = el.selectedOptions?.[0];
      return { value: el.value, label: opt ? opt.textContent.trim() : el.value };
    }
    return { value: el.value, label: el.value };
  }

  // -----------------------------------------------------------------------
  // Saving (unchanged logic)
  // -----------------------------------------------------------------------
  function collectRowFields(row) {
    const fields = {};
    row.querySelectorAll("select, input, textarea").forEach((el) => {
      const idOrName = el.id || el.name || "";
      if (!FIELD_ID_PATTERN.test(idOrName)) return;
      const { value, label } = readFieldValue(el);
      if (value === "" || value == null) return;
      fields[fieldBaseKey(idOrName)] = { value, label };
    });
    return fields;
  }

  const MAX_HISTORY = 10;

  function getHistory(record) {
    if (!record) return [];
    let list = [];
    if (Array.isArray(record.history)) list = record.history;
    else if (record.fields) list = [{ fields: record.fields, ts: record.ts }];
    const cutoff = Date.now() - CONFIG.MAX_AGE_MS;
    return list.filter((e) => e?.ts && e.ts >= cutoff);
  }

  function sameFields(a, b) {
    const ka = Object.keys(a);
    if (ka.length !== Object.keys(b).length) return false;
    return ka.every((k) => b[k]?.value === a[k].value);
  }

  function saveRowState(row) {
    const orderId = getOrderId(row);
    if (!orderId) return;
    const fields = collectRowFields(row);
    if (Object.keys(fields).length === 0) return;

    const key = storageKey(orderId);
    chrome.storage.local.get([key], (res) => {
      const history = getHistory(res?.[key]).slice();
      const last = history[history.length - 1];
      const now = Date.now();
      if (!(last && sameFields(last.fields, fields))) {
        history.push({ fields, ts: now });
        while (history.length > MAX_HISTORY) history.shift();
      }
      const record = { history, ts: history[history.length - 1].ts };
      chrome.storage.local.set({ [key]: record }, () => {
        log("saved", orderId);
        applyBadge(row, record);
      });
    });
  }

  function onFieldChange(e) {
    const el = e.target;
    if (!el?.id && !el?.name) return;
    const idOrName = el.id || el.name;
    if (!FIELD_ID_PATTERN.test(idOrName)) return;
    const row = getRow(el);
    if (row) saveRowState(row);
  }

  // -----------------------------------------------------------------------
  // Badges & popover (unchanged)
  // -----------------------------------------------------------------------
  function timeAgo(ts) {
    const diffMin = Math.round((Date.now() - ts) / 60000);
    if (diffMin < 1) return "الآن";
    if (diffMin < 60) return `قبل ${diffMin} دقيقة`;
    const diffH = Math.round(diffMin / 60);
    if (diffH < 24) return `قبل ${diffH} ساعة`;
    return `قبل ${Math.round(diffH / 24)} يوم`;
  }

  function formatClock(ts) {
    const d = new Date(ts);
    let h = d.getHours();
    const m = String(d.getMinutes()).padStart(2, "0");
    const suffix = h >= 12 ? "م" : "ص";
    h = h % 12 || 12;
    return `${h}:${m} ${suffix}`;
  }

  const assignDateColumnIndexByTable = new WeakMap();

  function getSavedChipCell(row) {
    const table = row.closest("table");
    if (table) {
      const index = findColumnIndex(table, assignDateColumnIndexByTable, (clean) =>
        normalizeAlif(clean).includes("تاريخ الاعطاء")
      );
      if (index !== -1) {
        const cells = row.querySelectorAll("td");
        if (cells[index]) return cells[index];
      }
    }
    return row.querySelector("td.cell");
  }

  let savedPopover = null, savedPopoverChip = null, savedPopoverPinned = false, savedPopoverHideTimer = null;

  function getSavedPopover() {
    if (savedPopover) return savedPopover;
    const pop = document.createElement("div");
    pop.className = "mutabaa-saved-popover";
    pop.style.cssText = [
      "position:fixed", "display:none", "z-index:2147483647", "min-width:150px", "max-width:260px",
      "padding:8px 10px", "background:#111827", "color:#f9fafb", "border:1px solid #2ecc71",
      "border-radius:8px", "box-shadow:0 6px 20px rgba(0,0,0,0.45)", "font-size:12px",
      "line-height:1.7", "direction:rtl", "text-align:right",
    ].join(";");
    pop.addEventListener("mouseenter", () => savedPopoverHideTimer && clearTimeout(savedPopoverHideTimer));
    pop.addEventListener("mouseleave", () => scheduleHideSavedPopover());
    pop.addEventListener("click", (ev) => ev.stopPropagation());
    document.body.appendChild(pop);
    document.addEventListener("click", () => hideSavedPopover(), true);
    document.addEventListener("keydown", (ev) => { if (ev.key === "Escape") hideSavedPopover(); });
    window.addEventListener("scroll", () => hideSavedPopover(), true);
    savedPopover = pop;
    return pop;
  }

  const hideSavedPopover = () => {
    savedPopoverHideTimer && clearTimeout(savedPopoverHideTimer);
    savedPopoverPinned = false;
    savedPopoverChip = null;
    savedPopover && (savedPopover.style.display = "none");
  };

  function scheduleHideSavedPopover() {
    if (savedPopoverPinned) return;
    savedPopoverHideTimer && clearTimeout(savedPopoverHideTimer);
    savedPopoverHideTimer = setTimeout(hideSavedPopover, 200);
  }

  function showSavedPopover(chip) {
    const record = chip._mutabaaRecord;
    if (!record) return;
    savedPopoverHideTimer && clearTimeout(savedPopoverHideTimer);
    const pop = getSavedPopover();
    savedPopoverChip = chip;
    pop.textContent = "";

    const title = document.createElement("div");
    title.style.cssText = "font-weight:bold;color:#9ca3af;margin-bottom:4px;";
    title.textContent = "الاختيارات المحفوظة";
    pop.appendChild(title);

    getHistory(record).slice().reverse().forEach((entry, i) => {
      const box = document.createElement("div");
      box.style.cssText = `padding:4px 0;${i > 0 ? "border-top:1px solid #374151;" : ""}`;
      const head = document.createElement("div");
      head.style.cssText = `font-size:11px;color:${i === 0 ? "#2ecc71" : "#9ca3af"};`;
      head.textContent = `${formatClock(entry.ts)} · ${timeAgo(entry.ts)}`;
      box.appendChild(head);
      Object.values(entry.fields).forEach((f) => {
        const line = document.createElement("div");
        line.textContent = f.label;
        box.appendChild(line);
      });
      pop.appendChild(box);
    });

    pop.style.display = "block";
    const r = chip.getBoundingClientRect();
    const pw = pop.offsetWidth, ph = pop.offsetHeight;
    let left = Math.max(8, Math.min(r.left + r.width / 2 - pw / 2, window.innerWidth - pw - 8));
    let top = r.bottom + 6;
    if (top + ph > window.innerHeight - 8) top = Math.max(8, r.top - ph - 6);
    pop.style.left = left + "px";
    pop.style.top = top + "px";
  }

  function applyBadge(row, record) {
    const cell = getSavedChipCell(row);
    if (!cell) return;

    const existing = row.querySelector(".mutabaa-saved-dot");
    if (existing && existing.parentElement !== cell) existing.remove();

    let chip = cell.querySelector(".mutabaa-saved-dot");
    if (!chip) {
      chip = document.createElement("div");
      chip.className = "mutabaa-saved-dot";
      chip.textContent = "●";
      chip.style.cssText = [
        "display:block", "width:fit-content", "margin:2px auto 0", "padding:0 4px",
        "font-size:20px", "line-height:1", "color:#2ecc71", "cursor:pointer", "user-select:none",
      ].join(";");
      cell.appendChild(chip);
      chip.addEventListener("mouseenter", () => { if (!savedPopoverPinned) showSavedPopover(chip); });
      chip.addEventListener("mouseleave", () => scheduleHideSavedPopover());
      chip.addEventListener("click", (ev) => {
        ev.stopPropagation(); ev.preventDefault();
        if (savedPopoverPinned && savedPopoverChip === chip) { hideSavedPopover(); return; }
        showSavedPopover(chip);
        savedPopoverPinned = true;
      });
    }
    chip._mutabaaRecord = record;
    if (savedPopoverChip === chip && savedPopover?.style.display !== "none") {
      showSavedPopover(chip);
    }
  }

  const removeBadge = (row) => row.querySelector(".mutabaa-saved-dot")?.remove();

  function restoreRow(row, cachedRecords) {
    const orderId = getOrderId(row);
    if (!orderId) return;
    const record = cachedRecords[storageKey(orderId)];
    record && getHistory(record).length > 0 ? applyBadge(row, record) : removeBadge(row);
  }

  // [PERF] Debounced batch restore — prevents storage spam during rapid mutations
  let restoreThrottleTimer = null;
  let pendingRestoreRows = new Set();

  function queueRestoreRows(rows) {
    rows.forEach((r) => pendingRestoreRows.add(r));
    if (restoreThrottleTimer) return;
    restoreThrottleTimer = setTimeout(() => {
      restoreThrottleTimer = null;
      const rows = Array.from(pendingRestoreRows);
      pendingRestoreRows.clear();
      if (!rows.length) return;

      const keys = rows.map(getOrderId).filter(Boolean).map(storageKey);
      if (!keys.length) return;

      chrome.storage.local.get(keys, (cached) => rows.forEach((row) => restoreRow(row, cached)));
    }, 100);
  }

  function restoreVisibleRows() {
    queueRestoreRows(Array.from(document.querySelectorAll("tr[smartykeycolval]")));
  }

  // -----------------------------------------------------------------------
  // [PERF] Throttled cleanup — was running every 60s with get(null)
  // -----------------------------------------------------------------------
  let lastCleanupTime = 0;

  function cleanupOldEntries() {
    const now = Date.now();
    // [PERF] Skip if ran recently (unless forced)
    if (now - lastCleanupTime < CONFIG.STORAGE_CLEANUP_INTERVAL_MS) return;
    lastCleanupTime = now;

    // [PERF] Prune caches for non-visible orders
    const visibleOrderIds = new Set(
      Array.from(document.querySelectorAll("tr[smartykeycolval]")).map(getOrderId).filter(Boolean)
    );

    for (const orderId of Array.from(deadlineCache.keys())) {
      if (!visibleOrderIds.has(orderId)) deadlineCache.delete(orderId);
    }
    for (const orderId of Array.from(rowSummaryCache.keys())) {
      if (visibleOrderIds.has(orderId)) continue;
      rowSummaryCache.delete(orderId);
      const timer = rowSummaryHideTimers.get(orderId);
      if (timer) { clearTimeout(timer); rowSummaryHideTimers.delete(orderId); }
    }

    // [PERF] Cancel pending fetches for non-visible orders
    for (const [orderId, controller] of pendingFetches) {
      if (!visibleOrderIds.has(orderId)) {
        controller.abort();
        pendingFetches.delete(orderId);
      }
    }

    // [PERF] Only scan storage if we have visible rows (skip on idle pages)
    if (!visibleOrderIds.size) return;

    chrome.storage.local.get(null, (all) => {
      const toRemove = [], toUpdate = {};
      for (const key in all) {
        if (!key.startsWith(STORAGE_PREFIX)) continue;
        const record = all[key];
        const live = getHistory(record);
        if (!live.length) toRemove.push(key);
        else if (!Array.isArray(record.history) || live.length !== record.history.length) {
          toUpdate[key] = { history: live, ts: live[live.length - 1].ts };
        }
      }
      const done = () => restoreVisibleRows();
      if (Object.keys(toUpdate).length) chrome.storage.local.set(toUpdate);
      toRemove.length ? chrome.storage.local.remove(toRemove, done) : done();
    });
  }

  // -----------------------------------------------------------------------
  // Search button (unchanged)
  // -----------------------------------------------------------------------
  const PHONE_PATTERN = /07\d{9}/;
  const GLOBAL_SEARCH_PATH = "/myp/Mainctrl/cases/displayGlobalSearchResults?globalSerachParamter=";
  const SEARCH_TAB_NAME = "mutabaaGlobalSearchTab";
  const phoneColumnIndexByTable = new WeakMap();

  const findPhoneInRow = (row) => {
    const cell = getPhoneCell(row);
    return cell?.textContent.match(PHONE_PATTERN)?.[0] || null;
  };

  function getPhoneColumnIndex(table) {
    if (phoneColumnIndexByTable.has(table)) return phoneColumnIndexByTable.get(table);
    let index = -1;
    table.querySelectorAll("thead th, tr:first-child th, tr:first-child td").forEach((th, i) => {
      if (index === -1 && th.textContent.replace(/\s+/g, " ").trim().includes("هاتف المستلم")) index = i;
    });
    phoneColumnIndexByTable.set(table, index);
    return index;
  }

  function getPhoneCell(row) {
    const table = row.closest("table");
    if (!table) return null;
    const index = getPhoneColumnIndex(table);
    if (index !== -1) {
      const cells = row.querySelectorAll("td");
      if (cells[index]) return cells[index];
    }
    return Array.from(row.querySelectorAll("td")).find((td) => PHONE_PATTERN.test(td.textContent)) || null;
  }

  function applySearchButton(row) {
    try {
      const targetCell = getPhoneCell(row);
      if (!targetCell || targetCell.querySelector(".mutabaa-search-btn")) return;
      if (!PHONE_PATTERN.test(targetCell.textContent)) return;

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "mutabaa-search-btn";
      btn.textContent = "ابحث في النظام";
      btn.style.cssText = [
        "display:block", "margin:18px auto 0", "padding:2px 8px", "font-size:11px",
        "line-height:1.6", "border-radius:4px", "border:1px solid #9ca3af",
        "background:#9ca3af", "color:#fff", "cursor:pointer", "white-space:nowrap",
      ].join(";");

      btn.addEventListener("click", (ev) => {
        ev.stopPropagation(); ev.preventDefault();
        const phone = findPhoneInRow(row);
        if (!phone) { alert("لم يتم العثور على رقم هاتف في هذا الصف."); return; }
        if (window.name === SEARCH_TAB_NAME) window.name = "";
        window.open(location.origin + GLOBAL_SEARCH_PATH + encodeURIComponent(phone), SEARCH_TAB_NAME);
      });

      targetCell.appendChild(btn);
    } catch (e) {
      console.error("[متابعة-process] applySearchButton error:", e);
    }
  }

  const applySearchButtonsToVisibleRows = () =>
    document.querySelectorAll("tr[smartykeycolval]").forEach(applySearchButton);

  // -----------------------------------------------------------------------
  // [PERF] Case summary with AbortController and bounded cache
  // -----------------------------------------------------------------------
  const SUMMARY_FIELD_SUFFIXES = { itemType: "itemsdetails", agentName: "dlvagentname", createdAt: "c_createddt", remarks: "c_rmk" };
  const DETAILS_LABELS = new Set(["تفاصيل", "التفاصيل"]);

  function getFieldValueFromDoc(doc, suffix) {
    const container = doc.querySelector(`[smarty_singledispalycol="smarty_singledispalycol_${suffix}_coldiv"]`);
    if (!container) return null;
    const valueCell = container.querySelector(".col-sm-7");
    if (valueCell) return valueCell.textContent.replace(/\s+/g, " ").trim() || null;
    const clone = container.cloneNode(true);
    clone.querySelectorAll("h6").forEach((h) => h.remove());
    return clone.textContent.replace(/\s+/g, " ").trim() || null;
  }

  const isDetailsButtonCell = (cell) => DETAILS_LABELS.has(cell.textContent.replace(/\s+/g, " ").trim());

  async function fetchItemTypesFromDetailsPage(auditCaseId, signal) {
    try {
      const res = await fetch(
        `${location.origin}/myp/Mainctrl/cases/itemDetails?auditcaseid=${encodeURIComponent(auditCaseId)}`,
        { credentials: "include", signal }
      );
      if (!res.ok) return null;
      const doc = new DOMParser().parseFromString(await res.text(), "text/html");
      const table = doc.querySelector("table");
      if (!table) return null;

      let typeIndex = -1;
      table.querySelectorAll("thead th").forEach((th, i) => {
        if (typeIndex === -1 && th.textContent.includes("نوع البضاعة")) typeIndex = i;
      });
      if (typeIndex === -1) return null;

      const counts = new Map();
      table.querySelectorAll("tbody tr").forEach((row) => {
        const val = row.querySelectorAll("td")[typeIndex]?.textContent.replace(/\s+/g, " ").trim();
        if (val) counts.set(val, (counts.get(val) || 0) + 1);
      });
      if (!counts.size) return null;
      return Array.from(counts.entries()).map(([t, c]) => (c > 1 ? `${t} (${c})` : t)).join("، ");
    } catch (e) {
      if (e.name !== "AbortError") console.error("[متابعة-process] fetchItemTypes error:", e);
      return null;
    }
  }

  async function resolveItemTypeFromDoc(doc, auditCaseId, signal) {
    const container = doc.querySelector(`[smarty_singledispalycol="smarty_singledispalycol_${SUMMARY_FIELD_SUFFIXES.itemType}_coldiv"]`);
    if (!container) return null;
    const valueCell = container.querySelector(".col-sm-7");
    if (!valueCell) return null;
    if (!isDetailsButtonCell(valueCell)) return valueCell.textContent.replace(/\s+/g, " ").trim() || null;
    return await fetchItemTypesFromDetailsPage(auditCaseId, signal);
  }

  function parseDateFlexible(raw) {
    if (!raw) return null;
    let d = new Date(raw.replace(" ", "T"));
    if (!isNaN(d.getTime())) return d;
    const m = raw.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?/);
    if (m) {
      const [, mo, day, yr, hh, mm, ss] = m;
      d = new Date(Number(yr), Number(mo) - 1, Number(day), Number(hh), Number(mm), Number(ss || 0));
      if (!isNaN(d.getTime())) return d;
    }
    return null;
  }

  function formatAge(createdDate) {
    if (!createdDate) return null;
    const diffMs = Date.now() - createdDate.getTime();
    if (diffMs < 0) return null;
    const minutes = Math.floor(diffMs / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    if (days >= 1) {
      const remHours = hours % 24;
      return remHours > 0 ? `${days} يوم و ${remHours} ساعة` : `${days} يوم`;
    }
    if (hours >= 1) return `${hours} ساعة`;
    return `${minutes} دقيقة`;
  }

  function extractLastProcessedBy(doc) {
    const table = doc.querySelector('table[id*="AuditTrailPopUp"]');
    if (!table) return null;
    const rows = Array.from(table.querySelectorAll("tbody tr"));
    for (let i = rows.length - 1; i >= 0; i--) {
      const cells = Array.from(rows[i].querySelectorAll("td"));
      const empIndex = cells.findIndex((td) => /موظف\s*:?/.test(td.textContent));
      if (empIndex === -1) continue;
      const empText = cells[empIndex].textContent.replace(/\s+/g, " ").trim();
      const name = (empText.match(/موظف\s*:?\s*(.+)/)?.[1] || empText).trim();
      const outcome = cells[empIndex - 2]?.textContent.replace(/\s+/g, " ").trim() || null;
      return { name: name || null, outcome };
    }
    return null;
  }

  // [PERF] Added AbortSignal support
  async function fetchCaseSummary(orderId, signal) {
    try {
      const res = await fetch(
        `${location.origin}/myp/Mainctrl/cases/displaySingleCaseInfo?auditcaseid=${encodeURIComponent(orderId)}`,
        { credentials: "include", signal }
      );
      if (!res.ok) return null;
      const doc = new DOMParser().parseFromString(await res.text(), "text/html");

      const [itemType, agentName, createdRaw, remarks, lastProcessed] = await Promise.all([
        resolveItemTypeFromDoc(doc, orderId, signal),
        Promise.resolve(getFieldValueFromDoc(doc, SUMMARY_FIELD_SUFFIXES.agentName)),
        Promise.resolve(getFieldValueFromDoc(doc, SUMMARY_FIELD_SUFFIXES.createdAt)),
        Promise.resolve(getFieldValueFromDoc(doc, SUMMARY_FIELD_SUFFIXES.remarks)),
        Promise.resolve(extractLastProcessedBy(doc)),
      ]);

      return {
        itemType: itemType || "غير متوفر",
        agentName: agentName || "غير متوفر",
        age: formatAge(parseDateFlexible(createdRaw)) || (createdRaw ? `${createdRaw} (تعذر حساب العمر)` : "غير متوفر"),
        remarks: remarks || "غير متوفر",
        lastProcessedByName: lastProcessed?.name || "غير متوفر",
        lastProcessedOutcome: lastProcessed?.outcome || "غير متوفر",
      };
    } catch (e) {
      if (e.name !== "AbortError") console.error("[متابعة-process] fetchCaseSummary error:", e);
      return null;
    }
  }

  function renderRowSummaryBox(targetCell) {
    let box = targetCell.querySelector(".mutabaa-row-summary");
    if (!box) {
      box = document.createElement("div");
      box.className = "mutabaa-row-summary";
      box.style.cssText = [
        "display:none", "margin-top:4px", "padding:4px 6px", "font-size:10px", "line-height:1.5",
        "text-align:right", "color:#1f2937", "background:#f3f4f6", "border:1px solid #e5e7eb",
        "border-radius:4px", "max-width:220px",
      ].join(";");
      targetCell.appendChild(box);
    }
    return box;
  }

  const SUMMARY_ROWS = [
    ["نوع البضاعة", "itemType", "#dbeafe"],
    ["مندوب التوصيل", "agentName", "#dcfce7"],
    ["عمر الطلب", "age", "#fef9c3"],
    ["ملاحظات", "remarks", "#fee2e2"],
    ["آخر موظف", "lastProcessedByName", "#ede9fe"],
    ["نتيجة معالجته", "lastProcessedOutcome", "#ffedd5"],
  ];

  const escapeHtml = (str) =>
    String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  const buildSummaryHtml = (summary) =>
    SUMMARY_ROWS.map(([label, key, bg]) =>
      `<div style="display:flex;justify-content:space-between;gap:6px;padding:2px 4px;margin-bottom:2px;border-radius:3px;background:${bg};">` +
      `<span style="color:#4b5563;white-space:nowrap;">${escapeHtml(label)}</span>` +
      `<span style="font-weight:bold;color:#111827;text-align:left;">${escapeHtml(summary[key])}</span></div>`
    ).join("");

  async function revealRowSummary(row, btn, box) {
    const orderId = getOrderId(row);
    if (!orderId) return;

    const existingTimer = rowSummaryHideTimers.get(orderId);
    if (existingTimer) clearTimeout(existingTimer);

    btn.style.display = "none";
    box.style.display = "block";

    const cached = rowSummaryCache.get(orderId);
    let html;

    if (cached && cached !== "pending" && cached !== "error") {
      html = cached.html;
    } else {
      box.textContent = "جارٍ التحميل...";

      // [PERF] Create abort controller for this fetch
      const controller = new AbortController();
      pendingFetches.set(orderId, controller);

      const summary = await fetchCaseSummary(orderId, controller.signal);

      // [PERF] Clean up pending fetch
      pendingFetches.delete(orderId);

      // [PERF] Don't update if row was removed while fetching
      if (!document.contains(row)) return;

      if (!summary) {
        rowSummaryCache.set(orderId, "error");
        html = "تعذر جلب التفاصيل";
      } else {
        html = buildSummaryHtml(summary);
        rowSummaryCache.set(orderId, { html });
      }
    }

    box.innerHTML = html;

    const timer = setTimeout(() => {
      box.style.display = "none";
      btn.style.display = "block";
      rowSummaryHideTimers.delete(orderId);
    }, CONFIG.SUMMARY_DISPLAY_MS);
    rowSummaryHideTimers.set(orderId, timer);
  }

  const dateColumnIndexByTable = new WeakMap();

  function getDateColumnIndex(table) {
    if (dateColumnIndexByTable.has(table)) return dateColumnIndexByTable.get(table);
    let index = -1;
    table.querySelectorAll("thead th, tr:first-child th, tr:first-child td").forEach((th, i) => {
      const clean = th.textContent.replace(/\s+/g, " ").trim();
      if (index === -1 && (clean.includes("تاريخ الشحنه") || clean.includes("تاريخ الشحنة"))) index = i;
    });
    dateColumnIndexByTable.set(table, index);
    return index;
  }

  const getDateCell = (row) => {
    const table = row.closest("table");
    if (!table) return null;
    const index = getDateColumnIndex(table);
    if (index === -1) return null;
    return row.querySelectorAll("td")[index] || null;
  };

  function applySummaryButton(row) {
    const targetCell = getDateCell(row) || getPhoneCell(row);
    if (!targetCell || targetCell.querySelector(".mutabaa-summary-row-btn")) return;

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "mutabaa-summary-row-btn";
    btn.textContent = "ملخص";
    btn.style.cssText = [
      "display:block", "margin:4px auto 0", "padding:2px 8px", "font-size:11px", "line-height:1.6",
      "border-radius:4px", "border:1px solid #9ca3af", "background:#9ca3af", "color:#fff",
      "cursor:pointer", "white-space:nowrap",
    ].join(";");

    const box = renderRowSummaryBox(targetCell);
    btn.addEventListener("click", (ev) => {
      ev.stopPropagation(); ev.preventDefault();
      revealRowSummary(row, btn, box);
    });

    targetCell.appendChild(btn);
  }

  const applySummaryButtonsToVisibleRows = () =>
    document.querySelectorAll("tr[smartykeycolval]").forEach(applySummaryButton);

  // -----------------------------------------------------------------------
  // [PERF] Deadline countdown with AbortController
  // -----------------------------------------------------------------------
  const PROCESSING_WINDOW_MS = 60 * 60 * 1000;

  const isPlausibleDeadline = (ms) => {
    if (ms == null || isNaN(ms)) return false;
    return Math.abs(ms - Date.now()) <= 31 * 24 * 60 * 60 * 1000;
  };

  const isSaneActionTimestamp = (d) => {
    if (!d || isNaN(d.getTime())) return false;
    const now = Date.now();
    return d.getTime() >= now - 30 * 24 * 60 * 60 * 1000 && d.getTime() <= now + 24 * 60 * 60 * 1000;
  };

  function extractLastActionTimestamp(doc) {
    const table = doc.querySelector('table[id*="AuditTrailPopUp"]');
    if (!table) return null;
    const rows = table.querySelectorAll("tbody tr");
    if (!rows.length) return null;

    const lastRow = rows[rows.length - 1];
    const candidates = Array.from(lastRow.querySelectorAll('td[dir="ltr"]'))
      .map((td) => parseDateFlexible(td.textContent.trim()))
      .filter((d) => isSaneActionTimestamp(d));

    return candidates.length ? candidates[candidates.length - 1] : null;
  }

  async function fetchProcessingDeadline(orderId, signal) {
    try {
      const res = await fetch(
        `${location.origin}/myp/Mainctrl/cases/displaySingleCaseInfo?auditcaseid=${encodeURIComponent(orderId)}`,
        { credentials: "include", signal }
      );
      if (!res.ok) return;

      const doc = new DOMParser().parseFromString(await res.text(), "text/html");
      const ts = extractLastActionTimestamp(doc);

      // [PERF] Don't cache if row no longer relevant
      if (!ts) {
        deadlineCache.set(orderId, { deadline: null, fetchedAt: Date.now() });
        return;
      }

      deadlineCache.set(orderId, {
        deadline: ts.getTime() + PROCESSING_WINDOW_MS,
        fetchedAt: Date.now(),
      });
    } catch (e) {
      if (e.name !== "AbortError") console.error("[متابعة-process] fetchProcessingDeadline error:", e);
    }
  }

  function formatCountdown(msLeft) {
    const overdue = msLeft < 0;
    const abs = Math.abs(msLeft);
    const totalMin = Math.floor(abs / 60000);
    const hh = Math.floor(totalMin / 60);
    const mm = totalMin % 60;
    const ss = Math.floor((abs % 60000) / 1000);
    const pad = (n) => String(n).padStart(2, "0");
    const clock = hh > 0 ? `${pad(hh)}:${pad(mm)}:${pad(ss)}` : `${pad(mm)}:${pad(ss)}`;
    return overdue ? `متأخر بـ \u2066${clock}\u2069` : `\u2066${clock}\u2069`;
  }

  function styleDeadlineBadge(badge, msLeft) {
    if (msLeft < 0) {
      if (Math.abs(msLeft) / 60000 <= 2) {
        badge.style.background = "rgb(173, 96, 88)";
        badge.style.color = "#fff";
        badge.style.border = "1px solid rgb(150, 80, 73)";
      } else {
        badge.style.background = "#dc2626";
        badge.style.color = "#fff";
        badge.style.border = "1px solid #b91c1c";
      }
    } else if (msLeft < 10 * 60 * 1000) {
      badge.style.background = "#f59e0b";
      badge.style.color = "#111827";
      badge.style.border = "1px solid #d97706";
    } else {
      badge.style.background = "#dcfce7";
      badge.style.color = "#065f46";
      badge.style.border = "1px solid #16a34a";
    }
  }

  function renderTimerBadge(row, orderId) {
    const cell = getDateCell(row);
    if (!cell) return;

    let badge = cell.querySelector(".mutabaa-deadline-badge");
    if (!badge) {
      badge = document.createElement("div");
      badge.className = "mutabaa-deadline-badge";
      badge.dataset.orderId = orderId;
      badge.style.cssText = [
        "display:block", "box-sizing:border-box", "width:112px", "max-width:100%", "height:20px",
        "margin:4px auto 0", "padding:0 4px", "font-size:11px", "font-weight:bold",
        "font-variant-numeric:tabular-nums", "font-feature-settings:'tnum' 1", "line-height:18px",
        "border-radius:4px", "text-align:center", "white-space:nowrap", "overflow:hidden",
        "contain:layout paint size", "direction:ltr",
      ].join(";");
      cell.appendChild(badge);
    }
    badge.dataset.orderId = orderId;

    const entry = deadlineCache.get(orderId);
    if (!entry) {
      badge.textContent = "...جارٍ الحساب";
      badge.style.cssText += ";background:#e5e7eb;color:#374151;border:1px solid #d1d5db;";
      return;
    }
    if (entry.deadline == null || !isPlausibleDeadline(entry.deadline)) {
      badge.textContent = "غير معروف";
      badge.style.cssText += ";background:#e5e7eb;color:#6b7280;border:1px solid #d1d5db;";
      return;
    }

    const msLeft = entry.deadline - Date.now();
    badge.textContent = formatCountdown(msLeft);
    styleDeadlineBadge(badge, msLeft);
  }

  // [PERF] Throttle badge updates — only process visible badges
  let badgeUpdatePending = false;

  function applyTimerBadgesToVisibleRows() {
    if (badgeUpdatePending) return;
    badgeUpdatePending = true;

    requestAnimationFrame(() => {
      badgeUpdatePending = false;
      document.querySelectorAll("tr[smartykeycolval]").forEach((row) => {
        const orderId = getOrderId(row);
        if (!orderId) return;

        renderTimerBadge(row, orderId);

        const entry = deadlineCache.get(orderId);
        const stale = !entry || Date.now() - entry.fetchedAt > CONFIG.DEADLINE_CACHE_TTL_MS;

        if (stale && !pendingFetches.has(orderId)) {
          // [PERF] Create abort controller
          const controller = new AbortController();
          pendingFetches.set(orderId, controller);

          fetchProcessingDeadline(orderId, controller.signal).finally(() => {
            pendingFetches.delete(orderId);
            // [PERF] Only re-render if row still exists
            if (document.contains(row)) renderTimerBadge(row, orderId);
          });
        }
      });
    });
  }

  // [PERF] Module-level interval handles for cleanup
  let badgeTickIntervalHandle = null;
  let deadlineRefreshIntervalHandle = null;

  // [PERF] Use requestAnimationFrame-throttled tick instead of direct setInterval
  // This prevents layout thrashing when tab is visible but busy
  let lastTickTime = 0;

  badgeTickIntervalHandle = setInterval(() => {
    const now = Date.now();
    // Skip if less than 900ms since last tick (prevents drift accumulation)
    if (now - lastTickTime < 900) return;
    lastTickTime = now;

    document.querySelectorAll(".mutabaa-deadline-badge").forEach((badge) => {
      const orderId = badge.dataset.orderId;
      const entry = orderId && deadlineCache.get(orderId);
      if (!entry?.deadline || !isPlausibleDeadline(entry.deadline)) return;
      const msLeft = entry.deadline - Date.now();
      badge.textContent = formatCountdown(msLeft);
      styleDeadlineBadge(badge, msLeft);
    });
  }, 1000);

  deadlineRefreshIntervalHandle = setInterval(applyTimerBadgesToVisibleRows, CONFIG.DEADLINE_CACHE_TTL_MS);

  // -----------------------------------------------------------------------
  // Internal request notice (unchanged)
  // -----------------------------------------------------------------------
  const addressColumnIndexByTable = new WeakMap();
  const noticeColumnIndexByTable = new WeakMap();

  function findColumnIndex(table, cache, matches) {
    if (cache.has(table)) return cache.get(table);
    let index = -1;
    table.querySelectorAll("thead th, tr:first-child th, tr:first-child td").forEach((th, i) => {
      const clean = th.textContent.replace(/\s+/g, " ").trim();
      if (index === -1 && matches(clean)) index = i;
    });
    cache.set(table, index);
    return index;
  }

  const getAddressCell = (row) => {
    const table = row.closest("table");
    if (!table) return null;
    const index = findColumnIndex(table, addressColumnIndexByTable, (c) => normalizeAlif(c).includes("العنوان"));
    if (index === -1) return null;
    return row.querySelectorAll("td")[index] || null;
  };

  const getNoticeCell = (row) => {
    const table = row.closest("table");
    if (!table) return null;
    const index = findColumnIndex(table, noticeColumnIndexByTable, (c) => normalizeAlif(c).includes("شعار"));
    if (index === -1) return null;
    return row.querySelectorAll("td")[index] || null;
  };

  function applyInternalRequestNotice(row) {
    const addressCell = getAddressCell(row);
    const noticeCell = getNoticeCell(row);
    if (!addressCell || !noticeCell) return;

    const isInternal = isInternalAddress(normalizeAlif(addressCell.textContent.replace(/\s+/g, " ").trim()));

    let label = noticeCell.querySelector(".mutabaa-internal-request-label");
    if (!label) {
      label = document.createElement("div");
      label.className = "mutabaa-internal-request-label";
      label.style.cssText = [
        "display:block", "margin:4px auto 0", "padding:2px 8px", "font-size:11px",
        "font-weight:bold", "line-height:1.6", "border-radius:4px", "text-align:center",
        "white-space:nowrap", "width:fit-content",
      ].join(";");
      noticeCell.appendChild(label);
    }

    label.textContent = "طلب داخلي";
    if (isInternal) {
      label.style.cssText += ";display:block;border:1px solid #dc2626;background:#dc2626;color:#fff;";
    } else {
      label.style.display = "none";
    }
  }

  const applyInternalRequestNoticeToVisibleRows = () =>
    document.querySelectorAll("tr[smartykeycolval]").forEach(applyInternalRequestNotice);

  // -----------------------------------------------------------------------
  // [PERF] Optimized mutation handling with coalescing
  // -----------------------------------------------------------------------
  let mutationTimer = null;
  let pendingMutationWork = false;

  function scheduleRestore() {
    if (mutationTimer) return; // [PERF] Don't reset timer — let it fire

    mutationTimer = setTimeout(() => {
      mutationTimer = null;
      if (pendingMutationWork) return; // [PERF] Skip if already running

      pendingMutationWork = true;
      requestAnimationFrame(() => {
        pendingMutationWork = false;
        restoreVisibleRows();
        applySearchButtonsToVisibleRows();
        applySummaryButtonsToVisibleRows();
        applyInternalRequestNoticeToVisibleRows();
        applyTimerBadgesToVisibleRows();
      });
    }, CONFIG.MUTATION_DEBOUNCE_MS);
  }


  // -----------------------------------------------------------------------
  // Note editor: big floating box for the per-order note textarea
  // (q_rmk_smartyrow_N) + the employee's own saved quick phrases.
  // The page only enables that textarea when "اعادة توصيل" is chosen, so we
  // simply never open for a disabled one. Everything typed is mirrored into
  // the ORIGINAL textarea (with input/change events), so saving works as-is.
  // -----------------------------------------------------------------------
  const PHRASES_KEY = "mutabaa_note_phrases"; // not "procstate_" -> never purged
  const MAX_PHRASES = 30;
  const MAX_PHRASE_LEN = 200;
  const NOTE_SELECTOR = 'textarea[id^="q_rmk_smartyrow_"]';

  function initNoteEditor() {
    let phrases = [];
    let target = null; // original textarea currently being edited

    const css = (el, str) => { el.style.cssText = str; return el; };
    const mk = (tag, str, text) => {
      const el = document.createElement(tag);
      if (str) el.style.cssText = str;
      if (text != null) el.textContent = text;
      return el;
    };

    const panel = css(document.createElement("div"),
      "display:none;position:fixed;z-index:2147483000;width:340px;box-sizing:border-box;" +
      "background:#1f2937;color:#f3f4f6;border:1px solid #4b5563;border-radius:8px;" +
      "padding:8px;box-shadow:0 8px 24px rgba(0,0,0,.5);direction:rtl;text-align:right;" +
      "font-family:inherit;");
    panel.className = "mutabaa-note-panel";

    const box = css(document.createElement("textarea"),
      "display:block;width:100%;height:120px;box-sizing:border-box;resize:vertical;" +
      "font-size:15px;line-height:1.6;padding:8px;border-radius:6px;border:1px solid #6b7280;" +
      "background:#111827;color:#f9fafb;direction:rtl;");
    box.placeholder = "اكتب الملاحظة هنا...";

    const chips = css(document.createElement("div"),
      "display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;max-height:110px;overflow-y:auto;");

    const bar = css(document.createElement("div"),
      "display:flex;gap:6px;margin-top:8px;justify-content:space-between;");
    const btnStyle = (bg) =>
      "border:0;border-radius:6px;padding:5px 10px;font-size:12px;cursor:pointer;color:#fff;background:" + bg + ";";
    const saveBtn = mk("button", btnStyle("#2563eb"), "＋ حفظ النص كعبارة");
    const doneBtn = mk("button", btnStyle("#059669"), "تم");
    saveBtn.type = "button";
    doneBtn.type = "button";
    bar.append(saveBtn, doneBtn);
    panel.append(box, chips, bar);
    document.body.appendChild(panel);

    function renderChips() {
      chips.textContent = "";
      if (!phrases.length) {
        chips.appendChild(mk("div", "font-size:12px;color:#9ca3af;",
          "لا توجد عبارات محفوظة. اكتب نصاً ثم اضغط «حفظ النص كعبارة»."));
        return;
      }
      phrases.forEach((text, i) => {
        const chip = mk("span",
          "display:inline-flex;align-items:center;gap:4px;background:#374151;border:1px solid #4b5563;" +
          "border-radius:14px;padding:3px 4px 3px 10px;font-size:12px;cursor:pointer;max-width:100%;");
        const label = mk("span", "overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:220px;", text);
        label.title = text;
        label.dataset.action = "insert";
        label.dataset.index = String(i);
        const del = mk("span", "color:#f87171;font-weight:bold;padding:0 4px;cursor:pointer;", "×");
        del.title = "حذف العبارة";
        del.dataset.action = "delete";
        del.dataset.index = String(i);
        chip.append(label, del);
        chips.appendChild(chip);
      });
    }

    function loadPhrases() {
      chrome.storage.local.get([PHRASES_KEY], (res) => {
        const v = res && res[PHRASES_KEY];
        phrases = Array.isArray(v) ? v.filter((x) => typeof x === "string") : [];
        renderChips();
      });
    }
    function savePhrases() {
      chrome.storage.local.set({ [PHRASES_KEY]: phrases });
      renderChips();
    }

    // Push the box's text into the real textarea so the page/our saver see it.
    function syncToTarget(fireChange) {
      if (!target || !target.isConnected) return;
      target.value = box.value;
      target.dispatchEvent(new Event("input", { bubbles: true }));
      if (fireChange) target.dispatchEvent(new Event("change", { bubbles: true }));
    }

    function position() {
      if (!target || !target.isConnected) return;
      const r = target.getBoundingClientRect();
      const pw = panel.offsetWidth || 340;
      const ph = panel.offsetHeight || 240;
      let left = Math.min(Math.max(8, r.left), window.innerWidth - pw - 8);
      let top = r.bottom + 6;
      if (top + ph > window.innerHeight - 8) top = Math.max(8, r.top - ph - 6);
      panel.style.left = left + "px";
      panel.style.top = top + "px";
    }

    function open(ta) {
      if (target && target !== ta) close();
      target = ta;
      box.value = ta.value;
      panel.style.display = "block";
      renderChips();
      position();
      box.focus();
      box.setSelectionRange(box.value.length, box.value.length);
    }

    function close() {
      if (!target) return;
      syncToTarget(true);
      target = null;
      panel.style.display = "none";
    }

    // Open when the (enabled) note textarea is focused/clicked.
    document.addEventListener("focusin", (e) => {
      const ta = e.target;
      if (!(ta instanceof HTMLTextAreaElement) || !ta.matches(NOTE_SELECTOR)) return;
      if (ta.disabled || ta.readOnly) return;
      if (target === ta) return;
      open(ta);
    }, true);

    // Click outside both the panel and the real textarea -> close.
    document.addEventListener("mousedown", (e) => {
      if (!target) return;
      if (panel.contains(e.target) || e.target === target) return;
      close();
    }, true);

    document.addEventListener("keydown", (e) => {
      if (target && e.key === "Escape") close();
    }, true);

    window.addEventListener("scroll", () => target && position(), true);
    window.addEventListener("resize", () => target && position());

    box.addEventListener("input", () => syncToTarget(false));

    saveBtn.addEventListener("click", () => {
      const text = box.value.replace(/\s+/g, " ").trim().slice(0, MAX_PHRASE_LEN);
      if (!text || phrases.includes(text)) return;
      phrases.unshift(text);
      if (phrases.length > MAX_PHRASES) phrases.length = MAX_PHRASES;
      savePhrases();
      box.focus();
    });
    doneBtn.addEventListener("click", close);

    chips.addEventListener("click", (e) => {
      const el = e.target;
      if (!(el instanceof HTMLElement)) return;
      const i = Number(el.dataset.index);
      if (!Number.isInteger(i) || !phrases[i]) return;
      if (el.dataset.action === "delete") {
        phrases.splice(i, 1);
        savePhrases();
      } else if (el.dataset.action === "insert") {
        const start = box.selectionStart ?? box.value.length;
        const end = box.selectionEnd ?? start;
        const before = box.value.slice(0, start);
        const after = box.value.slice(end);
        const sep = before && !/\s$/.test(before) ? " " : "";
        const added = sep + phrases[i];
        box.value = before + added + after;
        const pos = (before + added).length;
        box.setSelectionRange(pos, pos);
        syncToTarget(false);
        close(); // phrase chosen -> push to the real textarea (fires change) and close
      }
    });

    loadPhrases();
  }


  // -----------------------------------------------------------------------
  // Track button: intercept the "تتبع" click (popitup(...)) and ask the TOP
  // window (track-modal-top.js) to show the order in a floating box above the
  // whole page. If nobody answers (e.g. the top window has no host script),
  // fall back to the original popup window so the button never breaks.
  // -----------------------------------------------------------------------
  function initTrackModal() {
    const TRACK_URL_PART = "displaySingleCaseInfo";
    const MSG_OPEN = "mutabaa-track-open";
    const MSG_ACK = "mutabaa-track-ack";

    function openInTop(url) {
      let acked = false;
      const onAck = (ev) => {
        if (ev.data && ev.data.type === MSG_ACK && ev.data.url === url) acked = true;
      };
      window.addEventListener("message", onAck);
      try { window.top.postMessage({ type: MSG_OPEN, url }, "*"); } catch (e) {}
      setTimeout(() => {
        window.removeEventListener("message", onAck);
        if (!acked) window.open(url, "", "width=1350,height=700,resizable=yes,scrollbars=yes");
      }, 400);
    }

    document.addEventListener("click", (e) => {
      const btn = e.target instanceof Element ? e.target.closest("button[onclick]") : null;
      if (!btn) return;
      const oc = btn.getAttribute("onclick") || "";
      if (!oc.includes(TRACK_URL_PART)) return;
      const m = oc.match(/popitup\(\s*['"]([^'"]+)['"]/);
      if (!m) return;
      let url;
      try { url = new URL(m[1], location.href).href; } catch (err) { return; }
      e.preventDefault();
      e.stopImmediatePropagation();
      openInTop(url);
    }, true);
  }

  // -----------------------------------------------------------------------
  // Init
  // -----------------------------------------------------------------------
  function init() {
    document.addEventListener("change", onFieldChange, true);
    initNoteEditor();
    initTrackModal();

    // Initial pass
    restoreVisibleRows();
    applySearchButtonsToVisibleRows();
    applySummaryButtonsToVisibleRows();
    applyInternalRequestNoticeToVisibleRows();
    applyTimerBadgesToVisibleRows();
    cleanupOldEntries();

    const cleanupInterval = setInterval(cleanupOldEntries, CONFIG.CLEANUP_INTERVAL_MS);

    // [PERF] Optimized mutation observer with node type filtering
    const OWN_MUTATION_SELECTOR = [
      ".mutabaa-saved-dot", ".mutabaa-saved-popover", ".mutabaa-search-btn",
      ".mutabaa-row-summary", ".mutabaa-summary-row-btn", ".mutabaa-deadline-badge",
      ".mutabaa-internal-request-label", ".mutabaa-note-panel", ".mutabaa-track-modal",
    ].join(", ");

    function isOwnMutation(mutation) {
      const target = mutation.target;
      if (target.nodeType === Node.TEXT_NODE) {
        return !!target.parentElement?.closest(OWN_MUTATION_SELECTOR);
      }
      if (target.nodeType === Node.ELEMENT_NODE) {
        return !!target.closest(OWN_MUTATION_SELECTOR);
      }
      return false;
    }

    const observer = new MutationObserver((mutations) => {
      // [PERF] Quick check: only schedule if we see non-own element additions
      const hasRelevantMutation = mutations.some((m) => {
        if (isOwnMutation(m)) return false;
        return m.addedNodes?.length > 0;
      });

      if (hasRelevantMutation) scheduleRestore();
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Watchdog
    const watchdog = setInterval(() => {
      if (isExtensionContextValid()) return;

      clearInterval(cleanupInterval);
      clearInterval(watchdog);
      clearInterval(badgeTickIntervalHandle);
      clearInterval(deadlineRefreshIntervalHandle);
      observer.disconnect();

      // [PERF] Cancel all pending fetches
      for (const controller of pendingFetches.values()) controller.abort();
      pendingFetches.clear();

      console.log("[متابعة-process] extension context invalidated — stopped background work.");
    }, 10000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();

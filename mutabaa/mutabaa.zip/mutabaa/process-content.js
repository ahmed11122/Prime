// process-content.js
// -----------------------------------------------------------------------
// Purpose: prevent lost work when the PC/tab crashes or reloads while an
// employee is mid-way through choosing a case's disposition
// (حالة صحيحة / تعذر توصيل + سبب الراجع / موجل + تاريخ / اعادة توصيل / لا يرد
// على المتابعة).
//
// Strategy:
//   1. Every relevant <select>/<input> lives inside a <tr smartykeycolval="...">.
//      That attribute (mirrored in a hidden input smarty_c_id_hidden_smartyrow_N)
//      is the REAL, stable order id — not the smartyrow_N index, which just
//      reflects render position and shifts as rows load/reorder.
//   2. On every "change" event inside such a row, we snapshot all of that
//      row's relevant fields into chrome.storage.local, keyed by the order id.
//   3. On load, and whenever new rows appear (the table is populated/refreshed
//      via AJAX), we look up each visible row's order id in storage and, if a
//      saved choice exists, show a small colored dot next to the row number
//      with a tooltip describing the last choice and how long ago it was made.
//   4. We deliberately do NOT auto-fill the dropdowns from the cache — only
//      show the reminder — so we never risk silently applying a stale choice
//      to what might now be a different case state. The employee decides.
//   5. Old entries are purged after MAX_AGE_MS so storage doesn't grow forever.
//
// This file is independent from content.js (order start/end + activity
// tracking) and touches a completely different part of the page.
// -----------------------------------------------------------------------

(function () {
  "use strict";

  console.log("[متابعة-process] process-content.js loaded on:", location.href);

  // ---------------------------------------------------------------------
  // Guard against "Extension context invalidated" errors. This happens
  // when the extension is reloaded/updated while this tab is still open:
  // this script keeps running as a stale ("zombie") instance, and every
  // chrome.storage.local call it makes throws instead of working. Left
  // unguarded, that throw fires on every timer tick (every 1s/20s/etc.)
  // forever, some inside Promise executors with no .catch — flooding the
  // console with "Uncaught (in promise) Error: Extension context
  // invalidated" and potentially disrupting whatever else is running on
  // the page. Wrapping get/set here (once) means every call site below
  // just quietly gets an empty result instead of throwing.
  function isExtensionContextValid() {
    try {
      return !!(chrome && chrome.runtime && chrome.runtime.id);
    } catch (e) {
      return false;
    }
  }
  if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
    const _rawGet = chrome.storage.local.get.bind(chrome.storage.local);
    const _rawSet = chrome.storage.local.set.bind(chrome.storage.local);
    const _rawRemove = chrome.storage.local.remove.bind(chrome.storage.local);
    chrome.storage.local.get = function (keys, cb) {
      if (!isExtensionContextValid()) {
        if (typeof cb === "function") setTimeout(() => cb({}), 0);
        return;
      }
      try {
        return _rawGet(keys, cb);
      } catch (e) {
        if (typeof cb === "function") setTimeout(() => cb({}), 0);
      }
    };
    chrome.storage.local.set = function (items, cb) {
      if (!isExtensionContextValid()) {
        if (typeof cb === "function") setTimeout(() => cb(), 0);
        return;
      }
      try {
        return _rawSet(items, cb);
      } catch (e) {
        if (typeof cb === "function") setTimeout(() => cb(), 0);
      }
    };
    chrome.storage.local.remove = function (keys, cb) {
      if (!isExtensionContextValid()) {
        if (typeof cb === "function") setTimeout(() => cb(), 0);
        return;
      }
      try {
        return _rawRemove(keys, cb);
      } catch (e) {
        if (typeof cb === "function") setTimeout(() => cb(), 0);
      }
    };
  }

  // Last-resort net. The per-call guards above only wrap the *synchronous*
  // call into chrome.storage.local — they can't catch an exception Chrome
  // throws from inside its own internal delivery of the callback when the
  // extension world gets torn down in the middle of an in-flight request.
  // That's a real, observed case: it surfaces as an uncaught error/rejection
  // whose stack points at unrelated lines in this file (wherever the JS
  // engine happened to be executing when the internal throw landed), even
  // though every chrome.storage call site here is already guarded. Since a
  // zombie instance can never recover short of a page reload anyway, just
  // swallow this one specific error wherever it surfaces instead of letting
  // it spam the console indefinitely.
  function isContextInvalidatedError(err) {
    const msg = err && (err.message || String(err));
    return typeof msg === "string" && msg.includes("Extension context invalidated");
  }
  window.addEventListener("error", (event) => {
    if (isContextInvalidatedError(event.error || event)) {
      event.preventDefault();
    }
  });
  window.addEventListener("unhandledrejection", (event) => {
    if (isContextInvalidatedError(event.reason)) {
      event.preventDefault();
    }
  });

  // This script's logic (save/restore badges + the search button) is only
  // relevant to the متابعة الحالات list pages (CasesFollowUp and its sibling
  // queue tabs — تحت التدقيق / تم تدقيقها / etc. live under these other
  // paths). Other pages on the same domain — like the "تتبع" popup
  // (displaySingleCaseInfo) — reuse similar smarty-templated table markup
  // (tr[smartykeycolval], td.cell), which would otherwise cause this script
  // to mistakenly inject badges/buttons there too. Bail out early everywhere
  // else.
  const ALLOWED_PATHS = [
    "/tickets/CasesFollowUp",
    "/tickets/under-revision-by-emp",
    "/tickets/Needs-revision-branch-customers",
  ];

  if (!ALLOWED_PATHS.some((p) => location.pathname.includes(p))) {
    console.log("[متابعة-process] skipped — path not in allowed list:", location.pathname);
    return;
  }

  // Extra explicit guard: displaySingleCaseInfo (تسلسل الأحداث / case history
  // popup) reuses the exact same tr[smartykeycolval] / td.cell markup as the
  // CasesFollowUp list, which is what was causing the buttons/badges to leak
  // onto it even though the path check above should already exclude it.
  if (location.pathname.includes("displaySingleCaseInfo")) {
    console.log("[متابعة-process] skipped — displaySingleCaseInfo explicitly blocked:", location.pathname);
    return;
  }

  console.log("[متابعة-process] path matched, initializing...");

  const STORAGE_PREFIX = "procstate_"; // chrome.storage.local key prefix
  const MAX_AGE_MS = 24 * 60 * 60 * 1000; // purge saved choices after 24h
  const CLEANUP_INTERVAL_MS = 60 * 60 * 1000; // re-check every hour
  const MUTATION_DEBOUNCE_MS = 300;

  // Any element whose id/name contains "_smartyrow_" is one of the fields we
  // care about (status select, return-reason select, postponed date input,
  // etc). We don't hardcode each one so new fields of the same pattern are
  // picked up automatically.
  const FIELD_ID_PATTERN = /_smartyrow_\d+/;


  // -----------------------------------------------------------------------
  // Helpers
  // -----------------------------------------------------------------------

  function log(...args) {
    // Flip to false once the timer-badge investigation is done.
    if (true) console.log("[متابعة-process]", ...args);
  }

  function getRow(el) {
    return el.closest("tr[smartykeycolval]");
  }

  function getOrderId(row) {
    return row && row.getAttribute("smartykeycolval");
  }

  // Turns "q_action_smartyrow_1_casesFollowUp" -> "q_action"
  // Turns "c_rtnreason_smartyrow_1" -> "c_rtnreason"
  function fieldBaseKey(idOrName) {
    return idOrName.replace(/_smartyrow_\d+.*/, "");
  }

  function readFieldValue(el) {
    if (el.tagName === "SELECT") {
      const opt = el.selectedOptions && el.selectedOptions[0];
      return {
        value: el.value,
        label: opt ? opt.textContent.trim() : el.value,
      };
    }
    // input / textarea / date fields
    return { value: el.value, label: el.value };
  }

  function storageKey(orderId) {
    return STORAGE_PREFIX + orderId;
  }

  // -----------------------------------------------------------------------
  // Saving
  // -----------------------------------------------------------------------

  function collectRowFields(row) {
    const fields = {};
    const els = row.querySelectorAll("select, input, textarea");
    els.forEach((el) => {
      const idOrName = el.id || el.name || "";
      if (!FIELD_ID_PATTERN.test(idOrName)) return;
      // Skip empty/placeholder selections so we don't overwrite a real saved
      // choice with a blank one if the row re-renders mid-edit.
      const { value, label } = readFieldValue(el);
      if (value === "" || value == null) return;
      fields[fieldBaseKey(idOrName)] = { value, label };
    });
    return fields;
  }

  function saveRowState(row) {
    const orderId = getOrderId(row);
    if (!orderId) return;

    const fields = collectRowFields(row);
    if (Object.keys(fields).length === 0) return;

    const record = { fields, ts: Date.now() };
    chrome.storage.local.set({ [storageKey(orderId)]: record }, () => {
      log("saved", orderId, record);
      applyBadge(row, record);
    });
  }

  function onFieldChange(e) {
    const el = e.target;
    if (!el || !(el.id || el.name)) return;
    const idOrName = el.id || el.name;
    if (!FIELD_ID_PATTERN.test(idOrName)) return;

    const row = getRow(el);
    if (!row) return;

    saveRowState(row);
  }

  // -----------------------------------------------------------------------
  // Restoring / badges
  // -----------------------------------------------------------------------

  function timeAgo(ts) {
    const diffMin = Math.round((Date.now() - ts) / 60000);
    if (diffMin < 1) return "الآن";
    if (diffMin < 60) return `قبل ${diffMin} دقيقة`;
    const diffH = Math.round(diffMin / 60);
    if (diffH < 24) return `قبل ${diffH} ساعة`;
    const diffD = Math.round(diffH / 24);
    return `قبل ${diffD} يوم`;
  }

  function buildTooltip(record) {
    const lines = Object.values(record.fields).map((f) => f.label);
    return `آخر اختيار محفوظ (${timeAgo(record.ts)}):\n` + lines.join("\n");
  }

  function applyBadge(row, record) {
    const cell = row.querySelector("td.cell");
    if (!cell) return;

    let dot = cell.querySelector(".mutabaa-saved-dot");
    if (!dot) {
      dot = document.createElement("span");
      dot.className = "mutabaa-saved-dot";
      dot.style.cssText = [
        "display:inline-block",
        "width:9px",
        "height:9px",
        "border-radius:50%",
        "background:#2ecc71",
        "margin-inline-start:6px",
        "vertical-align:middle",
        "cursor:pointer",
        "box-shadow:0 0 0 2px rgba(46,204,113,0.25)",
      ].join(";");
      cell.appendChild(dot);

      // Tap/click shows the detail as a lightweight native alert — simplest
      // and most reliable across the page's existing styles/z-index stack.
      dot.addEventListener("click", (ev) => {
        ev.stopPropagation();
        ev.preventDefault();
        alert(dot.title);
      });
    }
    dot.title = buildTooltip(record);
  }

  function removeBadge(row) {
    const dot = row.querySelector(".mutabaa-saved-dot");
    if (dot) dot.remove();
  }

  function restoreRow(row, cachedRecords) {
    const orderId = getOrderId(row);
    if (!orderId) return;
    const record = cachedRecords[storageKey(orderId)];
    if (record) {
      applyBadge(row, record);
    } else {
      removeBadge(row);
    }
  }

  function restoreVisibleRows() {
    const rows = Array.from(document.querySelectorAll("tr[smartykeycolval]"));
    if (rows.length === 0) return;

    const keys = rows
      .map((r) => getOrderId(r))
      .filter(Boolean)
      .map(storageKey);

    // Batch the read so 100+ concurrent orders cost one storage call, not one
    // call per row.
    chrome.storage.local.get(keys, (cachedRecords) => {
      rows.forEach((row) => restoreRow(row, cachedRecords));
    });
  }

  // -----------------------------------------------------------------------
  // Cleanup — drop entries older than MAX_AGE_MS
  // -----------------------------------------------------------------------

  function cleanupOldEntries() {
    // Also prune the in-memory deadlineCache/rowSummaryCache (and their
    // matching hide-timer map) for any order no longer present as a row on
    // the page. Neither of those Maps is ever otherwise trimmed — over a
    // full shift touching hundreds of distinct orders, they'd just grow for
    // as long as the tab stays open. Anything for an order that scrolls off
    // the visible pages gets refetched on demand if it reappears, so this
    // is safe to drop.
    const visibleOrderIds = new Set(
      Array.from(document.querySelectorAll("tr[smartykeycolval]"))
        .map(getOrderId)
        .filter(Boolean)
    );
    for (const orderId of deadlineCache.keys()) {
      if (!visibleOrderIds.has(orderId)) deadlineCache.delete(orderId);
    }
    for (const orderId of rowSummaryCache.keys()) {
      if (visibleOrderIds.has(orderId)) continue;
      rowSummaryCache.delete(orderId);
      const timer = rowSummaryHideTimers.get(orderId);
      if (timer) {
        clearTimeout(timer);
        rowSummaryHideTimers.delete(orderId);
      }
    }

    chrome.storage.local.get(null, (all) => {
      const now = Date.now();
      const toRemove = [];
      Object.keys(all).forEach((key) => {
        if (!key.startsWith(STORAGE_PREFIX)) return;
        const record = all[key];
        if (!record || !record.ts || now - record.ts > MAX_AGE_MS) {
          toRemove.push(key);
        }
      });
      if (toRemove.length > 0) {
        chrome.storage.local.remove(toRemove, () => {
          log("cleaned up", toRemove.length, "stale entries");
        });
      }
    });
  }

  // -----------------------------------------------------------------------
  // "بحث في النظام" button — extract the recipient phone number from the
  // row and open prime-iq.com's global search for it in a new tab.
  // -----------------------------------------------------------------------

  // Iraqi mobile numbers as they appear in this table: 07 followed by 9
  // digits, sometimes with a trailing separator like " , " after them.
  const PHONE_PATTERN = /07\d{9}/;

  // Path only — the origin is taken from the current page (location.origin)
  // so the search tab always shares the same host/cookies/session as the
  // page the employee is logged in on. A hardcoded host caused a login
  // loop on PCs that reach the system via a different address.
  const GLOBAL_SEARCH_PATH =
    "/myp/Mainctrl/cases/displayGlobalSearchResults?globalSerachParamter=";
  const SEARCH_TAB_NAME = "mutabaaGlobalSearchTab";

  function findPhoneInRow(row) {
    const phoneCell = getPhoneCell(row);
    if (!phoneCell) return null;
    const match = phoneCell.textContent.match(PHONE_PATTERN);
    return match ? match[0] : null;
  }

  // Cache the column index of "هاتف المستلم" per table, since re-deriving it
  // on every row would mean walking the thead repeatedly.
  const phoneColumnIndexByTable = new WeakMap();

  function getPhoneColumnIndex(table) {
    if (phoneColumnIndexByTable.has(table)) {
      return phoneColumnIndexByTable.get(table);
    }
    let index = -1;
    // Some renders of this table don't use a real <thead>, so also check the
    // first row's cells as a fallback.
    const headerCells = table.querySelectorAll(
      "thead th, tr:first-child th, tr:first-child td"
    );
    headerCells.forEach((th, i) => {
      const clean = th.textContent.replace(/\s+/g, " ").trim();
      if (index === -1 && clean.includes("هاتف المستلم")) {
        index = i;
      }
    });
    phoneColumnIndexByTable.set(table, index);
    return index;
  }

  function getPhoneCell(row) {
    const table = row.closest("table");
    if (!table) return null;
    const index = getPhoneColumnIndex(table);
    if (index !== -1) {
      const cells = row.querySelectorAll("td");
      if (cells[index]) return cells[index];
    }
    // Column header lookup failed (unexpected table layout) — as a last
    // resort, use the one cell in this row that actually contains a phone
    // number, rather than giving up or falling back to an unrelated cell
    // like td.cell.
    const cells = Array.from(row.querySelectorAll("td"));
    return cells.find((td) => PHONE_PATTERN.test(td.textContent)) || null;
  }

  function applySearchButton(row) {
    try {
      // Only ever anchor to the cell that actually contains a phone number.
      // Never fall back to td.cell or any other unrelated cell — that's what
      // previously let the button attach to the wrong place.
      const targetCell = getPhoneCell(row);
      if (!targetCell) return;
      if (targetCell.querySelector(".mutabaa-search-btn")) return; // already added

      const match = targetCell.textContent.match(PHONE_PATTERN);
      if (!match) return; // no real phone number here — don't add a button

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "mutabaa-search-btn";
    btn.textContent = "ابحث في النظام";
    btn.style.cssText = [
      "display:block",
      "margin:18px auto 0 auto",
      "padding:2px 8px",
      "font-size:11px",
      "line-height:1.6",
      "border-radius:4px",
      "border:1px solid #9ca3af",
      "background:#9ca3af",
      "color:#fff",
      "cursor:pointer",
      "white-space:nowrap",
    ].join(";");

    btn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      ev.preventDefault();
      const phone = findPhoneInRow(row);
      if (!phone) {
        alert("لم يتم العثور على رقم هاتف في هذا الصف.");
        return;
      }
      // Bug fix: "_blank" is the literal keyword, not a name — every click
      // opened a brand-new, unrelated tab on prime-iq.com. On a system that
      // only allows one active login at a time, each fresh tab's login was
      // kicking out whichever tab was logged in a moment ago (the first
      // tab, then that new tab, then the next one clicked...), which is why
      // it looped between logging in and logging back out. Using a fixed
      // window name makes every search reuse the SAME tab instead of
      // spawning a new one, so there's only ever one extra session fighting
      // for the login instead of a new one every click.
      // window.name survives navigation: if this tab was ever the search tab,
      // window.open(..., name) would target ITSELF and search in the same tab.
      if (window.name === SEARCH_TAB_NAME) window.name = "";
      window.open(
        location.origin + GLOBAL_SEARCH_PATH + encodeURIComponent(phone),
        SEARCH_TAB_NAME
      );
    });

    targetCell.appendChild(btn);
    } catch (e) {
      console.error("[متابعة-process] applySearchButton error:", e);
    }
  }

  function applySearchButtonsToVisibleRows() {
    document
      .querySelectorAll("tr[smartykeycolval]")
      .forEach((row) => applySearchButton(row));
  }

  // -----------------------------------------------------------------------
  // Per-row case summary (نوع البضاعة / مندوب التوصيل / عمر الطلب) — the
  // same three facts content-summary.js shows on the تتبع popup, but pulled
  // in the background for every row on the list itself, right under the
  // "ابحث في النظام" button, so nobody has to open تتبع to see them.
  //
  // The popup page (displaySingleCaseInfo) is same-origin, so we can fetch
  // its HTML directly with the row's orderId as auditcaseid and parse the
  // same smarty_singledispalycol containers out of it.
  // -----------------------------------------------------------------------

  const SUMMARY_FIELD_SUFFIXES = {
    itemType: "itemsdetails",
    agentName: "dlvagentname",
    createdAt: "c_createddt",
    remarks: "c_rmk",
  };

  const DETAILS_LABELS = new Set(["تفاصيل", "التفاصيل"]);

  // orderId -> "pending" | { text } | "error" — avoids re-fetching the same
  // case every time the AJAX-rebuilt table triggers our mutation observer.
  const rowSummaryCache = new Map();

  function getFieldValueFromDoc(doc, suffix) {
    const container = doc.querySelector(
      `[smarty_singledispalycol="smarty_singledispalycol_${suffix}_coldiv"]`
    );
    if (!container) return null;

    const valueCell = container.querySelector(".col-sm-7");
    if (valueCell) {
      const text = valueCell.textContent.replace(/\s+/g, " ").trim();
      return text || null;
    }

    const clone = container.cloneNode(true);
    clone.querySelectorAll("h6").forEach((h) => h.remove());
    const text = clone.textContent.replace(/\s+/g, " ").trim();
    return text || null;
  }

  function isDetailsButtonCell(valueCell) {
    const cellText = valueCell.textContent.replace(/\s+/g, " ").trim();
    return DETAILS_LABELS.has(cellText);
  }

  async function fetchItemTypesFromDetailsPage(auditCaseId) {
    try {
      const url = `${location.origin}/myp/Mainctrl/cases/itemDetails?auditcaseid=${encodeURIComponent(
        auditCaseId
      )}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) return null;

      const html = await res.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const table = doc.querySelector("table");
      if (!table) return null;

      const headerCells = table.querySelectorAll("thead th");
      let typeIndex = -1;
      headerCells.forEach((th, i) => {
        if (typeIndex === -1 && th.textContent.includes("نوع البضاعة")) {
          typeIndex = i;
        }
      });
      if (typeIndex === -1) return null;

      const rows = table.querySelectorAll("tbody tr");
      const counts = new Map();
      rows.forEach((row) => {
        const cells = row.querySelectorAll("td");
        const val = cells[typeIndex]
          ? cells[typeIndex].textContent.replace(/\s+/g, " ").trim()
          : "";
        if (!val) return;
        counts.set(val, (counts.get(val) || 0) + 1);
      });
      if (counts.size === 0) return null;

      return Array.from(counts.entries())
        .map(([type, count]) => (count > 1 ? `${type} (${count})` : type))
        .join("، ");
    } catch (e) {
      console.error("[متابعة-process] fetchItemTypesFromDetailsPage error:", e);
      return null;
    }
  }

  async function resolveItemTypeFromDoc(doc, auditCaseId) {
    const container = doc.querySelector(
      `[smarty_singledispalycol="smarty_singledispalycol_${SUMMARY_FIELD_SUFFIXES.itemType}_coldiv"]`
    );
    if (!container) return null;

    const valueCell = container.querySelector(".col-sm-7");
    if (!valueCell) return null;

    if (!isDetailsButtonCell(valueCell)) {
      const text = valueCell.textContent.replace(/\s+/g, " ").trim();
      return text || null;
    }

    return await fetchItemTypesFromDetailsPage(auditCaseId);
  }

  function parseDateFlexible(raw) {
    if (!raw) return null;

    let d = new Date(raw.replace(" ", "T"));
    if (!isNaN(d.getTime())) return d;

    const m = raw.match(
      /(\d{1,2})\/(\d{1,2})\/(\d{4})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?/
    );
    if (m) {
      const [, mo, day, yr, hh, mm, ss] = m;
      d = new Date(
        Number(yr),
        Number(mo) - 1,
        Number(day),
        Number(hh),
        Number(mm),
        Number(ss || 0)
      );
      if (!isNaN(d.getTime())) return d;
    }

    return null;
  }

  function formatAge(createdDate) {
    if (!createdDate) return null;

    const diffMs = Date.now() - createdDate.getTime();
    if (diffMs < 0) return null;

    const minutes = Math.floor(diffMs / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days >= 1) {
      const remHours = hours % 24;
      return remHours > 0 ? `${days} يوم و ${remHours} ساعة` : `${days} يوم`;
    }
    if (hours >= 1) {
      return `${hours} ساعة`;
    }
    return `${minutes} دقيقة`;
  }

  // The real per-action case history is table[id*="AuditTrailPopUp"] — one
  // row per status change, in chronological order (each row's own two
  // timestamp columns confirm this). Its rows come from two different
  // sources though: staff actions (employee cell prefixed "موظف:") and the
  // delivery agent's own automatic log entries (prefixed "مندوب:" /
  // "متنوب:"). We only want the LAST *staff* entry — a later مندوب-logged
  // row would otherwise look "more recent" and wrongly overwrite whose
  // decision this actually was.
  //
  // Column order isn't labeled in the markup, but empirically: [index, date,
  // status, outcome, location, employee, date2, ...]. We locate the employee
  // cell by content ("موظف") rather than a fixed index, then read the
  // outcome as the cell two positions before it (status/disposition sits
  // right before location, which sits right before the employee cell).
  function extractLastProcessedBy(doc) {
    const table = doc.querySelector('table[id*="AuditTrailPopUp"]');
    if (!table) return null;

    const rows = Array.from(table.querySelectorAll("tbody tr"));
    if (!rows.length) return null;

    for (let i = rows.length - 1; i >= 0; i--) {
      const cells = Array.from(rows[i].querySelectorAll("td"));
      const empIndex = cells.findIndex((td) =>
        /موظف\s*:?/.test(td.textContent)
      );
      if (empIndex === -1) continue; // this row was logged by المندوب, not staff — skip it

      const empText = cells[empIndex].textContent.replace(/\s+/g, " ").trim();
      const nameMatch = empText.match(/موظف\s*:?\s*(.+)/);
      const name = (nameMatch ? nameMatch[1] : empText).trim();

      const outcomeCell = cells[empIndex - 2];
      const outcome = outcomeCell
        ? outcomeCell.textContent.replace(/\s+/g, " ").trim()
        : null;

      return { name: name || null, outcome: outcome || null };
    }

    return null;
  }

  async function fetchCaseSummary(orderId) {
    try {
      const url = `${location.origin}/myp/Mainctrl/cases/displaySingleCaseInfo?auditcaseid=${encodeURIComponent(
        orderId
      )}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) return null;

      const html = await res.text();
      const doc = new DOMParser().parseFromString(html, "text/html");

      const itemType = await resolveItemTypeFromDoc(doc, orderId);
      const agentName = getFieldValueFromDoc(doc, SUMMARY_FIELD_SUFFIXES.agentName);
      const createdRaw = getFieldValueFromDoc(doc, SUMMARY_FIELD_SUFFIXES.createdAt);
      const age = formatAge(parseDateFlexible(createdRaw));
      const remarks = getFieldValueFromDoc(doc, SUMMARY_FIELD_SUFFIXES.remarks);
      const lastProcessed = extractLastProcessedBy(doc);

      return {
        itemType: itemType || "غير متوفر",
        agentName: agentName || "غير متوفر",
        age: age || (createdRaw ? `${createdRaw} (تعذر حساب العمر)` : "غير متوفر"),
        remarks: remarks || "غير متوفر",
        lastProcessedByName: (lastProcessed && lastProcessed.name) || "غير متوفر",
        lastProcessedOutcome: (lastProcessed && lastProcessed.outcome) || "غير متوفر",
      };
    } catch (e) {
      console.error("[متابعة-process] fetchCaseSummary error:", e);
      return null;
    }
  }

  function renderRowSummaryBox(targetCell) {
    let box = targetCell.querySelector(".mutabaa-row-summary");
    if (!box) {
      box = document.createElement("div");
      box.className = "mutabaa-row-summary";
      box.style.cssText = [
        "display:none",
        "margin-top:4px",
        "padding:4px 6px",
        "font-size:10px",
        "line-height:1.5",
        "text-align:right",
        "color:#1f2937",
        "background:#f3f4f6",
        "border:1px solid #e5e7eb",
        "border-radius:4px",
        "max-width:220px",
      ].join(";");
      targetCell.appendChild(box);
    }
    return box;
  }

  // Each summary field, in display order: [label, key in the summary object, background color].
  const SUMMARY_ROWS = [
    ["نوع البضاعة", "itemType", "#dbeafe"],
    ["مندوب التوصيل", "agentName", "#dcfce7"],
    ["عمر الطلب", "age", "#fef9c3"],
    ["ملاحظات", "remarks", "#fee2e2"],
    ["آخر موظف", "lastProcessedByName", "#ede9fe"],
    ["نتيجة معالجته", "lastProcessedOutcome", "#ffedd5"],
  ];

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function buildSummaryHtml(summary) {
    return SUMMARY_ROWS.map(([label, key, bg]) => {
      return (
        `<div style="display:flex;justify-content:space-between;gap:6px;padding:2px 4px;margin-bottom:2px;border-radius:3px;background:${bg};">` +
        `<span style="color:#4b5563;white-space:nowrap;">${escapeHtml(label)}</span>` +
        `<span style="font-weight:bold;color:#111827;text-align:left;">${escapeHtml(summary[key])}</span>` +
        `</div>`
      );
    }).join("");
  }

  // How long the fetched details stay visible before the row reverts back to
  // showing the ملخص button. Fetch time itself doesn't count against this —
  // the countdown starts only once the text is actually on screen.
  const SUMMARY_DISPLAY_MS = 10000;

  const rowSummaryHideTimers = new Map(); // orderId -> timeout handle

  async function revealRowSummary(row, btn, box) {
    const orderId = getOrderId(row);
    if (!orderId) return;

    const existingTimer = rowSummaryHideTimers.get(orderId);
    if (existingTimer) clearTimeout(existingTimer);

    btn.style.display = "none";
    box.style.display = "block";

    const cached = rowSummaryCache.get(orderId);

    let html;
    if (cached && cached !== "pending" && cached !== "error") {
      html = cached.html;
    } else {
      box.textContent = "جارٍ التحميل...";
      const summary = await fetchCaseSummary(orderId);
      if (!summary) {
        rowSummaryCache.set(orderId, "error");
        html = "تعذر جلب التفاصيل";
      } else {
        html = buildSummaryHtml(summary);
        rowSummaryCache.set(orderId, { html });
      }
    }

    box.innerHTML = html;

    const timer = setTimeout(() => {
      box.style.display = "none";
      btn.style.display = "block";
      rowSummaryHideTimers.delete(orderId);
    }, SUMMARY_DISPLAY_MS);
    rowSummaryHideTimers.set(orderId, timer);
  }

  // Cache the column index of "تاريخ الشحنة" per table, same approach as
  // getPhoneColumnIndex — the ملخص button now lives here instead of next to
  // the phone/search button, so it needs its own column lookup.
  const dateColumnIndexByTable = new WeakMap();

  function getDateColumnIndex(table) {
    if (dateColumnIndexByTable.has(table)) {
      return dateColumnIndexByTable.get(table);
    }
    let index = -1;
    const headerCells = table.querySelectorAll(
      "thead th, tr:first-child th, tr:first-child td"
    );
    headerCells.forEach((th, i) => {
      const clean = th.textContent.replace(/\s+/g, " ").trim();
      if (index === -1 && (clean.includes("تاريخ الشحنه") || clean.includes("تاريخ الشحنة"))) {
        index = i;
      }
    });
    dateColumnIndexByTable.set(table, index);
    return index;
  }

  function getDateCell(row) {
    const table = row.closest("table");
    if (!table) return null;
    const index = getDateColumnIndex(table);
    if (index === -1) return null;
    const cells = row.querySelectorAll("td");
    return cells[index] || null;
  }

  function applySummaryButton(row) {
    // Sits under تاريخ الشحنة now, not next to the phone/search button —
    // falls back to the phone cell only if this row's table has no
    // recognizable تاريخ الشحنة column, so the button never just disappears.
    const targetCell = getDateCell(row) || getPhoneCell(row);
    if (!targetCell) return;
    if (targetCell.querySelector(".mutabaa-summary-row-btn")) return; // already added

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "mutabaa-summary-row-btn";
    btn.textContent = "ملخص";
    btn.style.cssText = [
      "display:block",
      "margin:4px auto 0 auto",
      "padding:2px 8px",
      "font-size:11px",
      "line-height:1.6",
      "border-radius:4px",
      "border:1px solid #9ca3af",
      "background:#9ca3af",
      "color:#fff",
      "cursor:pointer",
      "white-space:nowrap",
    ].join(";");

    const box = renderRowSummaryBox(targetCell);

    btn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      ev.preventDefault();
      revealRowSummary(row, btn, box);
    });

    targetCell.appendChild(btn);
  }

  function applySummaryButtonsToVisibleRows() {
    document.querySelectorAll("tr[smartykeycolval]").forEach((row) => {
      applySummaryButton(row);
    });
  }

  // -----------------------------------------------------------------------
  // Processing deadline countdown — مهلة معالجة الطلب (ساعة واحدة تبدأ من
  // آخر حدث مسجل في مسار الطلب، أي لحظة استلام/إرسال المندوب الأخيرة).
  // Shown as a small, always-visible, live-ticking badge under تاريخ
  // الشحنة so the employee sees at a glance how much time is left before
  // the order goes "متأخر", with no click needed (unlike ملخص above).
  // -----------------------------------------------------------------------

  const PROCESSING_WINDOW_MS = 60 * 60 * 1000; // 1 ساعة
  // Re-check the source page after this long so a newer مندوب action
  // (which restarts the clock) is picked up without a full page reload.
  const DEADLINE_CACHE_TTL_MS = 3 * 60 * 1000;

  const deadlineCache = new Map(); // orderId -> { deadline: number(ms), fetchedAt: number }
  const deadlinePending = new Set(); // orderId currently being fetched

  // Belt-and-suspenders check applied again right before we render a
  // countdown, independent of whatever validated the timestamp it was
  // built from. A deadline is just "some action time + 1h", so it should
  // never be wildly far from now — if it is, something upstream produced
  // garbage and we show "غير معروف" instead of a multi-year countdown.
  function isPlausibleDeadline(deadlineMs) {
    if (deadlineMs == null || isNaN(deadlineMs)) return false;
    const now = Date.now();
    const THIRTY_ONE_DAYS_MS = 31 * 24 * 60 * 60 * 1000;
    return Math.abs(deadlineMs - now) <= THIRTY_ONE_DAYS_MS;
  }

  // Reject a parsed timestamp that's clearly not real (corrupted markup,
  // wrong column picked, etc.) rather than silently turning it into a
  // nonsense multi-thousand-hour countdown. Anything further than ~30 days
  // in the past or 1 day in the future isn't a plausible مندوب action time
  // for this feature's purpose.
  function isSaneActionTimestamp(d) {
    if (!d || isNaN(d.getTime())) return false;
    const now = Date.now();
    const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;
    const ONE_DAY_MS = 24 * 60 * 60 * 1000;
    return d.getTime() >= now - THIRTY_DAYS_MS && d.getTime() <= now + ONE_DAY_MS;
  }

  // The audit table's LAST <tr> is the order's current step, whoever
  // logged it (موظف or مندوب) — its own trailing date column is when that
  // step started, i.e. the clock we're counting an hour from. Each row
  // has two ltr-dated columns (see extractLastProcessedBy note above);
  // we take the LAST sane one, since that's the timestamp of the step's
  // own end/transition point (e.g. the "09/26/2026 20:16:20" column, not
  // the "19:55:18" one before it) — skipping over anything that parses
  // to a clearly bogus date instead of trusting it blindly.
  function extractLastActionTimestamp(doc) {
    const table = doc.querySelector('table[id*="AuditTrailPopUp"]');
    if (!table) return null;

    const rows = table.querySelectorAll("tbody tr");
    if (!rows.length) return null;

    const lastRow = rows[rows.length - 1];
    const rawTexts = Array.from(lastRow.querySelectorAll('td[dir="ltr"]')).map(
      (td) => td.textContent.trim()
    );
    const parsed = rawTexts.map((raw) => ({ raw, d: parseDateFlexible(raw) }));
    // TEMP DIAGNOSTIC (see log() above) — shows exactly what raw text each
    // td[dir=ltr] in the last audit row contained, what it parsed to, and
    // whether it passed the 30-day sanity window. If a bogus decades-old
    // value is getting through, this line will show it and the raw string
    // it came from.
    log(
      "extractLastActionTimestamp candidates:",
      parsed.map((p) => ({
        raw: p.raw,
        parsedISO: p.d && !isNaN(p.d.getTime()) ? p.d.toISOString() : null,
        sane: isSaneActionTimestamp(p.d),
      }))
    );
    const candidates = parsed.map((p) => p.d).filter((d) => isSaneActionTimestamp(d));

    if (!candidates.length) return null;

    return candidates[candidates.length - 1];
  }

  async function fetchProcessingDeadline(orderId) {
    if (deadlinePending.has(orderId)) return;
    deadlinePending.add(orderId);
    try {
      const url = `${location.origin}/myp/Mainctrl/cases/displaySingleCaseInfo?auditcaseid=${encodeURIComponent(
        orderId
      )}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) return;

      const html = await res.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const ts = extractLastActionTimestamp(doc);
      if (!ts) {
        // No usable timestamp on this order's audit trail — remember that
        // (with a timestamp) so we back off for a full TTL instead of
        // refetching on every table refresh.
        deadlineCache.set(orderId, { deadline: null, fetchedAt: Date.now() });
        return;
      }

      deadlineCache.set(orderId, {
        deadline: ts.getTime() + PROCESSING_WINDOW_MS,
        fetchedAt: Date.now(),
      });
    } catch (e) {
      console.error("[متابعة-process] fetchProcessingDeadline error:", e);
    } finally {
      deadlinePending.delete(orderId);
    }
  }

  function formatCountdown(msLeft) {
    const overdue = msLeft < 0;
    const abs = Math.abs(msLeft);
    const totalMin = Math.floor(abs / 60000);
    const hh = Math.floor(totalMin / 60);
    const mm = totalMin % 60;
    const ss = Math.floor((abs % 60000) / 1000);
    const pad = (n) => String(n).padStart(2, "0");
    const clock =
      hh > 0 ? `${pad(hh)}:${pad(mm)}:${pad(ss)}` : `${pad(mm)}:${pad(ss)}`;
    // Wrap the LTR clock digits in Unicode isolate marks (U+2066/U+2069) so
    // the bidi algorithm can't reorder its digit groups when it's embedded
    // right after Arabic text in an RTL page — without this, an overdue
    // badge like "متأخر بـ 05:12:34" could render with the number's parts
    // visually scrambled.
    const isolatedClock = `\u2066${clock}\u2069`;
    return overdue ? `متأخر بـ ${isolatedClock}` : isolatedClock;
  }

  function styleDeadlineBadge(badge, msLeft) {
    if (msLeft < 0) {
      const overdueMin = Math.abs(msLeft) / 60000;
      if (overdueMin <= 2) {
        // Just tipped over — a softer warning tone before it escalates to
        // full red, so the employee notices without it looking alarming
        // for a 1-2 minute slip.
        badge.style.background = "rgb(173, 96, 88)";
        badge.style.color = "#fff";
        badge.style.border = "1px solid rgb(150, 80, 73)";
      } else {
        badge.style.background = "#dc2626";
        badge.style.color = "#fff";
        badge.style.border = "1px solid #b91c1c";
      }
    } else if (msLeft < 10 * 60 * 1000) {
      badge.style.background = "#f59e0b";
      badge.style.color = "#111827";
      badge.style.border = "1px solid #d97706";
    } else {
      badge.style.background = "#dcfce7";
      badge.style.color = "#065f46";
      badge.style.border = "1px solid #16a34a";
    }
  }

  function renderTimerBadge(row, orderId) {
    const cell = getDateCell(row);
    if (!cell) return;

    let badge = cell.querySelector(".mutabaa-deadline-badge");
    if (!badge) {
      badge = document.createElement("div");
      badge.className = "mutabaa-deadline-badge";
      badge.dataset.orderId = orderId;
      // FIXED size on purpose. Every one of the badge's dimensions used to
      // depend on its text (width:fit-content, height from line-height), and
      // the text changes every second: digits have different widths in a
      // proportional font ("23:21" vs "23:19"), and the overdue text
      // ("متأخر 04:24:25") is wider than the on-time text ("23:39"). The table
      // uses auto column layout, so each width change resized the date column
      // and re-flowed the whole table sideways — that's the whole page
      // (and its border lines) "moving" with the timer. With a fixed box +
      // equal-width digits + containment, no text change can alter layout.
      badge.style.cssText = [
        "display:block",
        "box-sizing:border-box",
        "width:112px",
        "max-width:100%",
        "height:20px",
        "margin:4px auto 0 auto",
        "padding:0 4px",
        "font-size:11px",
        "font-weight:bold",
        "font-variant-numeric:tabular-nums",
        "font-feature-settings:'tnum' 1",
        "line-height:18px",
        "border-radius:4px",
        "text-align:center",
        "white-space:nowrap",
        "overflow:hidden",
        "contain:layout paint size",
        "direction:ltr",
      ].join(";");
      cell.appendChild(badge);
    }
    badge.dataset.orderId = orderId; // keep in sync if row/order changes under the same cell

    const entry = deadlineCache.get(orderId);
    if (!entry) {
      badge.textContent = "...جارٍ الحساب";
      badge.style.background = "#e5e7eb";
      badge.style.color = "#374151";
      badge.style.border = "1px solid #d1d5db";
      return;
    }
    if (entry.deadline == null || !isPlausibleDeadline(entry.deadline)) {
      if (entry.deadline != null) {
        log(
          "rejecting implausible deadline at render time for order",
          orderId,
          new Date(entry.deadline).toISOString()
        );
      }
      badge.textContent = "غير معروف";
      badge.style.background = "#e5e7eb";
      badge.style.color = "#6b7280";
      badge.style.border = "1px solid #d1d5db";
      return;
    }

    const msLeft = entry.deadline - Date.now();
    badge.textContent = formatCountdown(msLeft);
    styleDeadlineBadge(badge, msLeft);
  }

  function applyTimerBadgesToVisibleRows() {
    document.querySelectorAll("tr[smartykeycolval]").forEach((row) => {
      const orderId = getOrderId(row);
      if (!orderId) return;

      renderTimerBadge(row, orderId);

      const entry = deadlineCache.get(orderId);
      const stale =
        !entry || Date.now() - entry.fetchedAt > DEADLINE_CACHE_TTL_MS;
      if (stale && !deadlinePending.has(orderId)) {
        fetchProcessingDeadline(orderId).then(() =>
          renderTimerBadge(row, orderId)
        );
      }
    });
  }

  // Handles for the two intervals below, captured here (module scope) so the
  // watchdog in init() can clear them once the extension is invalidated.
  // Previously these setInterval calls stored their handle nowhere, so the
  // watchdog — which only knew about cleanupInterval/observer/itself — could
  // never stop them. That meant a zombie tab (extension reloaded, this
  // script orphaned) kept running BOTH of these forever for as long as the
  // tab stayed open: a full-document badge query every second, plus a real
  // network fetch per stale order every DEADLINE_CACHE_TTL_MS (3 min) — with
  // no way to ever turn off short of closing the tab. Left running across a
  // whole workday with several tabs open, that adds up to real, needless
  // CPU and network use.
  let badgeTickIntervalHandle = null;
  let deadlineRefreshIntervalHandle = null;

  // Ticks every visible badge every second from the cached deadline —
  // no network calls here, just re-reading Date.now() against the cache
  // set by applyTimerBadgesToVisibleRows/fetchProcessingDeadline.
  badgeTickIntervalHandle = setInterval(() => {
    document.querySelectorAll(".mutabaa-deadline-badge").forEach((badge) => {
      const orderId = badge.dataset.orderId;
      const entry = orderId && deadlineCache.get(orderId);
      if (!entry || entry.deadline == null || !isPlausibleDeadline(entry.deadline)) return;
      const msLeft = entry.deadline - Date.now();
      badge.textContent = formatCountdown(msLeft);
      styleDeadlineBadge(badge, msLeft);
    });
  }, 1000);

  // Also re-check visible rows on the same cadence as the cache TTL, in
  // case the tab sits idle on an unchanged table (no mutations to trigger
  // scheduleRestore) for longer than that.
  deadlineRefreshIntervalHandle = setInterval(applyTimerBadgesToVisibleRows, DEADLINE_CACHE_TTL_MS);

  // -----------------------------------------------------------------------
  // "طلب داخلي" note — shown under اشعار المندوب, driven purely by whichever
  // neighborhood appears in this row's العنوان cell. Only these five
  // neighborhoods count as "internal"; everything else gets no text.
  // -----------------------------------------------------------------------

  const INTERNAL_REQUEST_NEIGHBORHOODS = [
    "حي العامل",
    "العامرية",
    "المحمودية",
    "ابو غريب",
    "اليرموك",
    "حي العدل",
    "حي الجامعة",
    "حي القادسية",
    "القادسية",
    "السيدية",
    "نفق الشرطة",
    "الحارثية",
  ];

  // Some neighborhood names above are substrings of a DIFFERENT, non-internal
  // area's full name (e.g. "كفاءات / السيدية" contains "السيدية" as text,
  // but the address is actually في الكفاءات, not internal). Each entry says:
  // if the address contains `ifAddressContains`, don't let `blockNeighborhood`
  // count as a match on its own.
  const INTERNAL_MATCH_EXCLUSIONS = [
    { ifAddressContains: "كفاءات", blockNeighborhood: "السيدية" },
  ];

  // ا / أ / إ / آ all render as plain "ا" once typed casually or copied from
  // different sources, so a literal .includes() on header/cell text is
  // fragile — normalize them all to ا before comparing (this is what broke
  // اشعار detection above).
  function normalizeAlif(str) {
    return str.replace(/[أإآ]/g, "ا");
  }

  // Cache column indices per table, same pattern as getDateColumnIndex /
  // getPhoneColumnIndex above.
  const addressColumnIndexByTable = new WeakMap();
  const noticeColumnIndexByTable = new WeakMap();

  function findColumnIndex(table, cache, matches) {
    if (cache.has(table)) return cache.get(table);
    let index = -1;
    const headerCells = table.querySelectorAll(
      "thead th, tr:first-child th, tr:first-child td"
    );
    headerCells.forEach((th, i) => {
      const clean = th.textContent.replace(/\s+/g, " ").trim();
      if (index === -1 && matches(clean)) index = i;
    });
    cache.set(table, index);
    return index;
  }

  function getAddressCell(row) {
    const table = row.closest("table");
    if (!table) return null;
    const index = findColumnIndex(table, addressColumnIndexByTable, (clean) =>
      normalizeAlif(clean).includes("العنوان")
    );
    if (index === -1) return null;
    const cells = row.querySelectorAll("td");
    return cells[index] || null;
  }

  function getNoticeCell(row) {
    const table = row.closest("table");
    if (!table) return null;
    // Header text varies not just in wording but in the alif form itself
    // (ا vs أ vs إ — e.g. "اشعار" vs "إشعار"), which silently breaks a
    // literal .includes() match. Normalize alif variants before comparing
    // so "شعار" (present in all of them) reliably matches, and also match
    // on "المندوب" as a second signal in case the root word itself differs.
    const index = findColumnIndex(table, noticeColumnIndexByTable, (clean) =>
      normalizeAlif(clean).includes("شعار")
    );
    if (index === -1) return null;
    const cells = row.querySelectorAll("td");
    return cells[index] || null;
  }

  function applyInternalRequestNotice(row) {
    const addressCell = getAddressCell(row);
    const noticeCell = getNoticeCell(row);
    if (!addressCell || !noticeCell) return;

    const addressText = normalizeAlif(
      addressCell.textContent.replace(/\s+/g, " ").trim()
    );
    // These neighborhoods are Baghdad-specific — matching the neighborhood
    // name alone isn't enough, since the same neighborhood name can turn up
    // in an address that is actually in a different city (e.g. "موصل - حي
    // الجامعة" vs "بغداد - حي الجامعة"). Require بغداد to appear too.
    const isBaghdad = addressText.includes(normalizeAlif("بغداد"));
    const isInternal =
      isBaghdad &&
      INTERNAL_REQUEST_NEIGHBORHOODS.some((n) => {
        if (!addressText.includes(normalizeAlif(n))) return false;
        // Reject this match if an exclusion rule says the address actually
        // belongs to a different (non-internal) area.
        const blocked = INTERNAL_MATCH_EXCLUSIONS.some(
          (ex) =>
            ex.blockNeighborhood === n &&
            addressText.includes(normalizeAlif(ex.ifAddressContains))
        );
        return !blocked;
      });

    let label = noticeCell.querySelector(".mutabaa-internal-request-label");
    if (!label) {
      label = document.createElement("div");
      label.className = "mutabaa-internal-request-label";
      label.style.cssText = [
        "display:block",
        "margin:4px auto 0 auto",
        "padding:2px 8px",
        "font-size:11px",
        "font-weight:bold",
        "line-height:1.6",
        "border-radius:4px",
        "text-align:center",
        "white-space:nowrap",
        "width:fit-content",
      ].join(";");
      noticeCell.appendChild(label);
    }

    if (isInternal) {
      label.textContent = "طلب داخلي";
      label.style.border = "1px solid #dc2626";
      label.style.background = "#dc2626";
      label.style.color = "#fff";
      label.style.display = "block";
    } else {
      // Not internal: no note at all — the label is just hidden rather
      // than showing "طلب ليس داخلي".
      label.textContent = "طلب داخلي";
      label.style.display = "none";
    }
  }

  function applyInternalRequestNoticeToVisibleRows() {
    document.querySelectorAll("tr[smartykeycolval]").forEach((row) => {
      applyInternalRequestNotice(row);
    });
  }

  // NOTE: quick-reopen (context menu) handler moved to content.js —
  // this file only loads on CasesFollowUp/etc. list pages (see
  // ALLOWED_PATHS above), but reopen needs to work from ANY page,
  // including the chatbox popup. See content.js for that logic.

  let mutationTimer = null;
  function scheduleRestore() {
    if (mutationTimer) clearTimeout(mutationTimer);
    mutationTimer = setTimeout(() => {
      restoreVisibleRows();
      applySearchButtonsToVisibleRows();
      applySummaryButtonsToVisibleRows();
      applyInternalRequestNoticeToVisibleRows();
      applyTimerBadgesToVisibleRows();
    }, MUTATION_DEBOUNCE_MS);
  }

  function init() {
    // Delegate change events for all current + future selects/inputs.
    document.addEventListener("change", onFieldChange, true);

    // Initial pass over whatever is already rendered.
    restoreVisibleRows();
    applySearchButtonsToVisibleRows();
    applySummaryButtonsToVisibleRows();
    applyInternalRequestNoticeToVisibleRows();
    applyTimerBadgesToVisibleRows();
    cleanupOldEntries();

    // Pages/tabs can stay open well past 24h without a reload, and cleanup
    // above only runs once at load — so also re-check on an interval while
    // the tab is alive, in addition to the once-per-load check.
    const cleanupInterval = setInterval(cleanupOldEntries, CLEANUP_INTERVAL_MS);

    // Watch the whole document for row add/remove (table body is rebuilt via
    // AJAX rather than single-row insertion in most of these grids).
    // Elements we inject ourselves. Updating these (e.g. the countdown badge's
    // text every second) triggers a childList mutation just like a real AJAX
    // table reload would — without this guard the observer below would treat
    // our own timer tick as "the table changed", call scheduleRestore(), which
    // re-renders the badges again, re-triggering the observer, forever. That
    // feedback loop (not the 1s interval itself) is what was making the page
    // grind to a halt after a few minutes with 50 rows open.
    const OWN_MUTATION_SELECTOR = [
      ".mutabaa-saved-dot",
      ".mutabaa-search-btn",
      ".mutabaa-row-summary",
      ".mutabaa-summary-row-btn",
      ".mutabaa-deadline-badge",
      ".mutabaa-internal-request-label",
    ].join(", ");

    function isOwnMutation(mutation) {
      const target = mutation.target;
      if (target.nodeType === Node.TEXT_NODE) {
        return !!target.parentElement && !!target.parentElement.closest(OWN_MUTATION_SELECTOR);
      }
      if (target.nodeType === Node.ELEMENT_NODE) {
        return target.closest(OWN_MUTATION_SELECTOR) != null;
      }
      return false;
    }

    const observer = new MutationObserver((mutations) => {
      let relevant = false;
      for (const m of mutations) {
        if (isOwnMutation(m)) continue;
        if (m.addedNodes && m.addedNodes.length > 0) {
          relevant = true;
          break;
        }
      }
      if (relevant) scheduleRestore();
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Once the extension is reloaded/updated, this content script instance
    // is a zombie: chrome.* calls are already being no-op'd above so
    // nothing throws, but there's no reason to keep polling/observing on
    // a page that will never get a working extension context again short
    // of a reload. Stop everything cleanly instead of running forever.
    const watchdog = setInterval(() => {
      if (isExtensionContextValid()) return;
      clearInterval(cleanupInterval);
      clearInterval(watchdog);
      clearInterval(badgeTickIntervalHandle);
      clearInterval(deadlineRefreshIntervalHandle);
      observer.disconnect();
      console.log(
        "[متابعة-process] extension context invalidated — stopped background work in this tab. Reload the page to restore it."
      );
    }, 10000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();

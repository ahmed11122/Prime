// process-content.js
// -----------------------------------------------------------------------
// Purpose: prevent lost work when the PC/tab crashes or reloads while an
// employee is mid-way through choosing a case's disposition
// (حالة صحيحة / تعذر توصيل + سبب الراجع / موجل + تاريخ / اعادة توصيل / لا يرد
// على المتابعة).
//
// Strategy:
//   1. Every relevant <select>/<input> lives inside a <tr smartykeycolval="...">.
//      That attribute (mirrored in a hidden input smarty_c_id_hidden_smartyrow_N)
//      is the REAL, stable order id — not the smartyrow_N index, which just
//      reflects render position and shifts as rows load/reorder.
//   2. On every "change" event inside such a row, we snapshot all of that
//      row's relevant fields into chrome.storage.local, keyed by the order id.
//   3. On load, and whenever new rows appear (the table is populated/refreshed
//      via AJAX), we look up each visible row's order id in storage and, if a
//      saved choice exists, show a small colored dot next to the row number
//      with a tooltip describing the last choice and how long ago it was made.
//   4. We deliberately do NOT auto-fill the dropdowns from the cache — only
//      show the reminder — so we never risk silently applying a stale choice
//      to what might now be a different case state. The employee decides.
//   5. Old entries are purged after MAX_AGE_MS so storage doesn't grow forever.
//
// This file is independent from content.js (order start/end + activity
// tracking) and touches a completely different part of the page.
// -----------------------------------------------------------------------

(function () {
  "use strict";

  console.log("[متابعة-process] process-content.js loaded on:", location.href);

  // This script's logic (save/restore badges + the search button) is only
  // relevant to the متابعة الحالات list pages (CasesFollowUp and its sibling
  // queue tabs — تحت التدقيق / تم تدقيقها / etc. live under these other
  // paths). Other pages on the same domain — like the "تتبع" popup
  // (displaySingleCaseInfo) — reuse similar smarty-templated table markup
  // (tr[smartykeycolval], td.cell), which would otherwise cause this script
  // to mistakenly inject badges/buttons there too. Bail out early everywhere
  // else.
  const ALLOWED_PATHS = [
    "/tickets/CasesFollowUp",
    "/tickets/under-revision-by-emp",
    "/tickets/Needs-revision-branch-customers",
  ];

  if (!ALLOWED_PATHS.some((p) => location.pathname.includes(p))) {
    console.log("[متابعة-process] skipped — path not in allowed list:", location.pathname);
    return;
  }

  // Extra explicit guard: displaySingleCaseInfo (تسلسل الأحداث / case history
  // popup) reuses the exact same tr[smartykeycolval] / td.cell markup as the
  // CasesFollowUp list, which is what was causing the buttons/badges to leak
  // onto it even though the path check above should already exclude it.
  if (location.pathname.includes("displaySingleCaseInfo")) {
    console.log("[متابعة-process] skipped — displaySingleCaseInfo explicitly blocked:", location.pathname);
    return;
  }

  console.log("[متابعة-process] path matched, initializing...");

  const STORAGE_PREFIX = "procstate_"; // chrome.storage.local key prefix
  const MAX_AGE_MS = 24 * 60 * 60 * 1000; // purge saved choices after 24h
  const CLEANUP_INTERVAL_MS = 60 * 60 * 1000; // re-check every hour
  const MUTATION_DEBOUNCE_MS = 300;

  // Any element whose id/name contains "_smartyrow_" is one of the fields we
  // care about (status select, return-reason select, postponed date input,
  // etc). We don't hardcode each one so new fields of the same pattern are
  // picked up automatically.
  const FIELD_ID_PATTERN = /_smartyrow_\d+/;

  // Same PocketBase instance/key content.js and background.js already use
  // for order_events/audit_events/break_events — the "important order"
  // marker below just adds one more collection on the same instance.
  const PB_BASE_URL = "https://api.mutabaa.online";
  const PB_API_KEY = "cf98ce3b65462aba390b6de5d4922f7219c46b344e6ba1cc";

  // -----------------------------------------------------------------------
  // Helpers
  // -----------------------------------------------------------------------

  function log(...args) {
    // Flip to true while debugging.
    if (false) console.log("[متابعة-process]", ...args);
  }

  function getRow(el) {
    return el.closest("tr[smartykeycolval]");
  }

  function getOrderId(row) {
    return row && row.getAttribute("smartykeycolval");
  }

  // Turns "q_action_smartyrow_1_casesFollowUp" -> "q_action"
  // Turns "c_rtnreason_smartyrow_1" -> "c_rtnreason"
  function fieldBaseKey(idOrName) {
    return idOrName.replace(/_smartyrow_\d+.*/, "");
  }

  function readFieldValue(el) {
    if (el.tagName === "SELECT") {
      const opt = el.selectedOptions && el.selectedOptions[0];
      return {
        value: el.value,
        label: opt ? opt.textContent.trim() : el.value,
      };
    }
    // input / textarea / date fields
    return { value: el.value, label: el.value };
  }

  function storageKey(orderId) {
    return STORAGE_PREFIX + orderId;
  }

  // -----------------------------------------------------------------------
  // Saving
  // -----------------------------------------------------------------------

  function collectRowFields(row) {
    const fields = {};
    const els = row.querySelectorAll("select, input, textarea");
    els.forEach((el) => {
      const idOrName = el.id || el.name || "";
      if (!FIELD_ID_PATTERN.test(idOrName)) return;
      // Skip empty/placeholder selections so we don't overwrite a real saved
      // choice with a blank one if the row re-renders mid-edit.
      const { value, label } = readFieldValue(el);
      if (value === "" || value == null) return;
      fields[fieldBaseKey(idOrName)] = { value, label };
    });
    return fields;
  }

  function saveRowState(row) {
    const orderId = getOrderId(row);
    if (!orderId) return;

    const fields = collectRowFields(row);
    if (Object.keys(fields).length === 0) return;

    const record = { fields, ts: Date.now() };
    chrome.storage.local.set({ [storageKey(orderId)]: record }, () => {
      log("saved", orderId, record);
      applyBadge(row, record);
    });
  }

  function onFieldChange(e) {
    const el = e.target;
    if (!el || !(el.id || el.name)) return;
    const idOrName = el.id || el.name;
    if (!FIELD_ID_PATTERN.test(idOrName)) return;

    const row = getRow(el);
    if (!row) return;

    saveRowState(row);
  }

  // -----------------------------------------------------------------------
  // Restoring / badges
  // -----------------------------------------------------------------------

  function timeAgo(ts) {
    const diffMin = Math.round((Date.now() - ts) / 60000);
    if (diffMin < 1) return "الآن";
    if (diffMin < 60) return `قبل ${diffMin} دقيقة`;
    const diffH = Math.round(diffMin / 60);
    if (diffH < 24) return `قبل ${diffH} ساعة`;
    const diffD = Math.round(diffH / 24);
    return `قبل ${diffD} يوم`;
  }

  function buildTooltip(record) {
    const lines = Object.values(record.fields).map((f) => f.label);
    return `آخر اختيار محفوظ (${timeAgo(record.ts)}):\n` + lines.join("\n");
  }

  function applyBadge(row, record) {
    const cell = row.querySelector("td.cell");
    if (!cell) return;

    let dot = cell.querySelector(".mutabaa-saved-dot");
    if (!dot) {
      dot = document.createElement("span");
      dot.className = "mutabaa-saved-dot";
      dot.style.cssText = [
        "display:inline-block",
        "width:9px",
        "height:9px",
        "border-radius:50%",
        "background:#2ecc71",
        "margin-inline-start:6px",
        "vertical-align:middle",
        "cursor:pointer",
        "box-shadow:0 0 0 2px rgba(46,204,113,0.25)",
      ].join(";");
      cell.appendChild(dot);

      // Tap/click shows the detail as a lightweight native alert — simplest
      // and most reliable across the page's existing styles/z-index stack.
      dot.addEventListener("click", (ev) => {
        ev.stopPropagation();
        ev.preventDefault();
        alert(dot.title);
      });
    }
    dot.title = buildTooltip(record);
  }

  function removeBadge(row) {
    const dot = row.querySelector(".mutabaa-saved-dot");
    if (dot) dot.remove();
  }

  // -----------------------------------------------------------------------
  // "مهم" (important order marker)
  // -----------------------------------------------------------------------
  // Unlike the green save-state dot above (chrome.storage.local — per PC,
  // per employee), this alert has to be visible to WHOEVER opens this
  // order next, on any PC. So it can't live in chrome.storage.local; it
  // goes to PocketBase (same instance/collection pattern as content.js's
  // order_events/audit_events/break_events), keyed by the same stable
  // order id (smartykeycolval) used everywhere else in this file.
  //
  // Shown as a small labeled pill next to the green dot: "+مهم" outlined
  // = not marked, solid red "مهم" = marked by someone (tooltip shows
  // who/when/why). Clicking toggles it; un-marking asks for confirmation
  // since it affects every employee's view, not just this tab.
  // -----------------------------------------------------------------------

  const IMPORTANT_COLLECTION = "important_orders";
  const IMPORTANT_REFRESH_MS = 20 * 1000; // pick up marks made by other employees/PCs

  async function pbListImportant(filter) {
    try {
      const params = new URLSearchParams({
        filter: filter || "",
        perPage: "200",
        sort: "-marked_at",
      });
      const res = await fetch(
        `${PB_BASE_URL}/api/collections/${IMPORTANT_COLLECTION}/records?${params.toString()}`,
        { headers: { "X-Api-Key": PB_API_KEY } }
      );
      if (!res.ok) {
        console.error("[متابعة-process] important pbList failed", res.status);
        return [];
      }
      const data = await res.json();
      return data.items || [];
    } catch (e) {
      console.error("[متابعة-process] important pbList error", e);
      return [];
    }
  }

  async function pbCreateImportant(payload) {
    try {
      const res = await fetch(
        `${PB_BASE_URL}/api/collections/${IMPORTANT_COLLECTION}/records`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json", "X-Api-Key": PB_API_KEY },
          body: JSON.stringify(payload),
        }
      );
      if (!res.ok) {
        console.error("[متابعة-process] important pbCreate failed", res.status);
        return null;
      }
      return await res.json();
    } catch (e) {
      console.error("[متابعة-process] important pbCreate error", e);
      return null;
    }
  }

  async function pbResolveImportant(recordId) {
    try {
      const res = await fetch(
        `${PB_BASE_URL}/api/collections/${IMPORTANT_COLLECTION}/records/${recordId}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json", "X-Api-Key": PB_API_KEY },
          body: JSON.stringify({ resolved: true }),
        }
      );
      if (!res.ok) {
        const bodyText = await res.text().catch(() => "");
        console.error("[متابعة-process] important pbResolve failed", res.status, bodyText);
        return { ok: false, status: res.status, body: bodyText };
      }
      return { ok: true };
    } catch (e) {
      console.error("[متابعة-process] important pbResolve error", e);
      return { ok: false, status: 0, body: String(e) };
    }
  }

  // Reuses the same cached employee name content.js writes to
  // chrome.storage.local (mutabaaRawName) — no need to re-scrape the
  // header here too.
  function getEmployeeNameForImportant() {
    return new Promise((resolve) => {
      if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) {
        resolve("غير معروف");
        return;
      }
      chrome.storage.local.get(["mutabaaRawName"], (data) => {
        resolve((data && data.mutabaaRawName) || "غير معروف");
      });
    });
  }

  // orderId -> unresolved important record. Refreshed periodically from
  // PocketBase so a mark made on a coworker's PC shows up here too.
  let importantOrdersCache = {};

  async function refreshImportantOrders() {
    const items = await pbListImportant("resolved=false");
    const next = {};
    items.forEach((r) => {
      next[r.order_id] = r;
    });
    importantOrdersCache = next;
    applyImportantMarksToVisibleRows();
  }

  function buildImportantTooltip(record) {
    const who = record.marked_by ? `بواسطة ${record.marked_by}` : "";
    const when = record.marked_at ? `(${timeAgo(record.marked_at)})` : "";
    const note = record.note ? `\n${record.note}` : "";
    return `مهم: طلب مهم ${who} ${when}`.trim() + note;
  }

  function applyImportantButton(row) {
    const cell = getReceiptCell(row);
    if (!cell) return;
    const orderId = getOrderId(row);
    if (!orderId) return;

    let btn = cell.querySelector(".mutabaa-important-badge");
    if (!btn) {
      btn = document.createElement("span");
      btn.className = "mutabaa-important-badge";
      btn.style.cssText = [
        "display:inline-flex",
        "align-items:center",
        "cursor:pointer",
        "font-weight:bold",
        "line-height:1.4",
        "white-space:nowrap",
        "user-select:none",
        "margin-inline-start:6px",
        "vertical-align:middle",
      ].join(";");
      cell.appendChild(btn);

      btn.addEventListener("click", (ev) => {
        ev.stopPropagation();
        ev.preventDefault();
        toggleImportant(row, orderId, btn);
      });
    }

    const record = importantOrdersCache[orderId];
    if (record) {
      // Marked: a small solid red pill labeled "مهم" — readable at a
      // glance, no need to hover just to know what the color means.
      btn.textContent = "مهم";
      btn.style.padding = "1px 6px";
      btn.style.borderRadius = "8px";
      btn.style.fontSize = "10px";
      btn.style.background = "#dc2626";
      btn.style.color = "#fff";
      btn.style.border = "1px solid rgba(220,38,38,0.6)";
      btn.title = buildImportantTooltip(record);
    } else {
      // Not marked: a small, unobtrusive outlined "+مهم" so it doesn't
      // compete with the badges that actually need attention, but is
      // still clearly the same control once you know to look for it.
      // White background + black text — the dark theme's red-on-dark
      // outline was nearly unreadable.
      btn.textContent = "+مهم";
      btn.style.padding = "1px 6px";
      btn.style.borderRadius = "8px";
      btn.style.fontSize = "10px";
      btn.style.background = "#ffffff";
      btn.style.color = "#000000";
      btn.style.border = "1px solid rgba(220,38,38,0.6)";
      btn.title = "وضع علامة كطلب مهم";
    }
  }

  async function toggleImportant(row, orderId, btn) {
    const existing = importantOrdersCache[orderId];

    if (existing) {
      if (!confirm('إزالة علامة "مهم" عن هذا الطلب؟ (ستختفي عند كل الموظفين)')) return;
      btn.style.opacity = "0.5";
      const result = await pbResolveImportant(existing.id);
      btn.style.opacity = "1";
      if (result.ok) {
        delete importantOrdersCache[orderId];
        applyImportantButton(row);
      } else {
        // Surface the actual server response instead of a generic message —
        // a 403 here almost always means the "important_orders" collection's
        // *update* API rule doesn't allow the same X-Api-Key access that its
        // create/list rules do (easy to miss when first setting the
        // collection up, since create/list working can look like everything
        // is configured).
        alert(
          `تعذر إزالة العلامة (رمز الخطأ: ${result.status || "شبكة"}).\n` +
          `إذا تكرر الخطأ، تحقق من صلاحية "update" على مجموعة important_orders في PocketBase.`
        );
      }
      return;
    }

    // Cancel must abort — not silently mark the order with an empty note.
    // window.prompt returns null on Cancel and "" on empty-but-confirmed
    // input; only null means "changed my mind".
    const note = prompt("سبب الأهمية (اختياري):", "");
    if (note === null) return;

    const marked_by = await getEmployeeNameForImportant();
    btn.style.opacity = "0.5";
    const created = await pbCreateImportant({
      order_id: orderId,
      marked_by,
      marked_at: Date.now(),
      note,
      resolved: false,
    });
    btn.style.opacity = "1";
    if (created) {
      importantOrdersCache[orderId] = created;
      applyImportantButton(row);
    } else {
      alert("تعذر حفظ العلامة، حاول مرة أخرى.");
    }
  }

  function applyImportantMarksToVisibleRows() {
    document.querySelectorAll("tr[smartykeycolval]").forEach((row) => {
      applyImportantButton(row);
    });
  }

  function restoreRow(row, cachedRecords) {
    const orderId = getOrderId(row);
    if (!orderId) return;
    const record = cachedRecords[storageKey(orderId)];
    if (record) {
      applyBadge(row, record);
    } else {
      removeBadge(row);
    }
  }

  function restoreVisibleRows() {
    const rows = Array.from(document.querySelectorAll("tr[smartykeycolval]"));
    if (rows.length === 0) return;

    const keys = rows
      .map((r) => getOrderId(r))
      .filter(Boolean)
      .map(storageKey);

    // Batch the read so 100+ concurrent orders cost one storage call, not one
    // call per row.
    chrome.storage.local.get(keys, (cachedRecords) => {
      rows.forEach((row) => restoreRow(row, cachedRecords));
    });
  }

  // -----------------------------------------------------------------------
  // Cleanup — drop entries older than MAX_AGE_MS
  // -----------------------------------------------------------------------

  function cleanupOldEntries() {
    chrome.storage.local.get(null, (all) => {
      const now = Date.now();
      const toRemove = [];
      Object.keys(all).forEach((key) => {
        if (!key.startsWith(STORAGE_PREFIX)) return;
        const record = all[key];
        if (!record || !record.ts || now - record.ts > MAX_AGE_MS) {
          toRemove.push(key);
        }
      });
      if (toRemove.length > 0) {
        chrome.storage.local.remove(toRemove, () => {
          log("cleaned up", toRemove.length, "stale entries");
        });
      }
    });
  }

  // -----------------------------------------------------------------------
  // "بحث في النظام" button — extract the recipient phone number from the
  // row and open prime-iq.com's global search for it in a new tab.
  // -----------------------------------------------------------------------

  // Iraqi mobile numbers as they appear in this table: 07 followed by 9
  // digits, sometimes with a trailing separator like " , " after them.
  const PHONE_PATTERN = /07\d{9}/;

  const GLOBAL_SEARCH_BASE =
    "https://prime-iq.com/myp/Mainctrl/cases/displayGlobalSearchResults?globalSerachParamter=";

  function findPhoneInRow(row) {
    const phoneCell = getPhoneCell(row);
    if (!phoneCell) return null;
    const match = phoneCell.textContent.match(PHONE_PATTERN);
    return match ? match[0] : null;
  }

  // Cache the column index of "هاتف المستلم" per table, since re-deriving it
  // on every row would mean walking the thead repeatedly.
  const phoneColumnIndexByTable = new WeakMap();

  function getPhoneColumnIndex(table) {
    if (phoneColumnIndexByTable.has(table)) {
      return phoneColumnIndexByTable.get(table);
    }
    let index = -1;
    // Some renders of this table don't use a real <thead>, so also check the
    // first row's cells as a fallback.
    const headerCells = table.querySelectorAll(
      "thead th, tr:first-child th, tr:first-child td"
    );
    headerCells.forEach((th, i) => {
      const clean = th.textContent.replace(/\s+/g, " ").trim();
      if (index === -1 && clean.includes("هاتف المستلم")) {
        index = i;
      }
    });
    phoneColumnIndexByTable.set(table, index);
    return index;
  }

  function getPhoneCell(row) {
    const table = row.closest("table");
    if (!table) return null;
    const index = getPhoneColumnIndex(table);
    if (index !== -1) {
      const cells = row.querySelectorAll("td");
      if (cells[index]) return cells[index];
    }
    // Column header lookup failed (unexpected table layout) — as a last
    // resort, use the one cell in this row that actually contains a phone
    // number, rather than giving up or falling back to an unrelated cell
    // like td.cell.
    const cells = Array.from(row.querySelectorAll("td"));
    return cells.find((td) => PHONE_PATTERN.test(td.textContent)) || null;
  }

  // Same lookup pattern, for "رقم الوصل" — this is where the مهم button
  // lives, instead of the # column.
  const receiptColumnIndexByTable = new WeakMap();

  function getReceiptColumnIndex(table) {
    if (receiptColumnIndexByTable.has(table)) {
      return receiptColumnIndexByTable.get(table);
    }
    let index = -1;
    const headerCells = table.querySelectorAll(
      "thead th, tr:first-child th, tr:first-child td"
    );
    headerCells.forEach((th, i) => {
      const clean = th.textContent.replace(/\s+/g, " ").trim();
      if (index === -1 && clean.includes("رقم الوصل")) {
        index = i;
      }
    });
    receiptColumnIndexByTable.set(table, index);
    return index;
  }

  function getReceiptCell(row) {
    const table = row.closest("table");
    if (!table) return null;
    const index = getReceiptColumnIndex(table);
    if (index !== -1) {
      const cells = row.querySelectorAll("td");
      if (cells[index]) return cells[index];
    }
    // Header lookup failed — fall back to td.cell rather than not showing
    // the button at all.
    return row.querySelector("td.cell");
  }

  function applySearchButton(row) {
    try {
      // Only ever anchor to the cell that actually contains a phone number.
      // Never fall back to td.cell or any other unrelated cell — that's what
      // previously let the button attach to the wrong place.
      const targetCell = getPhoneCell(row);
      if (!targetCell) return;
      if (targetCell.querySelector(".mutabaa-search-btn")) return; // already added

      const match = targetCell.textContent.match(PHONE_PATTERN);
      if (!match) return; // no real phone number here — don't add a button

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "mutabaa-search-btn";
    btn.textContent = "ابحث في النظام";
    btn.style.cssText = [
      "display:block",
      "margin:18px auto 0 auto",
      "padding:2px 8px",
      "font-size:11px",
      "line-height:1.6",
      "border-radius:4px",
      "border:1px solid #9ca3af",
      "background:#9ca3af",
      "color:#fff",
      "cursor:pointer",
      "white-space:nowrap",
    ].join(";");

    btn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      ev.preventDefault();
      const phone = findPhoneInRow(row);
      if (!phone) {
        alert("لم يتم العثور على رقم هاتف في هذا الصف.");
        return;
      }
      window.open(GLOBAL_SEARCH_BASE + encodeURIComponent(phone), "_blank");
    });

    targetCell.appendChild(btn);
    } catch (e) {
      console.error("[متابعة-process] applySearchButton error:", e);
    }
  }

  function applySearchButtonsToVisibleRows() {
    document
      .querySelectorAll("tr[smartykeycolval]")
      .forEach((row) => applySearchButton(row));
  }

  // -----------------------------------------------------------------------
  // Per-row case summary (نوع البضاعة / مندوب التوصيل / عمر الطلب) — the
  // same three facts content-summary.js shows on the تتبع popup, but pulled
  // in the background for every row on the list itself, right under the
  // "ابحث في النظام" button, so nobody has to open تتبع to see them.
  //
  // The popup page (displaySingleCaseInfo) is same-origin, so we can fetch
  // its HTML directly with the row's orderId as auditcaseid and parse the
  // same smarty_singledispalycol containers out of it.
  // -----------------------------------------------------------------------

  const SUMMARY_FIELD_SUFFIXES = {
    itemType: "itemsdetails",
    agentName: "dlvagentname",
    createdAt: "c_createddt",
    remarks: "c_rmk",
  };

  const DETAILS_LABELS = new Set(["تفاصيل", "التفاصيل"]);

  // orderId -> "pending" | { text } | "error" — avoids re-fetching the same
  // case every time the AJAX-rebuilt table triggers our mutation observer.
  const rowSummaryCache = new Map();

  function getFieldValueFromDoc(doc, suffix) {
    const container = doc.querySelector(
      `[smarty_singledispalycol="smarty_singledispalycol_${suffix}_coldiv"]`
    );
    if (!container) return null;

    const valueCell = container.querySelector(".col-sm-7");
    if (valueCell) {
      const text = valueCell.textContent.replace(/\s+/g, " ").trim();
      return text || null;
    }

    const clone = container.cloneNode(true);
    clone.querySelectorAll("h6").forEach((h) => h.remove());
    const text = clone.textContent.replace(/\s+/g, " ").trim();
    return text || null;
  }

  function isDetailsButtonCell(valueCell) {
    const cellText = valueCell.textContent.replace(/\s+/g, " ").trim();
    return DETAILS_LABELS.has(cellText);
  }

  async function fetchItemTypesFromDetailsPage(auditCaseId) {
    try {
      const url = `${location.origin}/myp/Mainctrl/cases/itemDetails?auditcaseid=${encodeURIComponent(
        auditCaseId
      )}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) return null;

      const html = await res.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const table = doc.querySelector("table");
      if (!table) return null;

      const headerCells = table.querySelectorAll("thead th");
      let typeIndex = -1;
      headerCells.forEach((th, i) => {
        if (typeIndex === -1 && th.textContent.includes("نوع البضاعة")) {
          typeIndex = i;
        }
      });
      if (typeIndex === -1) return null;

      const rows = table.querySelectorAll("tbody tr");
      const counts = new Map();
      rows.forEach((row) => {
        const cells = row.querySelectorAll("td");
        const val = cells[typeIndex]
          ? cells[typeIndex].textContent.replace(/\s+/g, " ").trim()
          : "";
        if (!val) return;
        counts.set(val, (counts.get(val) || 0) + 1);
      });
      if (counts.size === 0) return null;

      return Array.from(counts.entries())
        .map(([type, count]) => (count > 1 ? `${type} (${count})` : type))
        .join("، ");
    } catch (e) {
      console.error("[متابعة-process] fetchItemTypesFromDetailsPage error:", e);
      return null;
    }
  }

  async function resolveItemTypeFromDoc(doc, auditCaseId) {
    const container = doc.querySelector(
      `[smarty_singledispalycol="smarty_singledispalycol_${SUMMARY_FIELD_SUFFIXES.itemType}_coldiv"]`
    );
    if (!container) return null;

    const valueCell = container.querySelector(".col-sm-7");
    if (!valueCell) return null;

    if (!isDetailsButtonCell(valueCell)) {
      const text = valueCell.textContent.replace(/\s+/g, " ").trim();
      return text || null;
    }

    return await fetchItemTypesFromDetailsPage(auditCaseId);
  }

  function parseDateFlexible(raw) {
    if (!raw) return null;

    let d = new Date(raw.replace(" ", "T"));
    if (!isNaN(d.getTime())) return d;

    const m = raw.match(
      /(\d{1,2})\/(\d{1,2})\/(\d{4})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?/
    );
    if (m) {
      const [, mo, day, yr, hh, mm, ss] = m;
      d = new Date(
        Number(yr),
        Number(mo) - 1,
        Number(day),
        Number(hh),
        Number(mm),
        Number(ss || 0)
      );
      if (!isNaN(d.getTime())) return d;
    }

    return null;
  }

  function formatAge(createdDate) {
    if (!createdDate) return null;

    const diffMs = Date.now() - createdDate.getTime();
    if (diffMs < 0) return null;

    const minutes = Math.floor(diffMs / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days >= 1) {
      const remHours = hours % 24;
      return remHours > 0 ? `${days} يوم و ${remHours} ساعة` : `${days} يوم`;
    }
    if (hours >= 1) {
      return `${hours} ساعة`;
    }
    return `${minutes} دقيقة`;
  }

  // The real per-action case history is table[id*="AuditTrailPopUp"] — one
  // row per status change, in chronological order (each row's own two
  // timestamp columns confirm this). Its rows come from two different
  // sources though: staff actions (employee cell prefixed "موظف:") and the
  // delivery agent's own automatic log entries (prefixed "مندوب:" /
  // "متنوب:"). We only want the LAST *staff* entry — a later مندوب-logged
  // row would otherwise look "more recent" and wrongly overwrite whose
  // decision this actually was.
  //
  // Column order isn't labeled in the markup, but empirically: [index, date,
  // status, outcome, location, employee, date2, ...]. We locate the employee
  // cell by content ("موظف") rather than a fixed index, then read the
  // outcome as the cell two positions before it (status/disposition sits
  // right before location, which sits right before the employee cell).
  function extractLastProcessedBy(doc) {
    const table = doc.querySelector('table[id*="AuditTrailPopUp"]');
    if (!table) return null;

    const rows = Array.from(table.querySelectorAll("tbody tr"));
    if (!rows.length) return null;

    for (let i = rows.length - 1; i >= 0; i--) {
      const cells = Array.from(rows[i].querySelectorAll("td"));
      const empIndex = cells.findIndex((td) =>
        /موظف\s*:?/.test(td.textContent)
      );
      if (empIndex === -1) continue; // this row was logged by المندوب, not staff — skip it

      const empText = cells[empIndex].textContent.replace(/\s+/g, " ").trim();
      const nameMatch = empText.match(/موظف\s*:?\s*(.+)/);
      const name = (nameMatch ? nameMatch[1] : empText).trim();

      const outcomeCell = cells[empIndex - 2];
      const outcome = outcomeCell
        ? outcomeCell.textContent.replace(/\s+/g, " ").trim()
        : null;

      return { name: name || null, outcome: outcome || null };
    }

    return null;
  }

  async function fetchCaseSummary(orderId) {
    try {
      const url = `${location.origin}/myp/Mainctrl/cases/displaySingleCaseInfo?auditcaseid=${encodeURIComponent(
        orderId
      )}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) return null;

      const html = await res.text();
      const doc = new DOMParser().parseFromString(html, "text/html");

      const itemType = await resolveItemTypeFromDoc(doc, orderId);
      const agentName = getFieldValueFromDoc(doc, SUMMARY_FIELD_SUFFIXES.agentName);
      const createdRaw = getFieldValueFromDoc(doc, SUMMARY_FIELD_SUFFIXES.createdAt);
      const age = formatAge(parseDateFlexible(createdRaw));
      const remarks = getFieldValueFromDoc(doc, SUMMARY_FIELD_SUFFIXES.remarks);
      const lastProcessed = extractLastProcessedBy(doc);

      return {
        itemType: itemType || "غير متوفر",
        agentName: agentName || "غير متوفر",
        age: age || (createdRaw ? `${createdRaw} (تعذر حساب العمر)` : "غير متوفر"),
        remarks: remarks || "غير متوفر",
        lastProcessedByName: (lastProcessed && lastProcessed.name) || "غير متوفر",
        lastProcessedOutcome: (lastProcessed && lastProcessed.outcome) || "غير متوفر",
      };
    } catch (e) {
      console.error("[متابعة-process] fetchCaseSummary error:", e);
      return null;
    }
  }

  function renderRowSummaryBox(targetCell) {
    let box = targetCell.querySelector(".mutabaa-row-summary");
    if (!box) {
      box = document.createElement("div");
      box.className = "mutabaa-row-summary";
      box.style.cssText = [
        "display:none",
        "margin-top:4px",
        "padding:4px 6px",
        "font-size:10px",
        "line-height:1.5",
        "text-align:right",
        "color:#1f2937",
        "background:#f3f4f6",
        "border:1px solid #e5e7eb",
        "border-radius:4px",
        "max-width:220px",
      ].join(";");
      targetCell.appendChild(box);
    }
    return box;
  }

  // Each summary field, in display order: [label, key in the summary object, background color].
  const SUMMARY_ROWS = [
    ["نوع البضاعة", "itemType", "#dbeafe"],
    ["مندوب التوصيل", "agentName", "#dcfce7"],
    ["عمر الطلب", "age", "#fef9c3"],
    ["ملاحظات", "remarks", "#fee2e2"],
    ["آخر موظف", "lastProcessedByName", "#ede9fe"],
    ["نتيجة معالجته", "lastProcessedOutcome", "#ffedd5"],
  ];

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function buildSummaryHtml(summary) {
    return SUMMARY_ROWS.map(([label, key, bg]) => {
      return (
        `<div style="display:flex;justify-content:space-between;gap:6px;padding:2px 4px;margin-bottom:2px;border-radius:3px;background:${bg};">` +
        `<span style="color:#4b5563;white-space:nowrap;">${escapeHtml(label)}</span>` +
        `<span style="font-weight:bold;color:#111827;text-align:left;">${escapeHtml(summary[key])}</span>` +
        `</div>`
      );
    }).join("");
  }

  // How long the fetched details stay visible before the row reverts back to
  // showing the ملخص button. Fetch time itself doesn't count against this —
  // the countdown starts only once the text is actually on screen.
  const SUMMARY_DISPLAY_MS = 10000;

  const rowSummaryHideTimers = new Map(); // orderId -> timeout handle

  async function revealRowSummary(row, btn, box) {
    const orderId = getOrderId(row);
    if (!orderId) return;

    const existingTimer = rowSummaryHideTimers.get(orderId);
    if (existingTimer) clearTimeout(existingTimer);

    btn.style.display = "none";
    box.style.display = "block";

    const cached = rowSummaryCache.get(orderId);

    let html;
    if (cached && cached !== "pending" && cached !== "error") {
      html = cached.html;
    } else {
      box.textContent = "جارٍ التحميل...";
      const summary = await fetchCaseSummary(orderId);
      if (!summary) {
        rowSummaryCache.set(orderId, "error");
        html = "تعذر جلب التفاصيل";
      } else {
        html = buildSummaryHtml(summary);
        rowSummaryCache.set(orderId, { html });
      }
    }

    box.innerHTML = html;

    const timer = setTimeout(() => {
      box.style.display = "none";
      btn.style.display = "block";
      rowSummaryHideTimers.delete(orderId);
    }, SUMMARY_DISPLAY_MS);
    rowSummaryHideTimers.set(orderId, timer);
  }

  // Cache the column index of "تاريخ الشحنة" per table, same approach as
  // getPhoneColumnIndex — the ملخص button now lives here instead of next to
  // the phone/search button, so it needs its own column lookup.
  const dateColumnIndexByTable = new WeakMap();

  function getDateColumnIndex(table) {
    if (dateColumnIndexByTable.has(table)) {
      return dateColumnIndexByTable.get(table);
    }
    let index = -1;
    const headerCells = table.querySelectorAll(
      "thead th, tr:first-child th, tr:first-child td"
    );
    headerCells.forEach((th, i) => {
      const clean = th.textContent.replace(/\s+/g, " ").trim();
      if (index === -1 && (clean.includes("تاريخ الشحنه") || clean.includes("تاريخ الشحنة"))) {
        index = i;
      }
    });
    dateColumnIndexByTable.set(table, index);
    return index;
  }

  function getDateCell(row) {
    const table = row.closest("table");
    if (!table) return null;
    const index = getDateColumnIndex(table);
    if (index === -1) return null;
    const cells = row.querySelectorAll("td");
    return cells[index] || null;
  }

  function applySummaryButton(row) {
    // Sits under تاريخ الشحنة now, not next to the phone/search button —
    // falls back to the phone cell only if this row's table has no
    // recognizable تاريخ الشحنة column, so the button never just disappears.
    const targetCell = getDateCell(row) || getPhoneCell(row);
    if (!targetCell) return;
    if (targetCell.querySelector(".mutabaa-summary-row-btn")) return; // already added

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "mutabaa-summary-row-btn";
    btn.textContent = "ملخص";
    btn.style.cssText = [
      "display:block",
      "margin:4px auto 0 auto",
      "padding:2px 8px",
      "font-size:11px",
      "line-height:1.6",
      "border-radius:4px",
      "border:1px solid #9ca3af",
      "background:#9ca3af",
      "color:#fff",
      "cursor:pointer",
      "white-space:nowrap",
    ].join(";");

    const box = renderRowSummaryBox(targetCell);

    btn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      ev.preventDefault();
      revealRowSummary(row, btn, box);
    });

    targetCell.appendChild(btn);
  }

  function applySummaryButtonsToVisibleRows() {
    document.querySelectorAll("tr[smartykeycolval]").forEach((row) => {
      applySummaryButton(row);
    });
  }

  // -----------------------------------------------------------------------
  // "طلب داخلي" note — shown under اشعار المندوب, driven purely by whichever
  // neighborhood appears in this row's العنوان cell. Only these five
  // neighborhoods count as "internal"; everything else gets no text.
  // -----------------------------------------------------------------------

  const INTERNAL_REQUEST_NEIGHBORHOODS = [
    "حي العامل",
    "العامرية",
    "المحمودية",
    "ابو غريب",
    "اليرموك",
    "حي العدل",
    "حي الجامعة",
    "حي القادسية",
    "السيدية",
    "نفق الشرطة",
    "الحارثية",
  ];

  // ا / أ / إ / آ all render as plain "ا" once typed casually or copied from
  // different sources, so a literal .includes() on header/cell text is
  // fragile — normalize them all to ا before comparing (this is what broke
  // اشعار detection above).
  function normalizeAlif(str) {
    return str.replace(/[أإآ]/g, "ا");
  }

  // Cache column indices per table, same pattern as getDateColumnIndex /
  // getPhoneColumnIndex above.
  const addressColumnIndexByTable = new WeakMap();
  const noticeColumnIndexByTable = new WeakMap();

  function findColumnIndex(table, cache, matches) {
    if (cache.has(table)) return cache.get(table);
    let index = -1;
    const headerCells = table.querySelectorAll(
      "thead th, tr:first-child th, tr:first-child td"
    );
    headerCells.forEach((th, i) => {
      const clean = th.textContent.replace(/\s+/g, " ").trim();
      if (index === -1 && matches(clean)) index = i;
    });
    cache.set(table, index);
    return index;
  }

  function getAddressCell(row) {
    const table = row.closest("table");
    if (!table) return null;
    const index = findColumnIndex(table, addressColumnIndexByTable, (clean) =>
      normalizeAlif(clean).includes("العنوان")
    );
    if (index === -1) return null;
    const cells = row.querySelectorAll("td");
    return cells[index] || null;
  }

  function getNoticeCell(row) {
    const table = row.closest("table");
    if (!table) return null;
    // Header text varies not just in wording but in the alif form itself
    // (ا vs أ vs إ — e.g. "اشعار" vs "إشعار"), which silently breaks a
    // literal .includes() match. Normalize alif variants before comparing
    // so "شعار" (present in all of them) reliably matches, and also match
    // on "المندوب" as a second signal in case the root word itself differs.
    const index = findColumnIndex(table, noticeColumnIndexByTable, (clean) =>
      normalizeAlif(clean).includes("شعار")
    );
    if (index === -1) return null;
    const cells = row.querySelectorAll("td");
    return cells[index] || null;
  }

  function applyInternalRequestNotice(row) {
    const addressCell = getAddressCell(row);
    const noticeCell = getNoticeCell(row);
    if (!addressCell || !noticeCell) return;

    const addressText = normalizeAlif(
      addressCell.textContent.replace(/\s+/g, " ").trim()
    );
    // These neighborhoods are Baghdad-specific — matching the neighborhood
    // name alone isn't enough, since the same neighborhood name can turn up
    // in an address that is actually in a different city (e.g. "موصل - حي
    // الجامعة" vs "بغداد - حي الجامعة"). Require بغداد to appear too.
    const isBaghdad = addressText.includes(normalizeAlif("بغداد"));
    const isInternal =
      isBaghdad &&
      INTERNAL_REQUEST_NEIGHBORHOODS.some((n) =>
        addressText.includes(normalizeAlif(n))
      );

    let label = noticeCell.querySelector(".mutabaa-internal-request-label");
    if (!label) {
      label = document.createElement("div");
      label.className = "mutabaa-internal-request-label";
      label.style.cssText = [
        "display:block",
        "margin:4px auto 0 auto",
        "padding:2px 8px",
        "font-size:11px",
        "font-weight:bold",
        "line-height:1.6",
        "border-radius:4px",
        "text-align:center",
        "white-space:nowrap",
        "width:fit-content",
      ].join(";");
      noticeCell.appendChild(label);
    }

    if (isInternal) {
      label.textContent = "طلب داخلي";
      label.style.border = "1px solid #dc2626";
      label.style.background = "#dc2626";
      label.style.color = "#fff";
      label.style.display = "block";
    } else {
      // Not internal: no note at all — the label is just hidden rather
      // than showing "طلب ليس داخلي".
      label.textContent = "طلب داخلي";
      label.style.display = "none";
    }
  }

  function applyInternalRequestNoticeToVisibleRows() {
    document.querySelectorAll("tr[smartykeycolval]").forEach((row) => {
      applyInternalRequestNotice(row);
    });
  }

  // NOTE: quick-reopen (context menu) handler moved to content.js —
  // this file only loads on CasesFollowUp/etc. list pages (see
  // ALLOWED_PATHS above), but reopen needs to work from ANY page,
  // including the chatbox popup. See content.js for that logic.

  let mutationTimer = null;
  function scheduleRestore() {
    if (mutationTimer) clearTimeout(mutationTimer);
    mutationTimer = setTimeout(() => {
      restoreVisibleRows();
      applySearchButtonsToVisibleRows();
      applySummaryButtonsToVisibleRows();
      applyInternalRequestNoticeToVisibleRows();
      applyImportantMarksToVisibleRows(); // cache-only, no network call
    }, MUTATION_DEBOUNCE_MS);
  }

  function init() {
    // Delegate change events for all current + future selects/inputs.
    document.addEventListener("change", onFieldChange, true);

    // Initial pass over whatever is already rendered.
    restoreVisibleRows();
    applySearchButtonsToVisibleRows();
    applySummaryButtonsToVisibleRows();
    applyInternalRequestNoticeToVisibleRows();
    cleanupOldEntries();

    // Important-order marks: fetch once now, then keep polling so a mark
    // made by a coworker on a different PC shows up here without needing
    // a page reload.
    refreshImportantOrders();
    setInterval(refreshImportantOrders, IMPORTANT_REFRESH_MS);

    // Pages/tabs can stay open well past 24h without a reload, and cleanup
    // above only runs once at load — so also re-check on an interval while
    // the tab is alive, in addition to the once-per-load check.
    setInterval(cleanupOldEntries, CLEANUP_INTERVAL_MS);

    // Watch the whole document for row add/remove (table body is rebuilt via
    // AJAX rather than single-row insertion in most of these grids).
    const observer = new MutationObserver((mutations) => {
      let relevant = false;
      for (const m of mutations) {
        if (m.addedNodes && m.addedNodes.length > 0) {
          relevant = true;
          break;
        }
      }
      if (relevant) scheduleRestore();
    });

    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();

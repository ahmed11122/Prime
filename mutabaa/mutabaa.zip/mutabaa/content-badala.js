// ══════════════════════════════════════════════════════════════════
// متابعة — content-badala.js
// Runs on the badala.html (نظام البدالة) page.
// ══════════════════════════════════════════════════════════════════
// Job:
//  1. Watch the grid for "my" claimed line (.line-card.mine).
//  2. Read its username/password from the already-rendered
//     .line-creds-value spans (no need to touch Firebase directly —
//     the page already put the creds in the DOM for us).
//  3. Tell background.js to open/focus the Yeastar login tab and
//     auto-fill it.
//  4. If background.js later tells us the PBX logged the user out,
//     click the real "إغلاق البدالة" button so the page's own
//     releaseMyLine() runs and the line flips back to "متاحة".
// ══════════════════════════════════════════════════════════════════

let lastSentLine = null;

function getMyClaimedCard() {
  return document.querySelector(".line-card.mine");
}

function extractCreds(card) {
  const rows = card.querySelectorAll(".line-creds-row");
  let username = null, password = null;
  rows.forEach((row) => {
    const label = row.querySelector(".line-creds-label");
    const value = row.querySelector(".line-creds-value");
    if (!label || !value) return;
    const text = label.textContent.trim();
    if (text.includes("مستخدم")) username = value.textContent.trim();
    if (text.includes("مرور")) password = value.textContent.trim();
  });
  return { username, password };
}

function getLineNum(card) {
  const el = card.querySelector(".line-num");
  return el ? el.textContent.trim() : null;
}

function checkClaimedLine() {
  const card = getMyClaimedCard();

  if (!card) {
    // Not holding any line right now.
    lastSentLine = null;
    return;
  }

  const lineNum = getLineNum(card);
  if (!lineNum || lineNum === lastSentLine) return; // already handled

  const { username, password } = extractCreds(card);
  if (!username && !password) return; // creds not rendered yet, try again later

  lastSentLine = lineNum;

  console.log("[متابعة] detected claimed line", lineNum, "sending to background...");

  chrome.runtime.sendMessage(
    { type: "badalaClaimed", lineNum, username, password },
    () => {
      if (chrome.runtime.lastError) {
        console.error("[متابعة] sendMessage failed:", chrome.runtime.lastError.message);
      } else {
        console.log("[متابعة] background acknowledged badalaClaimed");
      }
    }
  );
}

// The grid re-renders on every Firebase update, so poll cheaply
// instead of trying to out-guess the page's own render() timing.
setInterval(checkClaimedLine, 1500);
checkClaimedLine();

// ── Auto-release when the PBX side reports a logout ────────────────
// When WE click .btn-release below (or the code here clicks it on the
// PBX's behalf) we don't want to bounce a redundant "badalaReleased"
// notification back to the PBX side — this flag suppresses exactly
// one upcoming click-notification.
let suppressNextReleaseNotify = false;

chrome.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "yeastarLoggedOut") {
    const releaseBtn = document.querySelector(".btn-release");
    if (releaseBtn) {
      suppressNextReleaseNotify = true; // this release originated FROM the PBX, don't loop back
      releaseBtn.click(); // triggers the page's own releaseMyLine()
      lastSentLine = null;
      console.log("[متابعة] auto-released line after PBX logout");
    }
  }
});

// ── Tell the PBX to log out when the employee manually releases ────
// releaseMyLine() is wired via an inline onclick="" attribute in
// badala.html, so we can't just replace it — instead we listen for
// the click ourselves (capture phase, on document) and fire our own
// notification alongside whatever the page's own handler does.
document.addEventListener(
  "click",
  (e) => {
    const btn = e.target.closest(".btn-release");
    if (!btn) return;

    if (suppressNextReleaseNotify) {
      suppressNextReleaseNotify = false;
      return; // this click came from the PBX-logout listener above
    }

    console.log("[متابعة] user manually released their line — asking PBX to log out too");
    chrome.runtime.sendMessage({ type: "badalaReleased" }, () => {
      void chrome.runtime.lastError;
    });
  },
  true
);

console.log("[متابعة] badala watcher active");
